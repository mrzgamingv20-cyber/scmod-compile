// PerfPreset mod: tombol "Preset Performa" di layar Pengaturan (Mati / Seimbang / Rendah).
// Satu ketukan mengatur sekaligus: jarak pandang, resolusi, bayangan objek, mipmap terrain, langit,
// terrain multithread, dan batas spawn mob alami (untuk world besar / banyak mob).
// Semua nilai memakai SettingsManager dan SubsystemCreatureSpawn yang sudah ada di game.
using System;
using System.Collections.Generic;
using System.Xml.Linq;
using Engine;
using GameEntitySystem;

namespace Game
{
	public class PerfPresetLoader : ModLoader
	{
		public const string ConfigKey = "com.mrzgaming.perfpreset.Preset";
		static readonly string[] Names = new string[] { "Mati", "Seimbang", "Rendah" };

		static int s_preset;
		static bool s_loaded;

		static int CurrentPreset
		{
			get
			{
				if (!s_loaded)
				{
					string text;
					int value;
					s_preset = (ModsManager.Configs.TryGetValue(ConfigKey, out text) && int.TryParse(text, out value)) ? Math.Clamp(value, 0, Names.Length - 1) : 0;
					s_loaded = true;
				}
				return s_preset;
			}
		}

		static string ButtonText()
		{
			return "Preset Performa: " + Names[CurrentPreset];
		}

		public override void __ModInitialize()
		{
			ModsManager.RegisterHook("OnProjectLoaded", this);
			ModsManager.RegisterHook("OnSettingsScreenCreated", this);
		}

		// Batas spawn adalah field static yang kembali ke bawaan tiap game dibuka, jadi diterapkan lagi saat world dimuat.
		public override void OnProjectLoaded(Project project)
		{
			ApplySpawnLimits(CurrentPreset);
		}

		static void ApplySpawnLimits(int preset)
		{
			// Hanya membatasi spawn BARU; mob yang sudah ada tidak dihapus.
			switch (preset)
			{
				case 1:   // Seimbang
					SubsystemCreatureSpawn.m_totalLimit = 18;
					SubsystemCreatureSpawn.m_areaLimit = 3;
					SubsystemCreatureSpawn.m_totalLimitConstant = 4;
					SubsystemCreatureSpawn.m_totalLimitConstantChallenging = 8;
					SubsystemCreatureSpawn.m_areaLimitConstant = 3;
					break;
				case 2:   // Rendah
					SubsystemCreatureSpawn.m_totalLimit = 12;
					SubsystemCreatureSpawn.m_areaLimit = 2;
					SubsystemCreatureSpawn.m_totalLimitConstant = 3;
					SubsystemCreatureSpawn.m_totalLimitConstantChallenging = 6;
					SubsystemCreatureSpawn.m_areaLimitConstant = 2;
					break;
				default:  // Mati: nilai bawaan game
					SubsystemCreatureSpawn.m_totalLimit = 26;
					SubsystemCreatureSpawn.m_areaLimit = 3;
					SubsystemCreatureSpawn.m_totalLimitConstant = 6;
					SubsystemCreatureSpawn.m_totalLimitConstantChallenging = 12;
					SubsystemCreatureSpawn.m_areaLimitConstant = 4;
					break;
			}
		}

		static void ApplyDisplay(int preset)
		{
			// "Mati" tidak menyentuh pengaturan tampilan (ubah manual di Pengaturan > Performa).
			if (preset == 1)
			{
				SettingsManager.VisibilityRange = 64;
				SettingsManager.ResolutionMode = ResolutionMode.Medium;
				SettingsManager.ObjectsShadowsEnabled = false;
				SettingsManager.TerrainMipmapsEnabled = true;
				SettingsManager.SkyRenderingMode = SkyRenderingMode.Full;
				SettingsManager.MultithreadedTerrainUpdate = true;
			}
			else if (preset == 2)
			{
				SettingsManager.VisibilityRange = 48;
				SettingsManager.ResolutionMode = ResolutionMode.Low;
				SettingsManager.ObjectsShadowsEnabled = false;
				SettingsManager.TerrainMipmapsEnabled = false;
				SettingsManager.SkyRenderingMode = SkyRenderingMode.NoClouds;
				SettingsManager.MultithreadedTerrainUpdate = true;
			}
		}

		static void SetPreset(int preset)
		{
			s_preset = preset;
			s_loaded = true;
			ModsManager.SetConfig(ConfigKey, preset.ToString());
			ApplySpawnLimits(preset);
			ApplyDisplay(preset);
			SettingsManager.SaveSettings();
		}

		public override void OnSettingsScreenCreated(SettingsScreen settingsScreen, out Dictionary<ButtonWidget, Action> buttonsToAdd)
		{
			ButtonWidget button = new BevelledButtonWidget
			{
				Name = "PerfPresetButton",
				Text = ButtonText(),
				Style = ContentManager.Get<XElement>("Styles/ButtonStyle_310x60"),
				HorizontalAlignment = WidgetAlignment.Center,
				VerticalAlignment = WidgetAlignment.Center,
				Margin = new Vector2(0f, 5f)
			};
			buttonsToAdd = new Dictionary<ButtonWidget, Action>();
			buttonsToAdd.Add(button, delegate
			{
				SetPreset((CurrentPreset + 1) % Names.Length);
				button.Text = ButtonText();
			});
		}
	}
}
