// Harmony patches. The API package has no ModLoader hooks for terrain drawing / saving, and no way to stop the vanilla
// dig / interact action, so these four game methods are patched. They are looked up by name at runtime, which keeps the
// mod compiling against any API version (a missing method is logged and only that feature is lost).
using System;
using System.Reflection;
using Engine;
using HarmonyLib;
using TemplatesDatabase;

namespace Game;

public static class SubLevelPatches
{
	public static void Install()
	{
		try
		{
			Harmony harmony = new Harmony("com.mrzgaming.sublevelphysics");
			Patch(harmony, AccessTools.Method(typeof(SubsystemTerrain), "Draw", new Type[] { typeof(Camera), typeof(int) }),
				null, "DrawPostfix", "SubsystemTerrain.Draw (bodies will not be drawn)");
			Patch(harmony, AccessTools.Method(typeof(SubsystemTerrain), "Save", new Type[] { typeof(ValuesDictionary) }),
				"SavePrefix", null, "SubsystemTerrain.Save (bodies will not be put back on save)");
			Patch(harmony, AccessTools.Method(typeof(ComponentMiner), "Dig", new Type[] { typeof(TerrainRaycastResult) }),
				"DigPrefix", null, "ComponentMiner.Dig (digging through bodies)");
			Patch(harmony, AccessTools.Method(typeof(ComponentMiner), "Interact", new Type[] { typeof(TerrainRaycastResult) }),
				"InteractPrefix", null, "ComponentMiner.Interact (interacting through bodies)");
		}
		catch (Exception ex)
		{
			Log.Error("SubLevel: Harmony patching failed: " + ex);
		}
	}

	static void Patch(Harmony harmony, MethodInfo target, string prefix, string postfix, string what)
	{
		if (target == null)
		{
			Log.Error("SubLevel: method not found: " + what);
			return;
		}
		HarmonyMethod pre = (prefix != null) ? new HarmonyMethod(typeof(SubLevelPatches).GetMethod(prefix)) : null;
		HarmonyMethod post = (postfix != null) ? new HarmonyMethod(typeof(SubLevelPatches).GetMethod(postfix)) : null;
		harmony.Patch(target, pre, post);
	}

	public static void DrawPostfix(SubsystemTerrain __instance, Camera camera, int drawOrder)
	{
		SubLevelPhysicsLoader loader = SubLevelPhysicsLoader.Instance;
		if (loader != null)
		{
			loader.OnTerrainDrawHook(camera, drawOrder);
		}
	}

	public static void SavePrefix()
	{
		SubLevelPhysicsLoader loader = SubLevelPhysicsLoader.Instance;
		if (loader != null)
		{
			loader.BeforeTerrainSaveHook();
		}
	}

	public static bool DigPrefix(ComponentMiner __instance, TerrainRaycastResult raycastResult, ref bool __result)
	{
		SubLevelPhysicsLoader loader = SubLevelPhysicsLoader.Instance;
		if (loader != null && loader.ShouldSuppress(__instance, false, raycastResult.Distance))
		{
			__result = false;
			return false;
		}
		return true;
	}

	public static bool InteractPrefix(ComponentMiner __instance, TerrainRaycastResult raycastResult, ref bool __result)
	{
		SubLevelPhysicsLoader loader = SubLevelPhysicsLoader.Instance;
		if (loader != null && loader.ShouldSuppress(__instance, true, raycastResult.Distance))
		{
			__result = false;
			return false;
		}
		return true;
	}
}
