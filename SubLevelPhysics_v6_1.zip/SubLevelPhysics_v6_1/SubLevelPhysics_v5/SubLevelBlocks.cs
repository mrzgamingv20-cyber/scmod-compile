// Sub-level physics mod v5 - the mod's OWN blocks and items (no vanilla block is reused for a role any more):
//   SuperGlueBlock    item      super glue (hold it, tap two corners)
//   PhysMagnetBlock   item      magnet / push tool
//   PhysicsLeverBlock block     physics lever (tap to switch ON / OFF)
//   ShipHelmBlock     block     ship wheel (pilot seat)
//   BalloonBlock      block     balloon / lift envelope
//   ThrusterBlock     block     propeller engine (thrust)
// Textures are painted in code (no image files needed). They live in one 256x256 sheet of 16x16 tiles, the same
// slot layout the game uses for its own block atlas, so the normal cube / flat-item rendering works with it.
using System;
using System.Collections.Generic;
using Engine;
using Engine.Graphics;
using Engine.Media;

namespace Game;

public static class SubLevelTextures
{
	public const int SlotGlue = 0;
	public const int SlotMagnet = 1;
	public const int SlotLeverOff = 2;
	public const int SlotLeverOn = 3;
	public const int SlotMetal = 4;
	public const int SlotHelmTop = 5;
	public const int SlotHelmSide = 6;
	public const int SlotBalloon = 7;
	public const int SlotThrusterFront = 8;
	public const int SlotThrusterSide = 9;

	static Texture2D s_atlas;
	static readonly object s_lock = new object();

	public static Texture2D Atlas
	{
		get { return s_atlas; }
	}

	// Must be called on the main thread (blocks call it from Initialize()).
	public static void Ensure()
	{
		lock (s_lock)
		{
			if (s_atlas != null)
			{
				return;
			}
			try
			{
				Image image = new Image(256, 256);
				for (int y = 0; y < 256; y++)
				{
					for (int x = 0; x < 256; x++)
					{
						image.SetPixel(x, y, new Color((byte)0, (byte)0, (byte)0, (byte)0));
					}
				}
				Put(image, SlotGlue, PaintGlue());
				Put(image, SlotMagnet, PaintMagnet());
				Put(image, SlotLeverOff, PaintLever(false));
				Put(image, SlotLeverOn, PaintLever(true));
				Put(image, SlotMetal, PaintMetal());
				Put(image, SlotHelmTop, PaintHelmTop());
				Put(image, SlotHelmSide, PaintHelmSide());
				Put(image, SlotBalloon, PaintBalloon());
				Put(image, SlotThrusterFront, PaintThrusterFront());
				Put(image, SlotThrusterSide, PaintThrusterSide());
				s_atlas = Texture2D.Load(image, 1);
			}
			catch (Exception ex)
			{
				Log.Error("SubLevel: could not create block textures: " + ex);
			}
		}
	}

	// ---------------------------------------------------------------- painting helpers (16x16 tiles)

	static Color C(int r, int g, int b, int a = 255)
	{
		return new Color((byte)r, (byte)g, (byte)b, (byte)a);
	}

	static readonly Color Clear = new Color((byte)0, (byte)0, (byte)0, (byte)0);

	static void Put(Image image, int slot, Color[,] tile)
	{
		int ox = (slot % 16) * 16;
		int oy = (slot / 16) * 16;
		for (int y = 0; y < 16; y++)
		{
			for (int x = 0; x < 16; x++)
			{
				image.SetPixel(ox + x, oy + y, tile[x, y]);
			}
		}
	}

	static Color[,] Tile(Color fill)
	{
		Color[,] t = new Color[16, 16];
		for (int y = 0; y < 16; y++)
			for (int x = 0; x < 16; x++)
				t[x, y] = fill;
		return t;
	}

	static int Noise(int x, int y, int s)
	{
		unchecked
		{
			int h = x * 73856093 ^ y * 19349663 ^ s * 83492791;
			h ^= h >> 13;
			h *= 1274126177;
			return (h >> 8) & 255;
		}
	}

	static void Rect(Color[,] t, int x0, int y0, int x1, int y1, Color c)
	{
		for (int y = Math.Max(0, y0); y <= Math.Min(15, y1); y++)
			for (int x = Math.Max(0, x0); x <= Math.Min(15, x1); x++)
				t[x, y] = c;
	}

	static void Disc(Color[,] t, float cx, float cy, float r, Color c)
	{
		for (int y = 0; y < 16; y++)
			for (int x = 0; x < 16; x++)
			{
				float dx = x + 0.5f - cx, dy = y + 0.5f - cy;
				if (dx * dx + dy * dy <= r * r) t[x, y] = c;
			}
	}

	static void Ring(Color[,] t, float cx, float cy, float r0, float r1, Color c)
	{
		for (int y = 0; y < 16; y++)
			for (int x = 0; x < 16; x++)
			{
				float dx = x + 0.5f - cx, dy = y + 0.5f - cy;
				float d2 = dx * dx + dy * dy;
				if (d2 <= r1 * r1 && d2 >= r0 * r0) t[x, y] = c;
			}
	}

	static void Line(Color[,] t, float x0, float y0, float x1, float y1, float width, Color c)
	{
		float dx = x1 - x0, dy = y1 - y0;
		float len2 = dx * dx + dy * dy;
		for (int y = 0; y < 16; y++)
			for (int x = 0; x < 16; x++)
			{
				float px = x + 0.5f - x0, py = y + 0.5f - y0;
				float u = len2 > 0f ? (px * dx + py * dy) / len2 : 0f;
				u = Math.Max(0f, Math.Min(1f, u));
				float qx = px - u * dx, qy = py - u * dy;
				if (qx * qx + qy * qy <= width * width * 0.25f) t[x, y] = c;
			}
	}

	// dark outline inside the opaque shape edge (for flat item icons)
	static void Outline(Color[,] t, Color outline)
	{
		bool[,] edge = new bool[16, 16];
		for (int y = 0; y < 16; y++)
			for (int x = 0; x < 16; x++)
			{
				if (t[x, y].A == 0) continue;
				bool border = x == 0 || y == 0 || x == 15 || y == 15
					|| t[x - 1, y].A == 0 || t[x + 1, y].A == 0 || t[x, y - 1].A == 0 || t[x, y + 1].A == 0;
				edge[x, y] = border;
			}
		for (int y = 0; y < 16; y++)
			for (int x = 0; x < 16; x++)
				if (edge[x, y]) t[x, y] = outline;
	}

	// ---------------------------------------------------------------- the tiles

	static Color[,] PaintGlue()
	{
		Color[,] t = Tile(Clear);
		Rect(t, 5, 5, 10, 14, C(238, 236, 222));          // tube
		Rect(t, 5, 5, 6, 14, C(205, 203, 190));           // shade
		Rect(t, 5, 9, 10, 11, C(60, 120, 200));           // label
		Rect(t, 6, 2, 9, 4, C(235, 120, 30));             // cap
		Rect(t, 7, 0, 8, 1, C(190, 90, 20));              // nozzle
		Rect(t, 10, 6, 10, 8, C(255, 255, 250));          // shine
		Outline(t, C(45, 40, 40));
		return t;
	}

	static Color[,] PaintMagnet()
	{
		Color[,] t = Tile(Clear);
		Rect(t, 3, 4, 5, 12, C(150, 150, 165));
		Rect(t, 10, 4, 12, 12, C(150, 150, 165));
		Rect(t, 4, 12, 11, 14, C(150, 150, 165));
		Rect(t, 3, 2, 5, 5, C(205, 35, 35));              // red tip
		Rect(t, 10, 2, 12, 5, C(50, 90, 205));            // blue tip
		Rect(t, 3, 12, 3, 13, C(120, 120, 135));
		Rect(t, 5, 6, 5, 11, C(190, 190, 205));           // shine
		Outline(t, C(40, 40, 50));
		return t;
	}

	static Color[,] PaintMetal()
	{
		Color[,] t = Tile(C(112, 116, 126));
		for (int y = 0; y < 16; y++)
			for (int x = 0; x < 16; x++)
			{
				int n = Noise(x, y, 4) % 12 - 6;
				t[x, y] = C(112 + n, 116 + n, 126 + n);
			}
		Rect(t, 0, 0, 15, 0, C(75, 78, 88));
		Rect(t, 0, 15, 15, 15, C(75, 78, 88));
		Rect(t, 0, 0, 0, 15, C(75, 78, 88));
		Rect(t, 15, 0, 15, 15, C(75, 78, 88));
		return t;
	}

	static Color[,] PaintLever(bool on)
	{
		Color[,] t = PaintMetal();
		Rect(t, 3, 12, 12, 13, C(60, 62, 70));            // slot
		Disc(t, 8f, 11.5f, 2.2f, C(40, 42, 50));          // pivot
		float tx = on ? 12f : 4f;
		Line(t, 8f, 11.5f, tx, 4.5f, 2f, C(215, 215, 222));
		Disc(t, tx, 4.2f, 2.4f, on ? C(60, 205, 75) : C(215, 45, 45));
		Rect(t, 1, 1, 2, 2, C(185, 185, 195));           // rivets
		Rect(t, 13, 1, 14, 2, C(185, 185, 195));
		return t;
	}

	static Color[,] PaintHelmSide()
	{
		Color[,] t = Tile(C(98, 66, 38));
		for (int y = 0; y < 16; y++)
			for (int x = 0; x < 16; x++)
			{
				int n = Noise(x / 2, y, 6) % 16 - 8;
				int band = (y % 4 == 0) ? -22 : 0;
				t[x, y] = C(98 + n + band, 66 + n / 2 + band, 38 + n / 3 + band);
			}
		Rect(t, 1, 1, 2, 2, C(205, 165, 60));
		Rect(t, 13, 1, 14, 2, C(205, 165, 60));
		Rect(t, 1, 13, 2, 14, C(205, 165, 60));
		Rect(t, 13, 13, 14, 14, C(205, 165, 60));
		return t;
	}

	static Color[,] PaintHelmTop()
	{
		Color[,] t = PaintHelmSide();
		Ring(t, 8f, 8f, 4.4f, 6.4f, C(205, 160, 55));
		for (int i = 0; i < 4; i++)
		{
			double a = i * Math.PI / 4.0;
			float ex = (float)Math.Cos(a) * 6.4f, ey = (float)Math.Sin(a) * 6.4f;
			Line(t, 8f - ex, 8f - ey, 8f + ex, 8f + ey, 1.2f, C(180, 140, 45));
		}
		Disc(t, 8f, 8f, 2f, C(235, 200, 90));
		return t;
	}

	static Color[,] PaintBalloon()
	{
		Color[,] t = Tile(C(236, 226, 190));
		for (int y = 0; y < 16; y++)
			for (int x = 0; x < 16; x++)
			{
				int n = Noise(x, y, 7) % 10 - 5;
				int seam = (x % 5 == 0) ? -28 : 0;
				t[x, y] = C(236 + n + seam, 226 + n + seam, 190 + n + seam);
			}
		Rect(t, 0, 6, 15, 9, C(200, 52, 42));
		Rect(t, 0, 6, 15, 6, C(160, 35, 30));
		Rect(t, 0, 9, 15, 9, C(160, 35, 30));
		return t;
	}

	static Color[,] PaintThrusterFront()
	{
		Color[,] t = Tile(C(58, 62, 72));
		Ring(t, 8f, 8f, 6.2f, 7.6f, C(200, 202, 212));
		Disc(t, 8f, 8f, 6.0f, C(36, 38, 46));
		Line(t, 3f, 5f, 13f, 11f, 2.2f, C(225, 227, 235));
		Line(t, 3f, 11f, 13f, 5f, 2.2f, C(225, 227, 235));
		Disc(t, 8f, 8f, 1.8f, C(205, 65, 45));
		Rect(t, 0, 0, 1, 1, C(185, 185, 195));
		Rect(t, 14, 0, 15, 1, C(185, 185, 195));
		Rect(t, 0, 14, 1, 15, C(185, 185, 195));
		Rect(t, 14, 14, 15, 15, C(185, 185, 195));
		return t;
	}

	static Color[,] PaintThrusterSide()
	{
		Color[,] t = PaintMetal();
		for (int y = 3; y < 16; y += 4)
			Rect(t, 0, y, 15, y, C(82, 85, 95));
		Rect(t, 2, 1, 3, 2, C(190, 190, 200));
		Rect(t, 12, 1, 13, 2, C(190, 190, 200));
		return t;
	}
}

// ==================================================================== items

public class SuperGlueBlock : FlatBlock
{
	public static int Index = 0;

	public SuperGlueBlock()
	{
		DefaultDisplayName = "Lem Super";
		DefaultDescription = "Pegang lem ini, ketuk dua sudut untuk menyatukan semua blok di kotak itu jadi satu benda berfisika. Ketuk blok yang sama dua kali untuk semua blok yang tersambung.";
		DefaultCategory = "Tools";
		DefaultTextureSlot = SubLevelTextures.SlotGlue;
		IsPlaceable = false;
		Density = 0.5f;
		DefaultCreativeData = 0;
	}

	public override void Initialize()
	{
		base.Initialize();
		SubLevelTextures.Ensure();
	}

	public override Texture2D GetDefaultTexture(int value)
	{
		return SubLevelTextures.Atlas;
	}

	public override IEnumerable<CraftingRecipe> GetProceduralCraftingRecipes()
	{
		CraftingRecipe r = new CraftingRecipe();
		r.ResultValue = Terrain.MakeBlockValue(BlockIndex, 0, 0);
		r.ResultCount = 2;
		r.RequiredHeatLevel = 0f;
		r.Description = "Lem Super";
		r.Ingredients[0] = "sulphurchunk";
		r.Ingredients[1] = "coalchunk";
		r.Ingredients[3] = "coalchunk";
		r.Ingredients[4] = "sulphurchunk";
		yield return r;
	}
}

public class PhysMagnetBlock : FlatBlock
{
	public static int Index = 0;

	public PhysMagnetBlock()
	{
		DefaultDisplayName = "Magnet Fisika";
		DefaultDescription = "Pegang dan ketuk benda berfisika untuk menahannya di depanmu. Ketuk lagi untuk melepas. Serang benda untuk mendorongnya.";
		DefaultCategory = "Tools";
		DefaultTextureSlot = SubLevelTextures.SlotMagnet;
		IsPlaceable = false;
		Density = 1f;
		DefaultCreativeData = 0;
	}

	public override void Initialize()
	{
		base.Initialize();
		SubLevelTextures.Ensure();
	}

	public override Texture2D GetDefaultTexture(int value)
	{
		return SubLevelTextures.Atlas;
	}

	public override IEnumerable<CraftingRecipe> GetProceduralCraftingRecipes()
	{
		CraftingRecipe r = new CraftingRecipe();
		r.ResultValue = Terrain.MakeBlockValue(BlockIndex, 0, 0);
		r.ResultCount = 1;
		r.RequiredHeatLevel = 0f;
		r.Description = "Magnet Fisika";
		r.Ingredients[0] = "copperingot";
		r.Ingredients[2] = "copperingot";
		r.Ingredients[3] = "copperingot";
		r.Ingredients[5] = "copperingot";
		r.Ingredients[7] = "copperingot";
		yield return r;
	}
}

// ==================================================================== blocks

public abstract class SubLevelCubeBlock : CubeBlock
{
	public override void Initialize()
	{
		base.Initialize();
		SubLevelTextures.Ensure();
	}

	public override Texture2D GetDefaultTexture(int value)
	{
		return SubLevelTextures.Atlas;
	}
}

public class PhysicsLeverBlock : SubLevelCubeBlock
{
	public static int Index = 0;

	public PhysicsLeverBlock()
	{
		DefaultDisplayName = "Tuas Fisika";
		DefaultDescription = "Pasang di sebelah benda yang sudah dilem lalu ketuk: menyala = jadi benda berfisika, mati = dipasang kembali jadi blok.";
		DefaultCategory = "Construction";
		DefaultTextureSlot = SubLevelTextures.SlotLeverOff;
		Density = 1.5f;
		DefaultCreativeData = 0;
	}

	public static bool GetState(int value)
	{
		return (Terrain.ExtractData(value) & 1) != 0;
	}

	public static int SetState(int value, bool on)
	{
		int data = Terrain.ExtractData(value);
		return Terrain.ReplaceData(value, on ? (data | 1) : (data & ~1));
	}

	public override int GetFaceTextureSlot(int face, int value)
	{
		if (face == 5)
		{
			return SubLevelTextures.SlotMetal;
		}
		return GetState(value) ? SubLevelTextures.SlotLeverOn : SubLevelTextures.SlotLeverOff;
	}

	public override IEnumerable<CraftingRecipe> GetProceduralCraftingRecipes()
	{
		CraftingRecipe r = new CraftingRecipe();
		r.ResultValue = Terrain.MakeBlockValue(BlockIndex, 0, 0);
		r.ResultCount = 1;
		r.RequiredHeatLevel = 0f;
		r.Description = "Tuas Fisika";
		r.Ingredients[1] = "copperingot";
		r.Ingredients[4] = "wire";
		r.Ingredients[7] = "copperingot";
		yield return r;
	}
}

public class ShipHelmBlock : SubLevelCubeBlock
{
	public static int Index = 0;

	public ShipHelmBlock()
	{
		DefaultDisplayName = "Kemudi Kapal";
		DefaultDescription = "Pasang di kapal. Ketuk untuk duduk dan mengemudi (joystick maju/belok, lompat naik, jongkok turun). Kapal butuh balon dan mesin.";
		DefaultCategory = "Construction";
		DefaultTextureSlot = SubLevelTextures.SlotHelmSide;
		Density = 2f;
		DefaultCreativeData = 0;
	}

	public override int GetFaceTextureSlot(int face, int value)
	{
		return face == 4 ? SubLevelTextures.SlotHelmTop : SubLevelTextures.SlotHelmSide;
	}

	public override IEnumerable<CraftingRecipe> GetProceduralCraftingRecipes()
	{
		CraftingRecipe r = new CraftingRecipe();
		r.ResultValue = Terrain.MakeBlockValue(BlockIndex, 0, 0);
		r.ResultCount = 1;
		r.RequiredHeatLevel = 0f;
		r.Description = "Kemudi Kapal";
		for (int i = 0; i < 9; i++)
		{
			r.Ingredients[i] = (i == 4) ? "glass" : "copperingot";
		}
		yield return r;
	}
}

public class BalloonBlock : SubLevelCubeBlock
{
	public static int Index = 0;

	public BalloonBlock()
	{
		DefaultDisplayName = "Balon Pengangkat";
		DefaultDescription = "Sangat ringan. Sekitar 30% blok kapal harus balon supaya kapal bisa melayang.";
		DefaultCategory = "Construction";
		DefaultTextureSlot = SubLevelTextures.SlotBalloon;
		Density = 0.2f;
		DefaultCreativeData = 0;
	}

	public override int GetFaceTextureSlot(int face, int value)
	{
		return SubLevelTextures.SlotBalloon;
	}

	public override IEnumerable<CraftingRecipe> GetProceduralCraftingRecipes()
	{
		CraftingRecipe r = new CraftingRecipe();
		r.ResultValue = Terrain.MakeBlockValue(BlockIndex, 0, 0);
		r.ResultCount = 2;
		r.RequiredHeatLevel = 0f;
		r.Description = "Balon Pengangkat";
		r.Ingredients[0] = "canvas";
		r.Ingredients[1] = "canvas";
		r.Ingredients[3] = "canvas";
		r.Ingredients[4] = "canvas";
		yield return r;
	}
}

public class ThrusterBlock : SubLevelCubeBlock
{
	public static int Index = 0;

	public ThrusterBlock()
	{
		DefaultDisplayName = "Mesin Baling-baling";
		DefaultDescription = "Memberi dorongan maju untuk kapal. Sekitar 6% blok kapal harus mesin untuk dorongan penuh.";
		DefaultCategory = "Construction";
		DefaultTextureSlot = SubLevelTextures.SlotThrusterSide;
		Density = 3f;
		DefaultCreativeData = 0;
	}

	public override int GetFaceTextureSlot(int face, int value)
	{
		return (face == 0 || face == 2) ? SubLevelTextures.SlotThrusterFront : SubLevelTextures.SlotThrusterSide;
	}

	public override IEnumerable<CraftingRecipe> GetProceduralCraftingRecipes()
	{
		CraftingRecipe r = new CraftingRecipe();
		r.ResultValue = Terrain.MakeBlockValue(BlockIndex, 0, 0);
		r.ResultCount = 1;
		r.RequiredHeatLevel = 0f;
		r.Description = "Mesin Baling-baling";
		r.Ingredients[1] = "copperingot";
		r.Ingredients[3] = "copperingot";
		r.Ingredients[4] = "coalchunk";
		r.Ingredients[5] = "copperingot";
		r.Ingredients[7] = "copperingot";
		yield return r;
	}
}
