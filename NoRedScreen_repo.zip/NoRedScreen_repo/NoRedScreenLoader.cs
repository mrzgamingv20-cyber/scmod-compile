// NoRedScreen mod: layar pemain tidak memerah saat terkena damage.
// ComponentHealth.Update memanggil hook ChangeVisualEffectOnInjury setelah menghitung efek merah;
// kita set redScreenFactor = 0 khusus pemain. Suara sakit, kedip bar nyawa, dan warna merah model tidak diubah.
using Engine;

namespace Game
{
	public class NoRedScreenLoader : ModLoader
	{
		public override void __ModInitialize()
		{
			ModsManager.RegisterHook("ChangeVisualEffectOnInjury", this);
		}

		public override void ChangeVisualEffectOnInjury(ComponentHealth componentHealth, float lastHealth, ref float redScreenFactor, ref bool playPainSound, ref int healthBarFlashCount, ref float creatureModelRedFactor)
		{
			if (componentHealth != null && componentHealth.m_componentPlayer != null)
			{
				redScreenFactor = 0f;
			}
		}
	}
}
