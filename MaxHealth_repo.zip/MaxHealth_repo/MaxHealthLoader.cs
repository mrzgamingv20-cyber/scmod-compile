// MaxHealth mod: nyawa semua pemain bisa diatur 1-500 HP (20 = normal).
// Damage ke pemain dikali 20 / nyawa. Pengaturan lewat tombol di layar Pengaturan.
using System;
using System.Collections.Generic;
using System.Xml.Linq;
using Engine;

namespace Game
{
	public class MaxHealthLoader : ModLoader
	{
		public const string ConfigKey = "com.mrzgaming.maxhealth.MaxHP";
		public const int BaselineHp = 20;   // nyawa game normal
		public const int MinHp = 1;
		public const int MaxHp = 500;
		public const int DefaultHp = 100;

		static int s_hp = DefaultHp;
		static bool s_loaded;

		public static int CurrentHp
		{
			get
			{
				if (!s_loaded)
				{
					s_hp = ReadConfig();
					s_loaded = true;
				}
				return s_hp;
			}
		}

		static int ReadConfig()
		{
			string text;
			int value;
			if (ModsManager.Configs.TryGetValue(ConfigKey, out text) && int.TryParse(text, out value))
			{
				return Math.Clamp(value, MinHp, MaxHp);
			}
			return DefaultHp;
		}

		static void SetHp(int value)
		{
			s_hp = Math.Clamp(value, MinHp, MaxHp);
			s_loaded = true;
			ModsManager.SetConfig(ConfigKey, s_hp.ToString());
			SettingsManager.SaveSettings();
		}

		static string ButtonText()
		{
			return "Nyawa Pemain: " + CurrentHp + " HP";
		}

		public override void __ModInitialize()
		{
			ModsManager.RegisterHook("CalculateCreatureInjuryAmount", this);
			ModsManager.RegisterHook("OnSettingsScreenCreated", this);
		}

		// Dipanggil untuk setiap Injury sebelum nyawa dikurangi.
		public override void CalculateCreatureInjuryAmount(Injury injury)
		{
			if (injury == null || injury.Amount <= 0f)
			{
				return;
			}
			ComponentHealth health = injury.ComponentHealth;
			if (health == null || health.m_componentPlayer == null)
			{
				return; // hanya pemain; mob tidak berubah
			}
			injury.Amount *= (float)BaselineHp / CurrentHp;
		}

		public override void OnSettingsScreenCreated(SettingsScreen settingsScreen, out Dictionary<ButtonWidget, Action> buttonsToAdd)
		{
			ButtonWidget button = new BevelledButtonWidget
			{
				Name = "MaxHealthButton",
				Text = ButtonText(),
				Style = ContentManager.Get<XElement>("Styles/ButtonStyle_310x60"),
				HorizontalAlignment = WidgetAlignment.Center,
				VerticalAlignment = WidgetAlignment.Center,
				Margin = new Vector2(0f, 5f)
			};
			buttonsToAdd = new Dictionary<ButtonWidget, Action>();
			buttonsToAdd.Add(button, delegate { ShowInput(button); });
		}

		static void ShowInput(ButtonWidget button)
		{
			DialogsManager.ShowDialog(null, new TextBoxDialog("Nyawa pemain (1-500, 20 = normal)", CurrentHp.ToString(), 3, delegate (string text)
			{
				int value;
				if (string.IsNullOrWhiteSpace(text) || !int.TryParse(text.Trim(), out value))
				{
					return; // dibatalkan / bukan angka: nilai lama tetap
				}
				SetHp(value);
				button.Text = ButtonText();
			}));
		}
	}
}
