using System;
using System.Collections.Generic;
using Engine;
using Game;

// SkyShip - kapal terbang untuk Survivalcraft (API 1.9).
//
// CARA PAKAI
//  1. Bangun kapal dari blok apa saja, SATU struktur yang terhubung (sisi-ke-sisi), dan JANGAN menyentuh tanah/terrain alami.
//  2. Pasang 1 "kemudi" = blok BESI (IronBlock) di kapal.
//  3. Pasang blok pengangkat (CANVAS/kain) dan mesin (PAGAR BESI). Banyak lift = bisa naik, banyak mesin = lebih cepat.
//  4. Tangan kosong, tap blok besi di tanah  -> kapal dirakit jadi satu benda yang melayang.
//  5. Tap blok besi lagi (di kapal)          -> mulai mengemudi. Tap lagi -> lepas kemudi (kapal diam di udara).
//  6. Mengemudi: joystick = maju/mundur/geser (arah mengikuti arah pandang), tombol lompat = naik, jongkok = turun.
//  7. Mendarat: berjongkok lalu tap blok besi -> kapal diubah kembali jadi blok biasa di posisi sekarang.
//
// Konstanta di SkyShipConfig bisa diubah. Nama blok dicocokkan lewat nama kelas (GetType().Name).
namespace SkyShip
{
	public static class SkyShipConfig
	{
		public const string SetId = "SkyShip";
		public static readonly string HelmBlock = "IronBlock";
		public static readonly string LiftBlock = "CanvasBlock";
		public static readonly string EngineBlock = "IronFenceBlock";

		public const int MaxBlocks = 400;
		public const float LiftPerBlock = 4f;     // kapal bisa naik/melayang bila lift*LiftPerBlock >= jumlah blok
		public const float EnginePerBlock = 6f;   // kecepatan penuh bila mesin*EnginePerBlock >= jumlah blok
		public const float MaxSpeed = 6f;         // blok/detik
		public const float ClimbSpeed = 3f;
		public const float SinkSpeed = 4f;        // kecepatan jatuh bila lift tidak cukup
		public const float Accel = 1.5f;

		// Blok alam yang TIDAK ikut dirakit.
		public static readonly HashSet<string> NaturalBlocks = new HashSet<string>
		{
			"BasaltBlock", "DirtBlock", "GrassBlock", "SandBlock", "GravelBlock", "SandstoneBlock", "LimestoneBlock",
			"ClayBlock", "SnowBlock", "IceBlock", "MagmaBlock", "WaterBlock", "BedrockBlock", "BoulderBlock",
			"LeavesBlock", "WoodBlock", "TallGrassBlock", "FlowerBlock", "MossBlock", "PeatBlock", "MycelBlock"
		};
	}

	class Ship
	{
		public ComponentPlayer Pilot;
		public Vector3 Velocity;
		public Vector3 Input;          // arah yang diminta pilot (dunia), panjang <= 1
		public float InputVertical;    // -1..1
		public double InputTime;
		public int CountedBlocks = -1;
		public int Lift, Engines, Total;
		public Point3 Helm;            // offset kemudi
		public bool HasHelm;
	}

	public class SkyShipLoader : ModLoader
	{
		SubsystemMovingBlocks m_mb;
		SubsystemTerrain m_terrain;
		SubsystemTime m_time;
		readonly Dictionary<IMovingBlockSet, Ship> m_ships = new Dictionary<IMovingBlockSet, Ship>();

		public override void __ModInitialize()
		{
			ModsManager.RegisterHook("OnProjectLoaded", this);
			ModsManager.RegisterHook("OnProjectDisposed", this);
			ModsManager.RegisterHook("OnMovingBlockSetUpdate", this);
			ModsManager.RegisterHook("OnPlayerInputInteract", this);
			ModsManager.RegisterHook("OnPlayerControlWalk", this);
		}

		public override void OnProjectLoaded(Project project)
		{
			m_mb = project.FindSubsystem<SubsystemMovingBlocks>(true);
			m_terrain = project.FindSubsystem<SubsystemTerrain>(true);
			m_time = project.FindSubsystem<SubsystemTime>(true);
			m_ships.Clear();
		}

		public override void OnProjectDisposed()
		{
			m_mb = null; m_terrain = null; m_time = null;
			m_ships.Clear();
		}

		// ------------------------------------------------------------ util blok

		static string NameOf(int value)
		{
			return BlocksManager.Blocks[Terrain.ExtractContents(value)].GetType().Name;
		}

		static bool IsNatural(int value)
		{
			string n = NameOf(value);
			return SkyShipConfig.NaturalBlocks.Contains(n) || n.Contains("Water") || n.Contains("Magma");
		}

		Ship GetShip(IMovingBlockSet set)
		{
			Ship s;
			if (!m_ships.TryGetValue(set, out s))
			{
				s = new Ship();
				m_ships[set] = s;
			}
			if (s.CountedBlocks != set.Blocks.Count)
			{
				s.CountedBlocks = set.Blocks.Count;
				s.Lift = 0; s.Engines = 0; s.Total = set.Blocks.Count; s.HasHelm = false;
				for (int i = 0; i < set.Blocks.Count; i++)
				{
					string n = NameOf(set.Blocks[i].Value);
					if (n == SkyShipConfig.LiftBlock) s.Lift++;
					else if (n == SkyShipConfig.EngineBlock) s.Engines++;
					else if (n == SkyShipConfig.HelmBlock && !s.HasHelm) { s.Helm = set.Blocks[i].Offset; s.HasHelm = true; }
				}
			}
			return s;
		}

		static void Msg(ComponentPlayer p, string text)
		{
			try { p.ComponentGui.DisplaySmallMessage(text, Color.White, true, false); } catch { }
		}

		// ------------------------------------------------------------ interaksi

		public override void OnPlayerInputInteract(ComponentPlayer cp, ref bool playerOperated, ref double timeIntervalLastActionTime, ref int priorityUse, ref int priorityInteract, ref int priorityPlace)
		{
			if (playerOperated || m_mb == null) return;
			PlayerInput input = cp.ComponentInput.PlayerInput;
			if (!input.Interact.HasValue) return;
			if (cp.ComponentMiner.ActiveBlockValue != 0) return; // tangan harus kosong
			try
			{
				MovingBlocksRaycastResult? mr = cp.ComponentMiner.Raycast<MovingBlocksRaycastResult>(input.Interact.Value, RaycastMode.Interaction);
				if (mr.HasValue && mr.Value.MovingBlock != null)
				{
					IMovingBlockSet set = mr.Value.MovingBlockSet;
					if (set != null && set.Id == SkyShipConfig.SetId && NameOf(mr.Value.MovingBlock.Value) == SkyShipConfig.HelmBlock)
					{
						playerOperated = true;
						timeIntervalLastActionTime = 0.6;
						OnHelmUsed(cp, set);
					}
					return;
				}
				TerrainRaycastResult? tr = cp.ComponentMiner.Raycast<TerrainRaycastResult>(input.Interact.Value, RaycastMode.Interaction);
				if (tr.HasValue && NameOf(tr.Value.Value) == SkyShipConfig.HelmBlock)
				{
					playerOperated = true;
					timeIntervalLastActionTime = 0.6;
					Assemble(cp, new Point3(tr.Value.CellFace.X, tr.Value.CellFace.Y, tr.Value.CellFace.Z));
				}
			}
			catch (Exception ex)
			{
				Log.Error("SkyShip: interact failed: " + ex);
			}
		}

		void OnHelmUsed(ComponentPlayer cp, IMovingBlockSet set)
		{
			Ship ship = GetShip(set);
			if (ship.Pilot == cp)
			{
				if (cp.ComponentBody.IsCrouching)
				{
					Land(cp, set, ship);
				}
				else
				{
					ship.Pilot = null;
					Msg(cp, "Kemudi dilepas. Kapal melayang diam.");
				}
			}
			else if (ship.Pilot != null)
			{
				Msg(cp, "Kapal sedang dikemudikan pemain lain.");
			}
			else
			{
				ship.Pilot = cp;
				Msg(cp, ship.Lift * SkyShipConfig.LiftPerBlock >= ship.Total
					? "Mengemudi: joystick = maju, lompat = naik, jongkok = turun. Jongkok + tap kemudi = mendarat."
					: "Lift kurang! Kapal tidak bisa naik (lift " + ship.Lift + ", perlu " + (int)Math.Ceiling(ship.Total / SkyShipConfig.LiftPerBlock) + ").");
			}
		}

		// ------------------------------------------------------------ rakit

		void Assemble(ComponentPlayer cp, Point3 helm)
		{
			Terrain terrain = m_terrain.Terrain;
			List<Point3> cells = new List<Point3>();
			HashSet<Point3> seen = new HashSet<Point3>();
			Queue<Point3> queue = new Queue<Point3>();
			queue.Enqueue(helm); seen.Add(helm);
			Point3[] dirs = { new Point3(1, 0, 0), new Point3(-1, 0, 0), new Point3(0, 1, 0), new Point3(0, -1, 0), new Point3(0, 0, 1), new Point3(0, 0, -1) };
			while (queue.Count > 0)
			{
				Point3 c = queue.Dequeue();
				cells.Add(c);
				if (cells.Count > SkyShipConfig.MaxBlocks)
				{
					Msg(cp, "Kapal terlalu besar atau menempel ke tanah (maks " + SkyShipConfig.MaxBlocks + " blok). Beri celah udara dari tanah.");
					return;
				}
				for (int d = 0; d < dirs.Length; d++)
				{
					Point3 n = new Point3(c.X + dirs[d].X, c.Y + dirs[d].Y, c.Z + dirs[d].Z);
					if (n.Y < 1 || n.Y > 254 || seen.Contains(n)) continue;
					int v = terrain.GetCellValueFast(n.X, n.Y, n.Z);
					if (Terrain.ExtractContents(v) == 0 || IsNatural(v)) continue;
					seen.Add(n);
					queue.Enqueue(n);
				}
			}

			int lift = 0;
			List<MovingBlock> blocks = new List<MovingBlock>();
			for (int i = 0; i < cells.Count; i++)
			{
				Point3 c = cells[i];
				int v = terrain.GetCellValueFast(c.X, c.Y, c.Z);
				if (NameOf(v) == SkyShipConfig.LiftBlock) lift++;
				blocks.Add(new MovingBlock { Offset = new Point3(c.X - helm.X, c.Y - helm.Y, c.Z - helm.Z), Value = v });
			}
			if (lift == 0)
			{
				Msg(cp, "Butuh minimal 1 blok pengangkat (canvas) yang tersambung ke kemudi.");
				return;
			}

			Vector3 pos = new Vector3(helm.X, helm.Y, helm.Z);
			IMovingBlockSet set = m_mb.AddMovingBlockSet(pos, pos, 0f, 0f, 0f, new Vector2(0f), blocks, SkyShipConfig.SetId, null, false);
			if (set == null)
			{
				Msg(cp, "Gagal merakit kapal.");
				return;
			}
			for (int i = 0; i < blocks.Count; i++)
			{
				m_terrain.ChangeCell(helm.X + blocks[i].Offset.X, helm.Y + blocks[i].Offset.Y, helm.Z + blocks[i].Offset.Z, 0, true, blocks[i]);
			}
			Ship ship = GetShip(set);
			Msg(cp, "Kapal dirakit: " + blocks.Count + " blok, lift " + ship.Lift + ", mesin " + ship.Engines + ". Tap kemudi untuk mengemudi.");
		}

		// ------------------------------------------------------------ mendarat

		void Land(ComponentPlayer cp, IMovingBlockSet set, Ship ship)
		{
			Vector3 p = set.Position;
			Point3 o = new Point3((int)Math.Round(p.X), (int)Math.Round(p.Y), (int)Math.Round(p.Z));
			Terrain terrain = m_terrain.Terrain;
			List<MovingBlock> blocks = new List<MovingBlock>(set.Blocks);
			for (int i = 0; i < blocks.Count; i++)
			{
				int x = o.X + blocks[i].Offset.X, y = o.Y + blocks[i].Offset.Y, z = o.Z + blocks[i].Offset.Z;
				if (y < 1 || y > 254) { Msg(cp, "Tidak bisa mendarat di ketinggian ini."); return; }
				int v = terrain.GetCellValueFast(x, y, z);
				if (Terrain.ExtractContents(v) != 0 && BlocksManager.Blocks[Terrain.ExtractContents(v)].IsCollidable_(v))
				{
					Msg(cp, "Tempat mendarat terhalang. Geser kapal sedikit.");
					return;
				}
			}
			ship.Pilot = null;
			for (int i = 0; i < blocks.Count; i++)
			{
				m_mb.AddTerrainBlock(o.X + blocks[i].Offset.X, o.Y + blocks[i].Offset.Y, o.Z + blocks[i].Offset.Z, blocks[i].Value, blocks[i]);
			}
			m_mb.RemoveMovingBlockSet(set);
			m_ships.Remove(set);
			Msg(cp, "Kapal mendarat.");
		}

		// ------------------------------------------------------------ input pilot (layar sentuh / joystick)

		public override void OnPlayerControlWalk(ComponentPlayer cp, bool skippedByOtherMods, out bool skipVanilla)
		{
			skipVanilla = false;
			if (m_ships.Count == 0) return;
			Ship mine = null;
			foreach (KeyValuePair<IMovingBlockSet, Ship> kv in m_ships)
			{
				if (kv.Value.Pilot == cp) { mine = kv.Value; break; }
			}
			if (mine == null) return;
			skipVanilla = true;

			PlayerInput pi = cp.ComponentInput.PlayerInput;
			Vector3 f = cp.ComponentBody.Matrix.Forward;
			f.Y = 0f;
			if (f.LengthSquared() < 1e-6f) f = new Vector3(0f, 0f, -1f);
			f = Vector3.Normalize(f);
			Vector3 r = new Vector3(-f.Z, 0f, f.X);
			Vector3 h = f * pi.Move.Z + r * pi.Move.X;
			if (h.LengthSquared() > 1f) h = Vector3.Normalize(h);
			float v = (pi.Jump ? 1f : 0f) + pi.Move.Y;
			if (cp.ComponentBody.IsCrouching) v -= 1f;
			mine.Input = h;
			mine.InputVertical = MathUtils.Clamp(v, -1f, 1f);
			mine.InputTime = m_time.GameTime;
		}

		// ------------------------------------------------------------ fisika kapal

		bool Collides(IMovingBlockSet set, Vector3 pos)
		{
			Terrain terrain = m_terrain.Terrain;
			const float e = 0.02f;
			List<MovingBlock> blocks = set.Blocks;
			for (int i = 0; i < blocks.Count; i++)
			{
				Point3 o = blocks[i].Offset;
				float minX = pos.X + o.X + e, minY = pos.Y + o.Y + e, minZ = pos.Z + o.Z + e;
				int x0 = (int)Math.Floor(minX), x1 = (int)Math.Floor(minX + 1f - 2f * e);
				int y0 = (int)Math.Floor(minY), y1 = (int)Math.Floor(minY + 1f - 2f * e);
				int z0 = (int)Math.Floor(minZ), z1 = (int)Math.Floor(minZ + 1f - 2f * e);
				if (y0 < 0 || y1 > 255) return true;
				for (int x = x0; x <= x1; x++)
					for (int y = y0; y <= y1; y++)
						for (int z = z0; z <= z1; z++)
						{
							int v = terrain.GetCellValueFast(x, y, z);
							int c = Terrain.ExtractContents(v);
							if (c != 0 && BlocksManager.Blocks[c].IsCollidable_(v)) return true;
						}
			}
			return false;
		}

		public override void OnMovingBlockSetUpdate(IMovingBlockSet movingBlockSet, SubsystemMovingBlocks subsystemMovingBlocks, bool skippedByOtherMods, out bool skipVanilla)
		{
			skipVanilla = false;
			if (movingBlockSet.Id != SkyShipConfig.SetId) return;
			skipVanilla = true;
			SubsystemMovingBlocks.MovingBlockSet set = movingBlockSet as SubsystemMovingBlocks.MovingBlockSet;
			if (set == null || m_terrain == null) return;
			try
			{
				float dt = m_time.GameTimeDelta;
				if (dt <= 0f) return;
				TerrainChunk chunk = m_terrain.Terrain.GetChunkAtCell(Terrain.ToCell(set.Position.X), Terrain.ToCell(set.Position.Z));
				if (chunk == null || chunk.State <= TerrainChunkState.InvalidContents4)
				{
					set.CurrentVelocity = Vector3.Zero;
					return;
				}
				Ship ship = GetShip(set);

				if (ship.Pilot != null)
				{
					bool bad = ship.Pilot.ComponentHealth.Health <= 0f
						|| Vector3.DistanceSquared(ship.Pilot.ComponentBody.Position, set.Position) > 40f * 40f;
					if (bad) ship.Pilot = null;
				}

				float total = Math.Max(1, ship.Total);
				float liftRatio = ship.Lift * SkyShipConfig.LiftPerBlock / total;
				float engineRatio = MathUtils.Saturate(ship.Engines * SkyShipConfig.EnginePerBlock / total);
				bool fresh = ship.Pilot != null && m_time.GameTime - ship.InputTime < 0.25;

				Vector3 target = Vector3.Zero;
				if (fresh)
				{
					target = ship.Input * (SkyShipConfig.MaxSpeed * engineRatio);
					if (ship.InputVertical > 0f && liftRatio >= 1f) target.Y = SkyShipConfig.ClimbSpeed;
					else if (ship.InputVertical < 0f) target.Y = -SkyShipConfig.ClimbSpeed;
				}
				if (liftRatio < 1f && target.Y > -SkyShipConfig.SinkSpeed * (1f - liftRatio) && !(fresh && ship.InputVertical < 0f))
				{
					target.Y = -SkyShipConfig.SinkSpeed * (1f - liftRatio);
				}

				ship.Velocity += (target - ship.Velocity) * Math.Min(1f, SkyShipConfig.Accel * dt);
				Vector3 d = ship.Velocity * dt;
				Vector3 pos = set.Position;
				if (d.X != 0f) { Vector3 t = new Vector3(pos.X + d.X, pos.Y, pos.Z); if (Collides(set, t)) ship.Velocity.X = 0f; else pos = t; }
				if (d.Y != 0f) { Vector3 t = new Vector3(pos.X, pos.Y + d.Y, pos.Z); if (Collides(set, t)) ship.Velocity.Y = 0f; else pos = t; }
				if (d.Z != 0f) { Vector3 t = new Vector3(pos.X, pos.Y, pos.Z + d.Z); if (Collides(set, t)) ship.Velocity.Z = 0f; else pos = t; }

				set.Position = pos;
				set.StartPosition = pos;
				set.TargetPosition = pos;
				set.Speed = 0f;
				set.CurrentVelocity = ship.Velocity;
				set.UpdateBox();
			}
			catch (Exception ex)
			{
				Log.Error("SkyShip: update failed: " + ex);
			}
		}
	}
}
