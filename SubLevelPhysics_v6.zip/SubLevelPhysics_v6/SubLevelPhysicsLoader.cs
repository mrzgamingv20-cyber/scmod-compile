// Sub-level physics mod for Survivalcraft 2.4.0.0 (API 1.9.5.1) - Sable / Create Aeronautics style.
//
//  Super glue (cotton wad): tap one corner block, then the opposite corner -> every glue-able block in that box becomes one group.
//  Lever (switch):          place it next to a glued block; switching it ON turns the group into a physics body (it moves, falls,
//                           tumbles). Tap the lever on the moving body to park it: the blocks are put back into the terrain.
//  Bodies stay usable:      you can dig their blocks (they drop items, the body is rebuilt) and tap the helm / lever.
//  Magnet:                  tap = grab a body and carry it where you look (tap again to release); attack = push it away.
//  Airship:                 a body with canvas (balloon) and furnace (engine) blocks flies when you tap its helm
//                           (crafting table): joystick = move/turn, Jump = rise, Crouch = leave the helm.
//  Trees:                   a felled tree pivots about its stump and topples away from you (no glue needed).
#pragma warning disable CS0672 // the obsolete SubsystemUpdate overload is still called by the game
using System;
using System.Collections.Generic;
using Engine;
using Engine.Graphics;
using GameEntitySystem;

namespace Game;

public sealed class GrabInfo
{
	public SubLevel Level;
	public PVec3 Local;        // grabbed point in the body's local space
	public float Distance;     // distance in front of the eyes where the point is held
}

public sealed class PlayerState
{
	public bool GlueHasFirst;
	public Point3 GlueFirst;
	public double LastActionTime;
	public double LastPushTime;
	public SubLevel DigLevel;
	public int DigIndex;
	public float DigProgress;
	public GrabInfo Grab;
}

public partial class SubLevelPhysicsLoader : ModLoader, IPhysWorld
{
	public static SubLevelPhysicsLoader Instance;

	SubsystemTerrain m_subsystemTerrain;
	Terrain m_terrain;
	SubsystemPickables m_subsystemPickables;
	SubsystemBlockBehaviors m_subsystemBlockBehaviors;
	SubsystemTime m_subsystemTime;
	SubsystemPlayers m_subsystemPlayers;
	SubsystemGameInfo m_subsystemGameInfo;

	readonly List<SubLevel> m_levels = new List<SubLevel>();
	readonly Dictionary<ComponentPlayer, PlayerState> m_players = new Dictionary<ComponentPlayer, PlayerState>();
	readonly Dictionary<Point3, bool> m_leverState = new Dictionary<Point3, bool>();
	readonly GlueStore m_glue = new GlueStore();
	readonly List<BlockDropValue> m_dropValues = new List<BlockDropValue>();
	PrimitivesRenderer3D m_renderer;
	DrawBlockEnvironmentData m_env;
	bool m_drawErrorLogged;
	bool m_updateErrorLogged;
	double m_nextLeverPoll;

	static readonly Point3[] Dirs6 =
	{
		new Point3(0, 1, 0), new Point3(1, 0, 0), new Point3(-1, 0, 0),
		new Point3(0, 0, 1), new Point3(0, 0, -1), new Point3(0, -1, 0)
	};

	public override void __ModInitialize()
	{
		ModsManager.RegisterHook("OnProjectLoaded", this);
		ModsManager.RegisterHook("OnProjectDisposed", this);
		ModsManager.RegisterHook("OnBlockDug", this);
		ModsManager.RegisterHook("SubsystemUpdate", this);
		Instance = this;
		SubLevelPatches.Install();
	}

	public override void OnProjectLoaded(Project project)
	{
		m_levels.Clear();
		m_players.Clear();
		m_leverState.Clear();
		m_glue.Clear();
		m_subsystemTerrain = project.FindSubsystem<SubsystemTerrain>(true);
		m_terrain = m_subsystemTerrain.Terrain;
		m_subsystemPickables = project.FindSubsystem<SubsystemPickables>(true);
		m_subsystemBlockBehaviors = project.FindSubsystem<SubsystemBlockBehaviors>(true);
		m_subsystemTime = project.FindSubsystem<SubsystemTime>(true);
		m_subsystemPlayers = project.FindSubsystem<SubsystemPlayers>(true);
		m_subsystemGameInfo = project.FindSubsystem<SubsystemGameInfo>(true);
		m_riders.Clear();
		LoadGlue();
	}

	public override void OnProjectDisposed()
	{
		m_levels.Clear();
		m_players.Clear();
		m_leverState.Clear();
		m_glue.Clear();
		m_subsystemTerrain = null;
		m_terrain = null;
		m_subsystemPickables = null;
		m_subsystemBlockBehaviors = null;
		m_subsystemTime = null;
		m_subsystemPlayers = null;
		m_subsystemGameInfo = null;
		m_riders.Clear();
	}

	// IPhysWorld
	public bool IsSolid(int x, int y, int z)
	{
		if (y < 0)
		{
			return true;
		}
		if (y > 255)
		{
			return false;
		}
		return StructureScanner.IsSolid(m_terrain.GetCellValue(x, y, z));
	}

	static void Say(ComponentPlayer player, string text)
	{
		if (player != null && player.ComponentGui != null)
		{
			player.ComponentGui.DisplaySmallMessage(text, Color.White, true, false);
		}
	}

	static PVec3 Normalized(PVec3 v)
	{
		float l = v.Length;
		return (l < 1e-6f) ? new PVec3(0f, 0f, 1f) : v * (1f / l);
	}

	// ---------------------------------------------------------------- glue persistence

	static string GluePath()
	{
		if (GameManager.WorldInfo == null)
		{
			return null;
		}
		return Storage.CombinePaths(GameManager.WorldInfo.DirectoryName, "SubLevelGlue.txt");
	}

	void LoadGlue()
	{
		try
		{
			string path = GluePath();
			if (path != null && Storage.FileExists(path))
			{
				m_glue.Deserialize(Storage.ReadAllText(path));
			}
		}
		catch (Exception ex)
		{
			Log.Error("SubLevel: could not load glue groups: " + ex);
		}
	}

	void SaveGlue()
	{
		try
		{
			string path = GluePath();
			if (path != null)
			{
				Storage.WriteAllText(path, m_glue.Serialize());
			}
		}
		catch (Exception ex)
		{
			Log.Error("SubLevel: could not save glue groups: " + ex);
		}
	}

	// ---------------------------------------------------------------- digging a block next to a tree / a glued block

	public override void OnBlockDug(ComponentMiner componentMiner, BlockPlacementData digValue, int cellValue, ref int durabilityReduction, ref bool mute, ref int playerDataDugAdd)
	{
		if (m_subsystemTerrain == null)
		{
			return;
		}
		try
		{
			Point3 dug = new Point3(digValue.CellFace.X, digValue.CellFace.Y, digValue.CellFace.Z);
			if (m_glue.Find(dug) != null)
			{
				m_glue.RemoveCell(dug);
				SaveGlue();
			}
			if (SubLevelConfig.AutoTrees)
			{
				CheckTrees(componentMiner, dug);
			}
		}
		catch (Exception ex)
		{
			Log.Error("SubLevel: dig handling failed: " + ex);
		}
	}

	void CheckTrees(ComponentMiner miner, Point3 dug)
	{
		HashSet<Point3> claimed = new HashSet<Point3>();
		for (int s = 0; s < Dirs6.Length; s++)
		{
			if (m_levels.Count >= SubLevelConfig.MaxBodies)
			{
				return;
			}
			Point3 seed = new Point3(dug.X + Dirs6[s].X, dug.Y + Dirs6[s].Y, dug.Z + Dirs6[s].Z);
			if (claimed.Contains(seed) || m_glue.Find(seed) != null)
			{
				continue;
			}
			if (!StructureScanner.IsLog(m_terrain.GetCellValue(seed.X, seed.Y, seed.Z)))
			{
				continue;
			}
			List<Point3> cells;
			int nonLeaf;
			bool treeLike;
			bool anchored;
			if (!StructureScanner.Scan(m_terrain, seed, claimed, out cells, out nonLeaf, out treeLike, out anchored) || anchored || !treeLike)
			{
				continue;
			}
			SubLevel level = CreateBody(cells, dug);
			level.TreeMode = true;
			SetupTree(level, cells, nonLeaf, dug, miner);
			RemoveFromTerrain(level);
			m_levels.Add(level);
		}
	}

	// A felled tree pivots about the back edge of its lowest log (pin joint) and is pushed away from the player.
	void SetupTree(SubLevel level, List<Point3> cells, int nonLeaf, Point3 dug, ComponentMiner miner)
	{
		Point3 baseCell = cells[0];
		long bestScore = long.MaxValue;
		for (int i = 0; i < nonLeaf; i++)
		{
			long dx = cells[i].X - dug.X;
			long dz = cells[i].Z - dug.Z;
			long score = (long)cells[i].Y * 100000L + dx * dx + dz * dz;
			if (score < bestScore)
			{
				bestScore = score;
				baseCell = cells[i];
			}
		}

		Vector3 pp = miner.ComponentCreature.ComponentBody.Position;
		float ddx = baseCell.X + 0.5f - pp.X;
		float ddz = baseCell.Z + 0.5f - pp.Z;
		float dirX = 0f;
		float dirZ = 0f;
		if (MathF.Abs(ddx) >= MathF.Abs(ddz))
		{
			dirX = (ddx >= 0f) ? 1f : -1f;
		}
		else
		{
			dirZ = (ddz >= 0f) ? 1f : -1f;
		}

		int hy = baseCell.Y;
		bool found = false;
		for (int k = 0; k < 5; k++)
		{
			if (IsSolid(baseCell.X, hy - 1, baseCell.Z))
			{
				found = true;
				break;
			}
			hy--;
		}
		RigidBody3D body = level.Body;
		PVec3 axis = new PVec3(dirZ, 0f, -dirX);   // up x dir: the top of the tree moves along dir
		body.AngularVelocity = axis * SubLevelConfig.TreeKick;
		if (found)
		{
			PVec3 hinge = new PVec3(baseCell.X + 0.5f - dirX * 0.5f, hy, baseCell.Z + 0.5f - dirZ * 0.5f);
			body.PinEnabled = true;
			body.PinWorld = hinge;
			body.PinLocal = hinge - body.CenterOfMass;
			body.Velocity = PVec3.Cross(body.AngularVelocity, body.CenterOfMass - hinge);
		}
	}

	// ---------------------------------------------------------------- bodies

	// Builds the rigid body for blocks that are still in the terrain (they are lifted out by RemoveFromTerrain).
	SubLevel CreateBody(List<Point3> cells, Point3 climateCell)
	{
		int count = cells.Count;
		SubLevel level = new SubLevel();
		level.Count = count;
		level.Values = new int[count];
		level.Cx = new int[count];
		level.Cy = new int[count];
		level.Cz = new int[count];
		level.Mass = new float[count];
		for (int i = 0; i < count; i++)
		{
			Point3 p = cells[i];
			int v = m_terrain.GetCellValue(p.X, p.Y, p.Z);
			level.Values[i] = v;
			level.Cx[i] = p.X;
			level.Cy[i] = p.Y;
			level.Cz[i] = p.Z;
			level.Mass[i] = Math.Max(0.1f, BlocksManager.Blocks[Terrain.ExtractContents(v)].GetDensity(v));
		}
		level.Body = new RigidBody3D(level.Cx, level.Cy, level.Cz, level.Mass, count);
		level.RebuildLocal();
		level.RebuildIndex();
		level.Humidity = m_terrain.GetSeasonalHumidity(climateCell.X, climateCell.Z);
		level.Temperature = m_terrain.GetSeasonalTemperature(climateCell.X, climateCell.Z);
		return level;
	}

	void RemoveFromTerrain(SubLevel level)
	{
		for (int i = 0; i < level.Count; i++)
		{
			m_subsystemTerrain.ChangeCell(level.Cx[i], level.Cy[i], level.Cz[i], 0, true);
		}
	}

	// After blocks were removed from the arrays: new mass properties, same position, rotation and momentum.
	void RebuildBody(SubLevel level)
	{
		RigidBody3D old = level.Body;
		RigidBody3D nb = new RigidBody3D(level.Cx, level.Cy, level.Cz, level.Mass, level.Count);
		PMat3 R = old.Rotation.ToMat3();
		PVec3 dCom = nb.CenterOfMass - old.CenterOfMass;
		PVec3 shift = R.Mul(dCom);
		nb.Rotation = old.Rotation;
		nb.Position = old.Position + shift;
		nb.AngularVelocity = old.AngularVelocity;
		nb.Velocity = old.Velocity + PVec3.Cross(old.AngularVelocity, shift);
		nb.NoSleep = old.NoSleep;
		nb.LinearDamping = old.LinearDamping;
		nb.AngularDamping = old.AngularDamping;
		nb.Age = old.Age;
		level.Body = nb;
		level.RebuildLocal();
		level.RebuildIndex();
		if (level.Ship != null)
		{
			level.Ship.SeatLocal = level.Ship.SeatLocal - dCom;
		}
		foreach (KeyValuePair<ComponentPlayer, PlayerState> kv in m_players)
		{
			if (kv.Value.Grab != null && kv.Value.Grab.Level == level)
			{
				kv.Value.Grab.Local = kv.Value.Grab.Local - dCom;
			}
			if (kv.Value.DigLevel == level)
			{
				kv.Value.DigLevel = null;
				kv.Value.DigProgress = 0f;
			}
		}
	}

	void RemoveLevel(SubLevel level)
	{
		if (level.Ship != null)
		{
			DismountPilot(level);
		}
		m_levels.Remove(level);
		ClearReferences(level);
		if (level.Group != null)
		{
			m_glue.Remove(level.Group);
			SaveGlue();
		}
	}

	void ClearReferences(SubLevel level)
	{
		foreach (KeyValuePair<ComponentPlayer, PlayerState> kv in m_players)
		{
			if (kv.Value.Grab != null && kv.Value.Grab.Level == level)
			{
				kv.Value.Grab = null;
			}
			if (kv.Value.DigLevel == level)
			{
				kv.Value.DigLevel = null;
				kv.Value.DigProgress = 0f;
			}
		}
	}

	PlayerState GetState(ComponentPlayer p)
	{
		PlayerState st;
		if (!m_players.TryGetValue(p, out st))
		{
			st = new PlayerState();
			m_players[p] = st;
		}
		return st;
	}

	bool IsPilot(ComponentPlayer p)
	{
		for (int i = 0; i < m_levels.Count; i++)
		{
			if (m_levels[i].Ship != null && m_levels[i].Ship.Pilot == p)
			{
				return true;
			}
		}
		return false;
	}

	// ---------------------------------------------------------------- glue + lever

	void GlueBox(ComponentPlayer p, Point3 a, Point3 b)
	{
		int x0 = Math.Min(a.X, b.X), x1 = Math.Max(a.X, b.X);
		int y0 = Math.Min(a.Y, b.Y), y1 = Math.Max(a.Y, b.Y);
		int z0 = Math.Min(a.Z, b.Z), z1 = Math.Max(a.Z, b.Z);
		int max = SubLevelConfig.MaxGlueBox;
		if (x1 - x0 + 1 > max || y1 - y0 + 1 > max || z1 - z0 + 1 > max)
		{
			Say(p, "Kotak lem terlalu besar (maksimal " + max + " blok per sisi).");
			return;
		}
		List<Point3> cells = new List<Point3>();
		for (int x = x0; x <= x1; x++)
		{
			for (int y = Math.Max(0, y0); y <= Math.Min(255, y1); y++)
			{
				for (int z = z0; z <= z1; z++)
				{
					if (StructureScanner.IsGluable(m_terrain.GetCellValue(x, y, z)))
					{
						cells.Add(new Point3(x, y, z));
					}
				}
			}
		}
		if (cells.Count == 0)
		{
			Say(p, "Tidak ada blok bangunan di kotak itu.");
			return;
		}
		if (cells.Count > SubLevelConfig.MaxBlocksPerBody)
		{
			Say(p, "Terlalu banyak blok (" + cells.Count + "), maksimal " + SubLevelConfig.MaxBlocksPerBody + ".");
			return;
		}
		GlueGroup g = m_glue.AddCells(cells);
		SaveGlue();
		Say(p, "Dilem: " + cells.Count + " blok (grup " + g.Cells.Count + "). Pasang tuas di sebelahnya, lalu nyalakan.");
	}

	void HandleGlue(ComponentPlayer p, PlayerState st, Ray3 ray)
	{
		Vector3 dir = Vector3.Normalize(ray.Direction);
		TerrainRaycastResult? tr = m_subsystemTerrain.Raycast(ray.Position, ray.Position + dir * SubLevelConfig.ReachDistance, false, true, null);
		if (!tr.HasValue)
		{
			return;
		}
		Point3 cell = new Point3(tr.Value.CellFace.X, tr.Value.CellFace.Y, tr.Value.CellFace.Z);
		if (!st.GlueHasFirst)
		{
			st.GlueFirst = cell;
			st.GlueHasFirst = true;
			Say(p, "Lem: titik 1 dipilih. Ketuk sudut seberang untuk titik 2.");
			return;
		}
		st.GlueHasFirst = false;
		GlueBox(p, st.GlueFirst, cell);
	}

	bool IsNearAnyPlayer(GlueGroup g)
	{
		Point3 first = default(Point3);
		foreach (Point3 c in g.Cells)
		{
			first = c;
			break;
		}
		float limit = SubLevelConfig.GroupActiveDistance * SubLevelConfig.GroupActiveDistance;
		ReadOnlyList<ComponentPlayer> players = m_subsystemPlayers.ComponentPlayers;
		for (int i = 0; i < players.Count; i++)
		{
			if (players[i] == null || players[i].ComponentBody == null)
			{
				continue;
			}
			Vector3 pp = players[i].ComponentBody.Position;
			float dx = pp.X - first.X;
			float dy = pp.Y - first.Y;
			float dz = pp.Z - first.Z;
			if (dx * dx + dy * dy + dz * dz <= limit)
			{
				return true;
			}
		}
		return false;
	}

	void ScanLevers(GlueGroup g)
	{
		g.Levers.Clear();
		foreach (Point3 c in g.Cells)
		{
			for (int i = 0; i < Dirs6.Length; i++)
			{
				Point3 n = new Point3(c.X + Dirs6[i].X, c.Y + Dirs6[i].Y, c.Z + Dirs6[i].Z);
				if (!g.Cells.Contains(n) && !g.Levers.Contains(n) && ToolConfig.IsLever(m_terrain.GetCellValue(n.X, n.Y, n.Z)))
				{
					g.Levers.Add(n);
				}
			}
		}
	}

	// A lever next to a glued group switched from OFF to ON turns the group into a physics body.
	void PollLevers(double now)
	{
		if (now < m_nextLeverPoll || m_glue.Groups.Count == 0)
		{
			return;
		}
		m_nextLeverPoll = now + SubLevelConfig.LeverPollInterval;
		for (int gi = 0; gi < m_glue.Groups.Count; gi++)
		{
			GlueGroup g = m_glue.Groups[gi];
			if (g.Active != null || !IsNearAnyPlayer(g))
			{
				continue;
			}
			if (now >= g.NextLeverScan)
			{
				ScanLevers(g);
				g.NextLeverScan = now + SubLevelConfig.LeverScanInterval;
			}
			for (int li = g.Levers.Count - 1; li >= 0; li--)
			{
				Point3 lc = g.Levers[li];
				int v = m_terrain.GetCellValue(lc.X, lc.Y, lc.Z);
				if (!ToolConfig.IsLever(v))
				{
					g.Levers.RemoveAt(li);
					m_leverState.Remove(lc);
					continue;
				}
				bool on = SwitchBlock.GetLeverState(v);
				bool last;
				if (!m_leverState.TryGetValue(lc, out last))
				{
					m_leverState[lc] = on;
					continue;
				}
				m_leverState[lc] = on;
				if (on && !last)
				{
					ActivateGroup(g);
					break;
				}
			}
		}
	}

	bool ActivateGroup(GlueGroup g)
	{
		if (g.Active != null || m_levels.Count >= SubLevelConfig.MaxBodies)
		{
			return false;
		}
		List<Point3> cells = new List<Point3>();
		foreach (Point3 c in g.Cells)
		{
			if (Terrain.ExtractContents(m_terrain.GetCellValue(c.X, c.Y, c.Z)) != 0)
			{
				cells.Add(c);
			}
		}
		for (int i = 0; i < g.Levers.Count; i++)
		{
			Point3 lc = g.Levers[i];
			if (!g.Cells.Contains(lc) && ToolConfig.IsLever(m_terrain.GetCellValue(lc.X, lc.Y, lc.Z)))
			{
				cells.Add(lc);
			}
		}
		if (cells.Count == 0 || cells.Count > SubLevelConfig.MaxBlocksPerBody)
		{
			return false;
		}
		m_glue.Unindex(g);
		SubLevel level = CreateBody(cells, cells[0]);
		level.Group = g;
		g.Active = level;
		g.Cells = new HashSet<Point3>(cells);
		RemoveFromTerrain(level);
		m_levels.Add(level);
		for (int i = 0; i < cells.Count; i++)
		{
			m_leverState.Remove(cells[i]);
		}
		return true;
	}

	// The body was put back into the terrain: its glue group now lives at the new cells.
	void FinishGroup(SubLevel level, List<Point3> placed)
	{
		ClearReferences(level);
		GlueGroup g = level.Group;
		if (g == null)
		{
			return;
		}
		g.Active = null;
		m_glue.SetCells(g, placed);
		for (int i = 0; i < placed.Count; i++)
		{
			if (ToolConfig.IsLever(m_terrain.GetCellValue(placed[i].X, placed[i].Y, placed[i].Z)))
			{
				m_leverState[placed[i]] = false;
			}
		}
		SaveGlue();
	}

	void ParkBody(SubLevel level, ComponentPlayer who)
	{
		if (level.Group == null)
		{
			return;
		}
		if (level.Ship != null)
		{
			DismountPilot(level);
		}
		List<Point3> placed = Settle(level, false);
		if (placed == null)
		{
			Say(who, "Benda terlalu miring untuk dipasang kembali. Luruskan dulu.");
			return;
		}
		m_levels.Remove(level);
		FinishGroup(level, placed);
		Say(who, "Fisika dimatikan: blok dipasang kembali.");
	}

	// ---------------------------------------------------------------- players: dig, interact, magnet

	bool TryBodyHit(Ray3 ray, out SubLevel level, out int index, out float distance, out Vector3 point)
	{
		level = null;
		index = -1;
		distance = 0f;
		point = Vector3.Zero;
		if (m_levels.Count == 0)
		{
			return false;
		}
		if (!BodyRaycaster.Raycast(m_levels, ray, SubLevelConfig.ReachDistance, out level, out index, out distance, out point))
		{
			return false;
		}
		// terrain in front of the body wins
		Vector3 dir = Vector3.Normalize(ray.Direction);
		TerrainRaycastResult? tr = m_subsystemTerrain.Raycast(ray.Position, ray.Position + dir * (distance - 0.02f), false, true, null);
		return !tr.HasValue;
	}

	// Called by the Harmony prefixes of ComponentMiner.Dig / Interact: true = the player is aiming at a body that is nearer
	// than the terrain, so the vanilla action on the terrain behind it must not happen.
	public bool ShouldSuppress(ComponentMiner miner, bool interact, float terrainDistance)
	{
		if (m_levels.Count == 0 || miner == null || miner.ComponentPlayer == null)
		{
			return false;
		}
		PlayerInput input = miner.ComponentPlayer.ComponentInput.PlayerInput;
		Ray3? ray = interact ? input.Interact : input.Dig;
		if (!ray.HasValue)
		{
			return false;
		}
		SubLevel level;
		int index;
		float distance;
		Vector3 point;
		if (!BodyRaycaster.Raycast(m_levels, ray.Value, SubLevelConfig.ReachDistance, out level, out index, out distance, out point))
		{
			return false;
		}
		return distance <= terrainDistance;
	}

	void UpdatePlayers(float dt)
	{
		ReadOnlyList<ComponentPlayer> players = m_subsystemPlayers.ComponentPlayers;
		for (int i = 0; i < players.Count; i++)
		{
			ComponentPlayer p = players[i];
			if (p == null || p.ComponentBody == null || p.ComponentMiner == null || p.ComponentInput == null || IsPilot(p))
			{
				continue;
			}
			UpdatePlayer(p, GetState(p), dt);
		}
	}

	void UpdatePlayer(ComponentPlayer p, PlayerState st, float dt)
	{
		PlayerInput input = p.ComponentInput.PlayerInput;
		ComponentMiner miner = p.ComponentMiner;
		int active = miner.ActiveBlockValue;
		double now = m_subsystemTime.GameTime;
		bool glue = ToolConfig.IsGlue(active);
		bool mover = ToolConfig.IsMover(active);

		HandleDig(p, st, input, miner, dt);

		if (input.Interact.HasValue && now - st.LastActionTime > 0.3)
		{
			st.LastActionTime = now;
			if (glue)
			{
				HandleGlue(p, st, input.Interact.Value);
			}
			else if (!mover && active != 0 && TryPlaceOnBody(p, miner, input.Interact.Value, active))
			{
				// a block was added to a body
			}
			else
			{
				HandleInteract(p, st, input.Interact.Value, mover);
			}
		}
		if (mover && input.Hit.HasValue && now - st.LastPushTime > 0.3)
		{
			st.LastPushTime = now;
			SubLevel level;
			int index;
			float distance;
			Vector3 point;
			if (TryBodyHit(input.Hit.Value, out level, out index, out distance, out point))
			{
				Vector3 dir = Vector3.Normalize(input.Hit.Value.Direction);
				PVec3 impulse = new PVec3(dir.X, dir.Y, dir.Z) * (SubLevelConfig.PushSpeed * level.Body.Mass);
				level.Body.AddImpulseAtPoint(impulse, new PVec3(point.X, point.Y, point.Z));
			}
		}
		if (!glue)
		{
			st.GlueHasFirst = false;
		}
		UpdateGrab(p, st, mover);
	}

	void HandleDig(ComponentPlayer p, PlayerState st, PlayerInput input, ComponentMiner miner, float dt)
	{
		if (!input.Dig.HasValue)
		{
			st.DigLevel = null;
			st.DigProgress = 0f;
			return;
		}
		SubLevel level;
		int index;
		float distance;
		Vector3 point;
		if (!TryBodyHit(input.Dig.Value, out level, out index, out distance, out point))
		{
			st.DigLevel = null;
			st.DigProgress = 0f;
			return;
		}
		if (st.DigLevel != level || st.DigIndex != index)
		{
			st.DigLevel = level;
			st.DigIndex = index;
			st.DigProgress = 0f;
		}
		float digTime = miner.CalculateDigTime(level.Values[index], miner.ActiveBlockValue);
		if (digTime <= 0f)
		{
			st.DigProgress = 1f;
		}
		else if (!float.IsInfinity(digTime))
		{
			st.DigProgress += dt / digTime;
		}
		if (st.DigProgress >= 1f)
		{
			st.DigLevel = null;
			st.DigProgress = 0f;
			BreakBlock(level, index, miner);
		}
	}

	void HandleInteract(ComponentPlayer p, PlayerState st, Ray3 ray, bool mover)
	{
		SubLevel level;
		int index;
		float distance;
		Vector3 point;
		bool hit = TryBodyHit(ray, out level, out index, out distance, out point);
		if (mover)
		{
			if (st.Grab != null)
			{
				st.Grab = null;
				Say(p, "Manipulator dilepas.");
				return;
			}
			if (hit)
			{
				GrabInfo grab = new GrabInfo();
				grab.Level = level;
				grab.Local = level.Body.WorldToLocal(new PVec3(point.X, point.Y, point.Z));
				grab.Distance = distance;
				st.Grab = grab;
				level.Body.Wake();
				Say(p, "Manipulator menahan benda. Ketuk lagi untuk melepas.");
			}
			return;
		}
		if (!hit)
		{
			return;
		}
		int value = level.Values[index];
		Block block = BlocksManager.Blocks[Terrain.ExtractContents(value)];

		// 1. Lever: PhysicsLeverBlock or SwitchBlock
		if (ToolConfig.IsLever(value))
		{
			bool crouching = p.ComponentBody != null && p.ComponentBody.IsCrouching;
			if (crouching)
			{
				ParkBody(level, p);
			}
			else
			{
				int data = Terrain.ExtractData(value);
				int newData = data ^ 1; // toggle ON/OFF
				level.Values[index] = Terrain.ReplaceData(value, newData);
				level.RebuildLocal();
				RebuildBody(level);
				try { AudioManager.PlaySound("Audio/UI/ButtonClick", 1f, 0f, 0f); } catch {}
				bool isOn = (newData & 1) != 0;
				Say(p, isOn ? "Tuas Fisika AKTIF [Listrik Mengalir]" : "Tuas Fisika NON-AKTIF");
				level.UpdateElectrics();
			}
			return;
		}

		// 2. Airship Helm: PhysicsHelmBlock or CraftingTableBlock
		if (ToolConfig.IsHelm(value))
		{
			StartPilot(level, p, index);
			return;
		}

		// 3. Doors
		if (block is DoorBlock)
		{
			int data = Terrain.ExtractData(value);
			bool open = DoorBlock.GetOpen(data);
			level.Values[index] = Terrain.ReplaceData(value, DoorBlock.SetOpen(data, !open));
			level.RebuildLocal();
			RebuildBody(level);
			try { AudioManager.PlaySound(!open ? "Audio/Doors/DoorOpen" : "Audio/Doors/DoorClose", 1f, 0f, 0f); } catch {}
			Say(p, !open ? "Pintu dibuka" : "Pintu ditutup");
			return;
		}

		// 4. Trapdoors
		if (block is TrapdoorBlock)
		{
			int data = Terrain.ExtractData(value);
			bool open = TrapdoorBlock.GetOpen(data);
			level.Values[index] = Terrain.ReplaceData(value, TrapdoorBlock.SetOpen(data, !open));
			level.RebuildLocal();
			RebuildBody(level);
			try { AudioManager.PlaySound(!open ? "Audio/Doors/DoorOpen" : "Audio/Doors/DoorClose", 1f, 0f, 0f); } catch {}
			Say(p, !open ? "Pintu palka dibuka" : "Pintu palka ditutup");
			return;
		}

		// 5. Fence Gates
		if (block is FenceGateBlock)
		{
			int data = Terrain.ExtractData(value);
			bool open = FenceGateBlock.GetOpen(data);
			level.Values[index] = Terrain.ReplaceData(value, FenceGateBlock.SetOpen(data, !open));
			level.RebuildLocal();
			RebuildBody(level);
			try { AudioManager.PlaySound(!open ? "Audio/Doors/DoorOpen" : "Audio/Doors/DoorClose", 1f, 0f, 0f); } catch {}
			return;
		}

		// 6. Chests on moving sub-level
		if (block is ChestBlock)
		{
			HandleSubLevelChest(p, level, index);
			return;
		}

		// 7. Furnaces / Thruster Engines
		if (block is FurnaceBlock || block is LitFurnaceBlock || block is PhysicsEngineBlock)
		{
			Say(p, "Mesin Pendorong. Status dorong: " + (level.EnginesElectricallyPowered ? "TURBO (Listrik ON)" : "Normal"));
			return;
		}
	}

	// Magnet: a spring pulls the grabbed point to where the player looks.
	void UpdateGrab(ComponentPlayer p, PlayerState st, bool mover)
	{
		GrabInfo grab = st.Grab;
		if (grab == null)
		{
			return;
		}
		if (!mover || !m_levels.Contains(grab.Level))
		{
			st.Grab = null;
			return;
		}
		ComponentCreatureModel model = p.ComponentCreatureModel;
		Vector3 eye = model.EyePosition;
		Matrix look = Matrix.CreateFromQuaternion(model.EyeRotation);
		Vector3 fwd = look.Forward;
		Vector3 target = eye + fwd * grab.Distance;
		RigidBody3D body = grab.Level.Body;
		PVec3 pw = body.LocalToWorld(grab.Local);
		float ex = pw.X - eye.X;
		float ey = pw.Y - eye.Y;
		float ez = pw.Z - eye.Z;
		if (ex * ex + ey * ey + ez * ez > SubLevelConfig.GrabMaxDistance * SubLevelConfig.GrabMaxDistance)
		{
			st.Grab = null;
			Say(p, "Magnet terlepas (terlalu jauh).");
			return;
		}
		body.Wake();
		PVec3 arm = pw - body.Position;
		PVec3 vp = body.Velocity + PVec3.Cross(body.AngularVelocity, arm);
		PVec3 error = new PVec3(target.X - pw.X, target.Y - pw.Y, target.Z - pw.Z);
		PVec3 force = error * (body.Mass * 25f) - vp * (body.Mass * 7f);
		body.AddForceAtPoint(force, pw);
		body.AddForce(new PVec3(0f, body.Mass * body.Gravity * 0.9f, 0f));
		body.AddTorque(body.AngularVelocity * (-body.InertiaScale * 2f));
	}

	void BreakBlock(SubLevel level, int index, ComponentMiner miner)
	{
		int value = level.Values[index];
		PVec3 w = level.Body.LocalToWorld(level.Local[index]);
		int active = miner.ActiveBlockValue;
		int toolLevel = BlocksManager.Blocks[Terrain.ExtractContents(active)].GetToolLevel(active);
		DropBlock(value, new Vector3(w.X, w.Y, w.Z), toolLevel);
		DropChestItems(level, index, new Vector3(w.X, w.Y, w.Z));
		miner.DamageActiveTool(1);
		bool wasHelm = ToolConfig.IsHelm(value);
		level.RemoveAt(index);
		if (level.Count == 0)
		{
			RemoveLevel(level);
			return;
		}
		SplitDisconnected(level);
		RebuildBody(level);
		level.Body.Wake();
		if (level.Ship != null && (wasHelm || !ComputeShipStats(level, level.Ship)))
		{
			DismountPilot(level);
		}
	}

	// ---------------------------------------------------------------- airship (Create Aeronautics style)

	bool ComputeShipStats(SubLevel level, ShipData ship)
	{
		PVec3 envSum = default(PVec3);
		int envCount = 0;
		int engineCount = 0;
		for (int i = 0; i < level.Count; i++)
		{
			int v = level.Values[i];
			if (ToolConfig.IsEnvelope(v))
			{
				envSum = envSum + level.Local[i];
				envCount++;
			}
			else if (ToolConfig.IsEngine(v))
			{
				engineCount++;
			}
		}
		ship.EnvelopeCentroidLocal = envSum * (1f / Math.Max(1, envCount));
		ship.EnvelopeFraction = (float)envCount / Math.Max(1, level.Count);
		ship.EngineFraction = (float)engineCount / Math.Max(1, level.Count);
		return envCount > 0 && engineCount > 0;
	}

	void StartPilot(SubLevel level, ComponentPlayer p, int helmIndex)
	{
		if (level.Ship != null)
		{
			if (level.Ship.Pilot != p)
			{
				Say(p, "Kapal sedang dikemudikan.");
			}
			return;
		}
		PMat3 R = level.Body.Rotation.ToMat3();
		if (R.M11 < 0.6f)
		{
			Say(p, "Kapal harus dalam posisi tegak.");
			return;
		}
		ShipData ship = new ShipData();
		ship.Pilot = p;
		if (!ComputeShipStats(level, ship))
		{
			Say(p, "Kapal butuh balon (kanvas) dan mesin (tungku).");
			return;
		}
		Matrix eye = Matrix.CreateFromQuaternion(p.ComponentCreatureModel.EyeRotation);
		Vector3 f = eye.Forward;
		Vector3 r = eye.Right;
		PMat3 Rt = R.Transpose();
		ship.ForwardLocal = Normalized(Rt.Mul(new PVec3(f.X, 0f, f.Z)));
		ship.RightLocal = Normalized(Rt.Mul(new PVec3(r.X, 0f, r.Z)));
		ship.SeatLocal = level.Local[helmIndex] + new PVec3(0f, 0.5f, 0f);
		level.Ship = ship;
		level.Body.NoSleep = true;
		level.Body.LinearDamping = ShipConfig.LinearDamping;
		level.Body.AngularDamping = ShipConfig.AngularDamping;
		level.Body.Wake();
		int liftPercent = (int)(100f * ship.EnvelopeFraction / ShipConfig.RequiredEnvelopeFraction);
		Say(p, "Kamu di kemudi. Daya angkat " + liftPercent + "%. Joystick: maju/belok, Lompat: naik, Jongkok: turun dari kemudi.");
	}

	bool ShipDismountRequested(SubLevel level)
	{
		ComponentPlayer pilot = level.Ship.Pilot;
		if (pilot == null || pilot.ComponentBody == null || pilot.ComponentHealth.Health <= 0f)
		{
			return true;
		}
		if (level.Body.Age < ShipConfig.DismountGrace)
		{
			return false;
		}
		PlayerInput input = pilot.ComponentInput.PlayerInput;
		return input.ToggleCrouch || input.ToggleMount;
	}

	void ApplyShipControls(SubLevel level, float dt)
	{
		ShipData ship = level.Ship;
		RigidBody3D body = level.Body;
		PlayerInput input = ship.Pilot.ComponentInput.PlayerInput;
		float forward = Math.Max(-1f, Math.Min(1f, input.Move.Z));
		float turn = Math.Max(-1f, Math.Min(1f, input.Move.X));

		PMat3 R = body.Rotation.ToMat3();
		PVec3 f = R.Mul(ship.ForwardLocal);
		PVec3 r = R.Mul(ship.RightLocal);
		PVec3 worldUp = new PVec3(0f, 1f, 0f);

		float weight = body.Mass * body.Gravity;
		float capacity = weight * (ship.EnvelopeFraction / ShipConfig.RequiredEnvelopeFraction);
		float factor = ShipConfig.HoverFactor + (input.Jump ? ShipConfig.AscendBonus : 0f);
		float lift = Math.Min(capacity, weight * factor);
		body.AddForceAtPoint(new PVec3(0f, lift, 0f), body.LocalToWorld(ship.EnvelopeCentroidLocal));
		body.AddForce(new PVec3(0f, -body.Velocity.Y * body.Mass * ShipConfig.VerticalDrag, 0f));

		float accel = Math.Min(ShipConfig.MaxThrustAccel, ship.EngineFraction / ShipConfig.RequiredEngineFraction * ShipConfig.ThrustAccelAtRequired);
		if (level.EnginesElectricallyPowered)
		{
			accel *= 2.2f; // Turbo boost saat dialiri listrik / sakelar ON
		}
		body.AddForce(f * (forward * accel * body.Mass));

		PVec3 axis = PVec3.Cross(f, r);
		float sign = (axis.Y >= 0f) ? 1f : -1f;
		float targetYaw = sign * turn * ShipConfig.YawRate;
		PVec3 w = body.AngularVelocity;
		w.Y += (targetYaw - w.Y) * Math.Min(1f, ShipConfig.YawResponse * dt);
		body.AngularVelocity = w;

		PVec3 upW = R.Mul(worldUp);
		PVec3 righting = PVec3.Cross(upW, worldUp);
		PVec3 wHorizontal = body.AngularVelocity - worldUp * body.AngularVelocity.Y;
		body.AddTorque((righting * ShipConfig.RightingAccel - wHorizontal * ShipConfig.TiltDamping) * body.InertiaScale);
	}

	void AttachPilot(SubLevel level)
	{
		ComponentBody pilotBody = level.Ship.Pilot.ComponentBody;
		PVec3 seat = level.Body.LocalToWorld(level.Ship.SeatLocal);
		pilotBody.Position = new Vector3(seat.X, seat.Y, seat.Z);
		pilotBody.Velocity = Vector3.Zero;
	}

	// The pilot leaves the helm; the body keeps its physics (without lift it comes down by itself).
	void DismountPilot(SubLevel level)
	{
		ShipData ship = level.Ship;
		if (ship == null)
		{
			return;
		}
		PVec3 seat = level.Body.LocalToWorld(ship.SeatLocal);
		ComponentPlayer pilot = ship.Pilot;
		level.Ship = null;
		level.Body.NoSleep = false;
		level.Body.LinearDamping = 0.02f;
		level.Body.AngularDamping = 0.25f;
		level.Body.Wake();
		if (pilot != null && pilot.ComponentBody != null)
		{
			pilot.ComponentBody.Position = new Vector3(seat.X, seat.Y + 0.6f, seat.Z);
			pilot.ComponentBody.Velocity = Vector3.Zero;
			Say(pilot, "Kamu turun dari kemudi.");
		}
	}

	// ---------------------------------------------------------------- simulation

	public override void SubsystemUpdate(float dt)
	{
		if (m_subsystemTime == null || m_subsystemTerrain == null)
		{
			return;
		}
		float step = Math.Min(m_subsystemTime.GameTimeDelta, 0.05f);
		if (step <= 0f)
		{
			return;
		}
		try
		{
			UpdatePlayers(step);
			PollLevers(m_subsystemTime.GameTime);
			UpdateLevels(step);
			UpdateAllSubLevelElectrics();
			ResolveInterBodyCollisions();
		}
		catch (Exception ex)
		{
			if (!m_updateErrorLogged)
			{
				m_updateErrorLogged = true;
				Log.Error("SubLevel: update failed: " + ex);
			}
		}
	}

	void UpdateLevels(float step)
	{
		for (int i = m_levels.Count - 1; i >= 0; i--)
		{
			if (i >= m_levels.Count)
			{
				continue;
			}
			SubLevel level = m_levels[i];
			try
			{
				RigidBody3D body = level.Body;
				if (m_terrain.GetChunkAtCell((int)MathF.Floor(body.Position.X), (int)MathF.Floor(body.Position.Z)) == null)
				{
					continue; // chunk not loaded: freeze
				}
				if (level.Ship != null && ShipDismountRequested(level))
				{
					DismountPilot(level);
				}
				if (level.Ship != null)
				{
					ApplyShipControls(level, step);
				}
				if (body.Sleeping)
				{
					level.SleepClock += step;
					if (level.SleepClock > SubLevelConfig.WakeInterval)
					{
						level.SleepClock = 0f;
						body.Wake();   // re-check the terrain below (it may have been dug away)
					}
				}
				body.Step(step, this);
				if (body.PinEnabled && body.Rotation.ToMat3().M11 < MathF.Cos(SubLevelConfig.TreeReleaseTilt))
				{
					body.PinEnabled = false;
				}
				if (level.Ship != null)
				{
					AttachPilot(level);
				}
				if (body.Position.Y < -30f)
				{
					RemoveLevel(level);
					continue;
				}
				// felled trees settle by themselves; glued bodies stay physical until a lever parks them
				if (level.Group == null && level.Ship == null && (body.Sleeping || body.Age > SubLevelConfig.MaxBodyAge))
				{
					m_levels.Remove(level);
					ClearReferences(level);
					Settle(level, true);
				}
			}
			catch (Exception ex)
			{
				Log.Error("SubLevel: body update failed: " + ex);
				m_levels.Remove(level);
			}
		}
	}

	// Saving the world while bodies are in flight would lose their blocks: put everything back first.
	public void BeforeTerrainSaveHook()
	{
		for (int i = m_levels.Count - 1; i >= 0; i--)
		{
			SubLevel level = m_levels[i];
			m_levels.RemoveAt(i);
			try
			{
				if (level.Ship != null)
				{
					DismountPilot(level);
				}
				List<Point3> placed = Settle(level, true);
				FinishGroup(level, placed ?? new List<Point3>());
			}
			catch (Exception ex)
			{
				Log.Error("SubLevel: settle on save failed: " + ex);
			}
		}
		SaveGlue();
	}

	// ---------------------------------------------------------------- settle (put back as blocks or drop)

	// Rounds a rotation to the nearest of the 24 axis-aligned rotations. S[row*3+col] in {-1,0,1}.
	static bool SnapRotation(PMat3 R, int[] S)
	{
		float[] m = { R.M00, R.M01, R.M02, R.M10, R.M11, R.M12, R.M20, R.M21, R.M22 };
		bool[] rowUsed = new bool[3];
		for (int i = 0; i < 9; i++)
		{
			S[i] = 0;
		}
		for (int col = 0; col < 3; col++)
		{
			int bestRow = 0;
			float bestAbs = -1f;
			for (int row = 0; row < 3; row++)
			{
				float a = MathF.Abs(m[row * 3 + col]);
				if (a > bestAbs)
				{
					bestAbs = a;
					bestRow = row;
				}
			}
			if (rowUsed[bestRow])
			{
				return false;
			}
			rowUsed[bestRow] = true;
			S[bestRow * 3 + col] = (m[bestRow * 3 + col] >= 0f) ? 1 : -1;
		}
		int det = S[0] * (S[4] * S[8] - S[5] * S[7]) - S[1] * (S[3] * S[8] - S[5] * S[6]) + S[2] * (S[3] * S[7] - S[4] * S[6]);
		return det == 1;
	}

	static int RemapValue(int value, int[] S)
	{
		if (ToolConfig.IsLever(value))
		{
			return SwitchBlock.SetLeverState(value, false);   // a parked body always has its lever OFF
		}
		if (!(BlocksManager.Blocks[Terrain.ExtractContents(value)] is WoodBlock))
		{
			return value;
		}
		int data = Terrain.ExtractData(value);
		int cutFace = WoodBlock.GetCutFace(data);
		int localAxis = (cutFace == 4 || cutFace == 5) ? 1 : ((cutFace == 0 || cutFace == 2) ? 2 : 0);
		int newAxis = localAxis;
		for (int row = 0; row < 3; row++)
		{
			if (S[row * 3 + localAxis] != 0)
			{
				newAxis = row;
			}
		}
		int newCutFace = (newAxis == 1) ? 4 : ((newAxis == 2) ? 0 : 1);
		return Terrain.MakeBlockValue(Terrain.ExtractContents(value), 0, WoodBlock.SetCutFace(data, newCutFace));
	}

	bool IsReplaceable(int x, int y, int z)
	{
		if (y < 0 || y > 255)
		{
			return false;
		}
		return !StructureScanner.IsSolid(m_terrain.GetCellValue(x, y, z));
	}

	// Puts the body back into the terrain as blocks. Returns the cells that were filled, or null if the body is too tilted and
	// force is false. With force the blocks that cannot be placed are dropped as items.
	List<Point3> Settle(SubLevel level, bool force)
	{
		RigidBody3D body = level.Body;
		int count = level.Count;
		int[] S = new int[9];
		bool wantRestore = level.Group != null || SubLevelConfig.RestoreBlocks;
		if (!wantRestore || !SnapRotation(body.Rotation.ToMat3(), S))
		{
			if (!force)
			{
				return null;
			}
			DropAll(level);
			return new List<Point3>();
		}

		PVec3[] sw = new PVec3[count];
		for (int i = 0; i < count; i++)
		{
			PVec3 l = level.Local[i];
			sw[i] = new PVec3(
				S[0] * l.X + S[1] * l.Y + S[2] * l.Z,
				S[3] * l.X + S[4] * l.Y + S[5] * l.Z,
				S[6] * l.X + S[7] * l.Y + S[8] * l.Z);
		}
		PVec3 p0 = body.Position + sw[0];
		PVec3 origin = new PVec3(
			body.Position.X + (MathF.Floor(p0.X) + 0.5f - p0.X),
			body.Position.Y + (MathF.Floor(p0.Y) + 0.5f - p0.Y),
			body.Position.Z + (MathF.Floor(p0.Z) + 0.5f - p0.Z));

		int bestDy = 0;
		int bestConflicts = int.MaxValue;
		for (int dy = 0; dy <= 2 && bestConflicts > 0; dy++)
		{
			int conflicts = 0;
			for (int i = 0; i < count; i++)
			{
				int x = (int)MathF.Round(origin.X + sw[i].X - 0.5f);
				int y = (int)MathF.Round(origin.Y + sw[i].Y - 0.5f) + dy;
				int z = (int)MathF.Round(origin.Z + sw[i].Z - 0.5f);
				if (!IsReplaceable(x, y, z))
				{
					conflicts++;
				}
			}
			if (conflicts < bestConflicts)
			{
				bestConflicts = conflicts;
				bestDy = dy;
			}
		}
		if (bestConflicts > 0 && !force)
		{
			return null; // does not fit here
		}

		List<Point3> placed = new List<Point3>();
		for (int i = 0; i < count; i++)
		{
			int x = (int)MathF.Round(origin.X + sw[i].X - 0.5f);
			int y = (int)MathF.Round(origin.Y + sw[i].Y - 0.5f) + bestDy;
			int z = (int)MathF.Round(origin.Z + sw[i].Z - 0.5f);
			if (IsReplaceable(x, y, z))
			{
				m_subsystemTerrain.ChangeCell(x, y, z, RemapValue(level.Values[i], S), true);
				placed.Add(new Point3(x, y, z));
			}
			else
			{
				DropBlock(level.Values[i], new Vector3(x + 0.5f, y + 0.5f, z + 0.5f), 0);
			}
		}
		return placed;
	}

	void DropAll(SubLevel level)
	{
		RigidBody3D body = level.Body;
		PMat3 R = body.Rotation.ToMat3();
		for (int i = 0; i < level.Count; i++)
		{
			PVec3 w = body.Position + R.Mul(level.Local[i]);
			DropBlock(level.Values[i], new Vector3(w.X, w.Y + 0.25f, w.Z), 0);
		}
	}

	// Same drop rules as SubsystemTerrain.DestroyCell.
	void DropBlock(int value, Vector3 position, int toolLevel)
	{
		Block block = BlocksManager.Blocks[Terrain.ExtractContents(value)];
		m_dropValues.Clear();
		bool showDebris;
		block.GetDropValues(m_subsystemTerrain, value, 0, toolLevel, m_dropValues, out showDebris);
		int newValue = 0;
		int cx = (int)MathF.Floor(position.X);
		int cy = (int)MathF.Floor(position.Y);
		int cz = (int)MathF.Floor(position.Z);
		for (int i = 0; i < m_dropValues.Count; i++)
		{
			BlockDropValue drop = m_dropValues[i];
			if (drop.Count <= 0)
			{
				continue;
			}
			SubsystemBlockBehavior[] behaviors = m_subsystemBlockBehaviors.GetBlockBehaviors(Terrain.ExtractContents(drop.Value));
			for (int j = 0; j < behaviors.Length; j++)
			{
				behaviors[j].OnItemHarvested(cx, cy, cz, value, ref drop, ref newValue);
			}
			if (drop.Count > 0 && Terrain.ExtractContents(drop.Value) != 0)
			{
				m_subsystemPickables.AddPickable(drop.Value, drop.Count, position, null, null);
			}
		}
	}

	// ---------------------------------------------------------------- rendering

	public void OnTerrainDrawHook(Camera camera, int drawOrder)
	{
		if (drawOrder != 0 || m_levels.Count == 0 || m_terrain == null)
		{
			return;
		}
		try
		{
			DrawLevels(camera);
		}
		catch (Exception ex)
		{
			if (!m_drawErrorLogged)
			{
				m_drawErrorLogged = true;
				Log.Error("SubLevel: draw failed: " + ex);
			}
		}
	}

	void DrawLevels(Camera camera)
	{
		if (m_renderer == null)
		{
			m_renderer = new PrimitivesRenderer3D();
		}
		if (m_env == null)
		{
			m_env = new DrawBlockEnvironmentData();
		}
		m_env.SubsystemTerrain = m_subsystemTerrain;
		bool any = false;
		for (int li = 0; li < m_levels.Count; li++)
		{
			SubLevel level = m_levels[li];
			PVec3 pos = level.Body.Position;
			if (Vector3.Distance(camera.ViewPosition, new Vector3(pos.X, pos.Y, pos.Z)) > SubLevelConfig.MaxVisibleDistance)
			{
				continue;
			}
			PMat3 R = level.Body.Rotation.ToMat3();
			m_env.Humidity = level.Humidity;
			m_env.Temperature = level.Temperature;
			for (int i = 0; i < level.Count; i++)
			{
				if (level.Hidden != null && i < level.Hidden.Length && level.Hidden[i])
				{
					continue;
				}
				PVec3 w = pos + R.Mul(level.Local[i]);
				Matrix matrix = new Matrix(
					R.M00, R.M10, R.M20, 0f,
					R.M01, R.M11, R.M21, 0f,
					R.M02, R.M12, R.M22, 0f,
					w.X, w.Y, w.Z, 1f);
				int light = m_terrain.GetCellLight((int)MathF.Floor(w.X), (int)MathF.Floor(w.Y), (int)MathF.Floor(w.Z));
				m_env.Light = Math.Max(0, Math.Min(15, light));
				m_env.InWorldMatrix = matrix;
				int value = level.Values[i];
				BlocksManager.Blocks[Terrain.ExtractContents(value)].DrawBlock(m_renderer, value, Color.White, 1f, ref matrix, m_env);
			}
			any = true;
		}
		if (any)
		{
			m_renderer.Flush(camera.ViewProjectionMatrix, true, int.MaxValue);
		}
	}

	// ---------------------------------------------------------------- chest storage on moving bodies
	readonly Dictionary<string, List<int>> m_subLevelChestStorage = new Dictionary<string, List<int>>();

	string ChestKey(SubLevel level, int index)
	{
		return level.GetHashCode() + "_" + level.Cx[index] + "_" + level.Cy[index] + "_" + level.Cz[index];
	}

	void HandleSubLevelChest(ComponentPlayer p, SubLevel level, int index)
	{
		string key = ChestKey(level, index);
		List<int> items;
		if (!m_subLevelChestStorage.TryGetValue(key, out items))
		{
			items = new List<int>();
			m_subLevelChestStorage[key] = items;
		}

		ComponentMiner miner = p.ComponentMiner;
		int active = miner != null ? miner.ActiveBlockValue : 0;
		if (active != 0)
		{
			items.Add(active);
			if (m_subsystemGameInfo == null || m_subsystemGameInfo.WorldSettings.GameMode != GameMode.Creative)
			{
				miner.RemoveActiveTool(1);
			}
			try { AudioManager.PlaySound("Audio/UI/ButtonClick", 1f, 0f, 0f); } catch {}
			Block b = BlocksManager.Blocks[Terrain.ExtractContents(active)];
			Say(p, "Peti Fisika: Menyimpan " + b.DefaultDisplayName + " (Total: " + items.Count + " item)");
		}
		else
		{
			if (items.Count > 0)
			{
				int take = items[items.Count - 1];
				items.RemoveAt(items.Count - 1);
				if (m_subsystemPickables != null)
				{
					Vector3 eye = p.ComponentCreatureModel != null ? p.ComponentCreatureModel.EyePosition : p.ComponentBody.Position;
					m_subsystemPickables.AddPickable(take, 1, eye, Vector3.Zero, null);
				}
				try { AudioManager.PlaySound("Audio/UI/ButtonClick", 1f, 0f, 0f); } catch {}
				Block b = BlocksManager.Blocks[Terrain.ExtractContents(take)];
				Say(p, "Peti Fisika: Mengambil " + b.DefaultDisplayName + " (Sisa: " + items.Count + " item)");
			}
			else
			{
				Say(p, "Peti Fisika kosong. Ketuk sambil memegang item untuk menyimpannya.");
			}
		}
	}

	void DropChestItems(SubLevel level, int index, Vector3 worldPos)
	{
		string key = ChestKey(level, index);
		List<int> items;
		if (m_subLevelChestStorage.TryGetValue(key, out items))
		{
			for (int i = 0; i < items.Count; i++)
			{
				if (m_subsystemPickables != null)
				{
					m_subsystemPickables.AddPickable(items[i], 1, worldPos, new Vector3(0f, 2f, 0f), null);
				}
			}
			m_subLevelChestStorage.Remove(key);
		}
	}

	// ---------------------------------------------------------------- electricity simulation
	double m_lastElectricsUpdate;

	void UpdateAllSubLevelElectrics()
	{
		double now = m_subsystemTime.GameTime;
		if (now - m_lastElectricsUpdate < 0.2)
		{
			return;
		}
		m_lastElectricsUpdate = now;
		for (int i = 0; i < m_levels.Count; i++)
		{
			m_levels[i].UpdateElectrics();
		}
	}

	// ---------------------------------------------------------------- body-vs-body collision & physics interaction
	void ResolveInterBodyCollisions()
	{
		int count = m_levels.Count;
		if (count < 2)
		{
			return;
		}
		for (int i = 0; i < count; i++)
		{
			SubLevel levelA = m_levels[i];
			RigidBody3D bodyA = levelA.Body;
			PMat3 RA = bodyA.Rotation.ToMat3();
			PVec3[] samplesA = bodyA.Samples;
			if (samplesA == null || samplesA.Length == 0)
			{
				continue;
			}
			float radA = (levelA.BoundsMax - levelA.BoundsMin).Length * 0.5f;

			for (int j = i + 1; j < count; j++)
			{
				SubLevel levelB = m_levels[j];
				RigidBody3D bodyB = levelB.Body;
				PVec3 delta = bodyA.Position - bodyB.Position;
				float radB = (levelB.BoundsMax - levelB.BoundsMin).Length * 0.5f;
				float maxDist = radA + radB + 1f;

				if (delta.X * delta.X + delta.Y * delta.Y + delta.Z * delta.Z > maxDist * maxDist)
				{
					continue;
				}

				PMat3 RB = bodyB.Rotation.ToMat3();
				PMat3 invRB = RB.Transpose();

				for (int s = 0; s < samplesA.Length; s++)
				{
					PVec3 pWorld = bodyA.Position + RA.Mul(samplesA[s]);
					PVec3 pLocalB = invRB.Mul(pWorld - bodyB.Position);
					PVec3 pCellB = pLocalB + bodyB.CenterOfMass;
					int cx = (int)MathF.Floor(pCellB.X);
					int cy = (int)MathF.Floor(pCellB.Y);
					int cz = (int)MathF.Floor(pCellB.Z);

					int idxB;
					if (levelB.Index.TryGetValue(new Point3(cx, cy, cz), out idxB))
					{
						int valB = levelB.Values[idxB];
						if (StructureScanner.IsSolid(valB))
						{
							PVec3 cellCenter = new PVec3(cx + 0.5f, cy + 0.5f, cz + 0.5f);
							PVec3 diff = pCellB - cellCenter;
							float len = diff.Length;
							PVec3 nWorld = (len > 1e-4f) ? RB.Mul(diff * (1f / len)) : new PVec3(0f, 1f, 0f);

							PVec3 rA = pWorld - bodyA.Position;
							PVec3 rB = pWorld - bodyB.Position;
							PVec3 vpA = bodyA.Velocity + PVec3.Cross(bodyA.AngularVelocity, rA);
							PVec3 vpB = bodyB.Velocity + PVec3.Cross(bodyB.AngularVelocity, rB);
							PVec3 vRel = vpA - vpB;

							float vn = PVec3.Dot(vRel, nWorld);
							if (vn < 0f)
							{
								float e = 0.25f;
								float effMass = bodyA.InvMass + bodyB.InvMass;
								float jMag = -(1f + e) * vn / Math.Max(0.0001f, effMass);
								PVec3 impulse = nWorld * jMag;

								bodyA.AddImpulseAtPoint(impulse, pWorld);
								bodyB.AddImpulseAtPoint(impulse * (-1f), pWorld);

								float push = 0.08f;
								bodyA.Position = bodyA.Position + nWorld * push;
								bodyB.Position = bodyB.Position - nWorld * push;

								bodyA.Wake();
								bodyB.Wake();
								break;
							}
						}
					}
				}
			}
		}
	}
}
