// Sub-level physics mod - Custom independent blocks and models (Sable / Create Aeronautics style)
// Defines standalone 3D models and blocks without overriding vanilla game items.
using System;
using System.Collections.Generic;
using Engine;
using Engine.Graphics;

namespace Game;

public static class ProceduralMeshHelper
{
	public static void AddQuad(BlockMesh mesh, Vector3 p0, Vector3 p1, Vector3 p2, Vector3 p3, Vector4 tc, Color color, byte face, Matrix? transform = null)
	{
		if (transform.HasValue)
		{
			p0 = Vector3.Transform(p0, transform.Value);
			p1 = Vector3.Transform(p1, transform.Value);
			p2 = Vector3.Transform(p2, transform.Value);
			p3 = Vector3.Transform(p3, transform.Value);
		}
		int start = mesh.Vertices.Count;
		mesh.Vertices.Add(new BlockMeshVertex { Position = p0, TextureCoordinates = new Vector2(tc.X, tc.W), Color = color, Face = face });
		mesh.Vertices.Add(new BlockMeshVertex { Position = p1, TextureCoordinates = new Vector2(tc.Z, tc.W), Color = color, Face = face });
		mesh.Vertices.Add(new BlockMeshVertex { Position = p2, TextureCoordinates = new Vector2(tc.Z, tc.Y), Color = color, Face = face });
		mesh.Vertices.Add(new BlockMeshVertex { Position = p3, TextureCoordinates = new Vector2(tc.X, tc.Y), Color = color, Face = face });

		mesh.Indices.Add(start);
		mesh.Indices.Add(start + 1);
		mesh.Indices.Add(start + 2);
		mesh.Indices.Add(start + 2);
		mesh.Indices.Add(start + 3);
		mesh.Indices.Add(start);
	}

	public static void AddBox(BlockMesh mesh, Vector3 min, Vector3 max, Color color, int slot = 0, Matrix? transform = null)
	{
		Vector4 tc = (slot >= 0 && slot < BlocksManager.m_slotTexCoords.Length && BlocksManager.m_slotTexCoords[slot] != default)
			? BlocksManager.m_slotTexCoords[slot]
			: new Vector4(0f, 0f, 1f, 1f);

		// Face 0: +Z
		AddQuad(mesh, new Vector3(min.X, min.Y, max.Z), new Vector3(max.X, min.Y, max.Z), new Vector3(max.X, max.Y, max.Z), new Vector3(min.X, max.Y, max.Z), tc, color, 0, transform);
		// Face 1: +X
		AddQuad(mesh, new Vector3(max.X, min.Y, max.Z), new Vector3(max.X, min.Y, min.Z), new Vector3(max.X, max.Y, min.Z), new Vector3(max.X, max.Y, max.Z), tc, color, 1, transform);
		// Face 2: -Z
		AddQuad(mesh, new Vector3(max.X, min.Y, min.Z), new Vector3(min.X, min.Y, min.Z), new Vector3(min.X, max.Y, min.Z), new Vector3(max.X, max.Y, min.Z), tc, color, 2, transform);
		// Face 3: -X
		AddQuad(mesh, new Vector3(min.X, min.Y, min.Z), new Vector3(min.X, min.Y, max.Z), new Vector3(min.X, max.Y, max.Z), new Vector3(min.X, max.Y, min.Z), tc, color, 3, transform);
		// Face 4: +Y
		AddQuad(mesh, new Vector3(min.X, max.Y, max.Z), new Vector3(max.X, max.Y, max.Z), new Vector3(max.X, max.Y, min.Z), new Vector3(min.X, max.Y, min.Z), tc, color, 4, transform);
		// Face 5: -Y
		AddQuad(mesh, new Vector3(min.X, min.Y, min.Z), new Vector3(max.X, min.Y, min.Z), new Vector3(max.X, min.Y, max.Z), new Vector3(min.X, min.Y, max.Z), tc, color, 5, transform);
	}
}

// ============================================================================
// 1. Physics Super Glue: Custom adhesive tube item & block
// ============================================================================
public class PhysicsGlueBlock : Block
{
	public BlockMesh m_standaloneMesh = new BlockMesh();
	public BoundingBox[] m_collisionBoxes = new BoundingBox[1];

	public PhysicsGlueBlock()
	{
		DefaultDisplayName = "Lem Super Fisika";
		DefaultDescription = "Alat perekat struktur sub-level (Create/Sable style). Ketuk satu sudut balok lalu sudut lawannya untuk mengelompokkan area menjadi struktur fisik.";
		DefaultCategory = "Mechanics";
		MaxStacking = 16;
		IsCollidable = true;
		IsPlaceable = true;
	}

	public override void Initialize()
	{
		m_standaloneMesh = new BlockMesh();
		// Glue tube body (white/cyan polymer)
		ProceduralMeshHelper.AddBox(m_standaloneMesh, new Vector3(0.35f, 0.0f, 0.35f), new Vector3(0.65f, 0.50f, 0.65f), new Color(230, 240, 255), 19);
		// Industrial red/yellow label stripe
		ProceduralMeshHelper.AddBox(m_standaloneMesh, new Vector3(0.34f, 0.15f, 0.34f), new Vector3(0.66f, 0.35f, 0.66f), new Color(235, 50, 40), 129);
		// Golden applicator collar
		ProceduralMeshHelper.AddBox(m_standaloneMesh, new Vector3(0.40f, 0.50f, 0.40f), new Vector3(0.60f, 0.62f, 0.60f), new Color(250, 200, 40), 145);
		// Precision nozzle tip
		ProceduralMeshHelper.AddBox(m_standaloneMesh, new Vector3(0.45f, 0.62f, 0.45f), new Vector3(0.55f, 0.85f, 0.55f), new Color(245, 245, 255), 19);

		m_collisionBoxes[0] = new BoundingBox(new Vector3(0.3f, 0.0f, 0.3f), new Vector3(0.7f, 0.85f, 0.7f));
		base.Initialize();
	}

	public override void GenerateTerrainVertices(BlockGeometryGenerator generator, TerrainGeometry geometry, int value, int x, int y, int z)
	{
		generator.GenerateMeshVertices(this, x, y, z, m_standaloneMesh, Color.White, null, geometry.SubsetOpaque);
	}

	public override void DrawBlock(PrimitivesRenderer3D primitivesRenderer, int value, Color color, float size, ref Matrix matrix, DrawBlockEnvironmentData environmentData)
	{
		BlocksManager.DrawMeshBlock(primitivesRenderer, m_standaloneMesh, color, size, ref matrix, environmentData);
	}

	public override BoundingBox[] GetCustomCollisionBoxes(SubsystemTerrain terrain, int value)
	{
		return m_collisionBoxes;
	}
}

// ============================================================================
// 2. Physics Lever: Heavy-duty industrial physics activation switch
// ============================================================================
public class PhysicsLeverBlock : Block
{
	public BlockMesh[] m_blockMeshesByIndex = new BlockMesh[12];
	public BlockMesh m_standaloneMesh = new BlockMesh();
	public BoundingBox[][] m_collisionBoxesByIndex = new BoundingBox[12][];

	public PhysicsLeverBlock()
	{
		DefaultDisplayName = "Tuas Fisika";
		DefaultDescription = "Tuas industri pengaktif sub-level fisika. Sakelar ON mengubah struktur balok menjadi objek fisika dinamis & mengalirkan listrik. Ketuk saat jongkok untuk memarkirkan kembali.";
		DefaultCategory = "Mechanics";
		MaxStacking = 16;
		IsCollidable = true;
		IsPlaceable = true;
	}

	public override void Initialize()
	{
		for (int face = 0; face < 6; face++)
		{
			for (int state = 0; state < 2; state++)
			{
				int index = (face << 1) | state;
				Matrix faceMat = face >= 4
					? face != 4
						? Matrix.CreateRotationX((float)Math.PI) * Matrix.CreateTranslation(0.5f, 1f, 0.5f)
						: Matrix.CreateTranslation(0.5f, 0f, 0.5f)
					: Matrix.CreateRotationX((float)Math.PI / 2f)
					* Matrix.CreateTranslation(0f, 0f, -0.5f)
					* Matrix.CreateRotationY(face * (float)Math.PI / 2f)
					* Matrix.CreateTranslation(0.5f, 0.5f, 0.5f);

				BlockMesh mesh = new BlockMesh();
				// Heavy cast-iron base plate
				ProceduralMeshHelper.AddBox(mesh, new Vector3(0.20f, 0.0f, 0.20f), new Vector3(0.80f, 0.08f, 0.80f), new Color(55, 58, 62), 19, faceMat);
				// Metallic pivot bracket
				ProceduralMeshHelper.AddBox(mesh, new Vector3(0.40f, 0.08f, 0.38f), new Vector3(0.60f, 0.22f, 0.62f), new Color(75, 80, 85), 19, faceMat);

				// Lever arm matrix (tilted forward if ON, tilted backward if OFF)
				float angle = (state == 1) ? MathUtils.DegToRad(32f) : MathUtils.DegToRad(-32f);
				Matrix leverMat = Matrix.CreateTranslation(-0.5f, -0.15f, -0.5f)
					* Matrix.CreateRotationX(angle)
					* Matrix.CreateTranslation(0.5f, 0.15f, 0.5f)
					* faceMat;

				// Steel arm rod
				ProceduralMeshHelper.AddBox(mesh, new Vector3(0.46f, 0.15f, 0.46f), new Vector3(0.54f, 0.58f, 0.54f), new Color(180, 185, 195), 19, leverMat);
				// Vivid industrial red handle knob (glows brighter when active)
				Color knobColor = (state == 1) ? new Color(255, 45, 30) : new Color(180, 30, 20);
				ProceduralMeshHelper.AddBox(mesh, new Vector3(0.40f, 0.58f, 0.40f), new Vector3(0.60f, 0.74f, 0.60f), knobColor, 129, leverMat);

				m_blockMeshesByIndex[index] = mesh;
				m_collisionBoxesByIndex[index] = new BoundingBox[] { mesh.CalculateBoundingBox() };
			}
		}

		m_standaloneMesh = m_blockMeshesByIndex[0];
		base.Initialize();
	}

	public override void GenerateTerrainVertices(BlockGeometryGenerator generator, TerrainGeometry geometry, int value, int x, int y, int z)
	{
		int face = (Terrain.ExtractData(value) >> 1) & 7;
		int state = Terrain.ExtractData(value) & 1;
		int index = Math.Clamp((face << 1) | state, 0, 11);
		generator.GenerateMeshVertices(this, x, y, z, m_blockMeshesByIndex[index], Color.White, null, geometry.SubsetOpaque);
	}

	public override void DrawBlock(PrimitivesRenderer3D primitivesRenderer, int value, Color color, float size, ref Matrix matrix, DrawBlockEnvironmentData environmentData)
	{
		BlocksManager.DrawMeshBlock(primitivesRenderer, m_standaloneMesh, color, size, ref matrix, environmentData);
	}

	public override BoundingBox[] GetCustomCollisionBoxes(SubsystemTerrain terrain, int value)
	{
		int face = (Terrain.ExtractData(value) >> 1) & 7;
		int state = Terrain.ExtractData(value) & 1;
		int index = Math.Clamp((face << 1) | state, 0, 11);
		return m_collisionBoxesByIndex[index];
	}

	public override BlockPlacementData GetPlacementValue(SubsystemTerrain subsystemTerrain, ComponentMiner componentMiner, int value, TerrainRaycastResult raycastResult)
	{
		BlockPlacementData result = default;
		result.Value = Terrain.ReplaceData(value, raycastResult.CellFace.Face << 1);
		result.CellFace = raycastResult.CellFace;
		return result;
	}
}

// ============================================================================
// 3. Physics Helm: Dedicated Airship Steering Console & Wheel
// ============================================================================
public class PhysicsHelmBlock : Block
{
	public BlockMesh[] m_meshesByRotation = new BlockMesh[4];
	public BlockMesh m_standaloneMesh = new BlockMesh();
	public BoundingBox[][] m_collisionBoxes = new BoundingBox[4][];

	public PhysicsHelmBlock()
	{
		DefaultDisplayName = "Kemudi Kapal Udara";
		DefaultDescription = "Konsol kemudi untuk menerbangkan dan mengarahkan kapal udara atau kendaraan fisika. Ketuk untuk mengemudi, gunakan joystick arah, Lompat untuk naik, Jongkok untuk turun.";
		DefaultCategory = "Mechanics";
		MaxStacking = 8;
		IsCollidable = true;
		IsPlaceable = true;
	}

	public override void Initialize()
	{
		for (int rot = 0; rot < 4; rot++)
		{
			Matrix rotMat = Matrix.CreateRotationY(rot * (float)Math.PI / 2f) * Matrix.CreateTranslation(0.5f, 0f, 0.5f);
			BlockMesh mesh = new BlockMesh();

			// Wooden pedestal base
			ProceduralMeshHelper.AddBox(mesh, new Vector3(-0.30f, 0.0f, -0.25f), new Vector3(0.30f, 0.65f, 0.25f), new Color(85, 55, 30), 4, rotMat);
			// Brass instrument housing
			ProceduralMeshHelper.AddBox(mesh, new Vector3(-0.20f, 0.65f, -0.15f), new Vector3(0.20f, 0.85f, 0.15f), new Color(220, 180, 50), 145, rotMat);
			// Wheel shaft (facing forward +Z in console space)
			ProceduralMeshHelper.AddBox(mesh, new Vector3(-0.05f, 0.55f, 0.15f), new Vector3(0.05f, 0.65f, 0.35f), new Color(190, 150, 40), 145, rotMat);

			// 8-Spoke Captain's Steering Wheel
			Matrix wheelCenter = Matrix.CreateTranslation(0f, 0.60f, 0.35f) * rotMat;
			for (int s = 0; s < 4; s++)
			{
				Matrix spokeMat = Matrix.CreateRotationZ(s * (float)Math.PI / 4f) * wheelCenter;
				ProceduralMeshHelper.AddBox(mesh, new Vector3(-0.03f, -0.40f, -0.02f), new Vector3(0.03f, 0.40f, 0.02f), new Color(100, 65, 35), 4, spokeMat);
			}
			// Outer wheel rim
			ProceduralMeshHelper.AddBox(mesh, new Vector3(-0.35f, -0.35f, -0.02f), new Vector3(0.35f, 0.35f, 0.02f), new Color(190, 150, 40), 145, wheelCenter);
			// Wheel hub
			ProceduralMeshHelper.AddBox(mesh, new Vector3(-0.08f, -0.08f, -0.03f), new Vector3(0.08f, 0.08f, 0.04f), new Color(240, 200, 60), 145, wheelCenter);

			m_meshesByRotation[rot] = mesh;
			m_collisionBoxes[rot] = new BoundingBox[] { mesh.CalculateBoundingBox() };
		}

		m_standaloneMesh = m_meshesByRotation[0];
		base.Initialize();
	}

	public override void GenerateTerrainVertices(BlockGeometryGenerator generator, TerrainGeometry geometry, int value, int x, int y, int z)
	{
		int rot = Terrain.ExtractData(value) & 3;
		generator.GenerateMeshVertices(this, x, y, z, m_meshesByRotation[rot], Color.White, null, geometry.SubsetOpaque);
	}

	public override void DrawBlock(PrimitivesRenderer3D primitivesRenderer, int value, Color color, float size, ref Matrix matrix, DrawBlockEnvironmentData environmentData)
	{
		BlocksManager.DrawMeshBlock(primitivesRenderer, m_standaloneMesh, color, size, ref matrix, environmentData);
	}

	public override BoundingBox[] GetCustomCollisionBoxes(SubsystemTerrain terrain, int value)
	{
		int rot = Terrain.ExtractData(value) & 3;
		return m_collisionBoxes[rot];
	}

	public override BlockPlacementData GetPlacementValue(SubsystemTerrain subsystemTerrain, ComponentMiner componentMiner, int value, TerrainRaycastResult raycastResult)
	{
		Vector3 forward = componentMiner.ComponentPlayer != null ? componentMiner.ComponentPlayer.ComponentCreatureModel.EyeRotation.GetForwardVector() : Vector3.UnitZ;
		int rot = 0;
		if (MathF.Abs(forward.X) > MathF.Abs(forward.Z))
		{
			rot = (forward.X > 0f) ? 1 : 3;
		}
		else
		{
			rot = (forward.Z > 0f) ? 0 : 2;
		}
		BlockPlacementData result = default;
		result.Value = Terrain.ReplaceData(value, rot);
		result.CellFace = raycastResult.CellFace;
		return result;
	}
}

// ============================================================================
// 4. Physics Engine: Mechanical Thruster Engine with Exhaust Turbine
// ============================================================================
public class PhysicsEngineBlock : Block
{
	public BlockMesh m_blockMesh = new BlockMesh();
	public BoundingBox[] m_collisionBoxes = new BoundingBox[1];

	public PhysicsEngineBlock()
	{
		DefaultDisplayName = "Mesin Pendorong Fisika";
		DefaultDescription = "Mesin turbin pendorong untuk kapal udara dan struktur fisika. Memberikan daya dorong linier. Daya dorong meningkat berlipat ganda saat dialiri sinyal listrik.";
		DefaultCategory = "Mechanics";
		MaxStacking = 16;
		IsCollidable = true;
		IsPlaceable = true;
	}

	public override void Initialize()
	{
		m_blockMesh = new BlockMesh();
		// Reinforced armored casing
		ProceduralMeshHelper.AddBox(m_blockMesh, new Vector3(0.04f, 0.04f, 0.04f), new Vector3(0.96f, 0.96f, 0.96f), new Color(60, 64, 70), 19);
		// Front air intake grill
		ProceduralMeshHelper.AddBox(m_blockMesh, new Vector3(0.18f, 0.18f, 0.95f), new Vector3(0.82f, 0.82f, 1.01f), new Color(35, 38, 42), 19);
		// Rear exhaust nozzle
		ProceduralMeshHelper.AddBox(m_blockMesh, new Vector3(0.15f, 0.15f, -0.02f), new Vector3(0.85f, 0.85f, 0.06f), new Color(180, 80, 30), 145);
		// Glowing energetic internal core
		ProceduralMeshHelper.AddBox(m_blockMesh, new Vector3(0.25f, 0.25f, 0.25f), new Vector3(0.75f, 0.75f, 0.75f), new Color(255, 140, 20), 143);

		m_collisionBoxes[0] = new BoundingBox(Vector3.Zero, Vector3.One);
		base.Initialize();
	}

	public override void GenerateTerrainVertices(BlockGeometryGenerator generator, TerrainGeometry geometry, int value, int x, int y, int z)
	{
		generator.GenerateMeshVertices(this, x, y, z, m_blockMesh, Color.White, null, geometry.SubsetOpaque);
	}

	public override void DrawBlock(PrimitivesRenderer3D primitivesRenderer, int value, Color color, float size, ref Matrix matrix, DrawBlockEnvironmentData environmentData)
	{
		BlocksManager.DrawMeshBlock(primitivesRenderer, m_blockMesh, color, size, ref matrix, environmentData);
	}

	public override BoundingBox[] GetCustomCollisionBoxes(SubsystemTerrain terrain, int value)
	{
		return m_collisionBoxes;
	}
}

// ============================================================================
// 5. Physics Manipulator: Handheld Physics Mover & Kinetic Wrench
// ============================================================================
public class PhysicsMoverBlock : Block
{
	public BlockMesh m_standaloneMesh = new BlockMesh();
	public BoundingBox[] m_collisionBoxes = new BoundingBox[1];

	public PhysicsMoverBlock()
	{
		DefaultDisplayName = "Manipulator Fisika";
		DefaultDescription = "Alat manipulator gravitasi dan penahan fisika. Ketuk untuk mengangkat dan membawa struktur sub-level. Serang/pukul untuk melontarkan gaya kinetik pendorong.";
		DefaultCategory = "Tools";
		MaxStacking = 1;
		IsCollidable = true;
		IsPlaceable = true;
	}

	public override void Initialize()
	{
		m_standaloneMesh = new BlockMesh();
		// Heavy insulated handle grip
		ProceduralMeshHelper.AddBox(m_standaloneMesh, new Vector3(0.42f, 0.0f, 0.42f), new Vector3(0.58f, 0.55f, 0.58f), new Color(45, 48, 52), 19);
		// Magnetic induction emitter core (cyan glow)
		ProceduralMeshHelper.AddBox(m_standaloneMesh, new Vector3(0.32f, 0.55f, 0.35f), new Vector3(0.68f, 0.72f, 0.65f), new Color(30, 160, 255), 143);
		// Left field prong
		ProceduralMeshHelper.AddBox(m_standaloneMesh, new Vector3(0.30f, 0.72f, 0.42f), new Vector3(0.40f, 0.95f, 0.58f), new Color(210, 215, 225), 19);
		// Right field prong
		ProceduralMeshHelper.AddBox(m_standaloneMesh, new Vector3(0.60f, 0.72f, 0.42f), new Vector3(0.70f, 0.95f, 0.58f), new Color(210, 215, 225), 19);

		m_collisionBoxes[0] = new BoundingBox(new Vector3(0.25f, 0.0f, 0.25f), new Vector3(0.75f, 0.95f, 0.75f));
		base.Initialize();
	}

	public override void GenerateTerrainVertices(BlockGeometryGenerator generator, TerrainGeometry geometry, int value, int x, int y, int z)
	{
		generator.GenerateMeshVertices(this, x, y, z, m_standaloneMesh, Color.White, null, geometry.SubsetOpaque);
	}

	public override void DrawBlock(PrimitivesRenderer3D primitivesRenderer, int value, Color color, float size, ref Matrix matrix, DrawBlockEnvironmentData environmentData)
	{
		BlocksManager.DrawMeshBlock(primitivesRenderer, m_standaloneMesh, color, size, ref matrix, environmentData);
	}

	public override BoundingBox[] GetCustomCollisionBoxes(SubsystemTerrain terrain, int value)
	{
		return m_collisionBoxes;
	}
}
