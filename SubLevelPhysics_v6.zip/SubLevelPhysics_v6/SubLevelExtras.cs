// Sub-level physics mod v5 - Sable style extras:
//  1. Riding: players and animals stand on, walk on and are carried by moving / rotating bodies ("entities stick to sub-levels").
//  2. Building on bodies: hold a block and tap the side of a body block to add it to the body.
//  3. Splitting: when a body falls apart (blocks dug), every disconnected piece becomes its own body.
using System;
using System.Collections.Generic;
using Engine;

namespace Game;

public sealed class RideState
{
	public SubLevel Level;
	public PVec3 Cell;          // feet position in the body's cell frame (the frame of Cx/Cy/Cz)
	public PMat3 RotAtSet;      // body rotation when the entity position was last written
	public PVec3 WorldAtSet;    // entity position as last written by us
	public float Yaw;           // body yaw when the entity position was last written
	public float Airborne;      // seconds without a floor under the feet
}

public partial class SubLevelPhysicsLoader
{
	readonly Dictionary<ComponentBody, RideState> m_riders = new Dictionary<ComponentBody, RideState>();
	readonly List<ComponentBody> m_deadRiders = new List<ComponentBody>();

	// ================================================================ riding

	static float YawOf(PMat3 R)
	{
		return MathF.Atan2(R.M02, R.M00);
	}

	bool BoxHits(SubLevel level, PVec3 feet, float radius, float height)
	{
		int x0 = (int)MathF.Floor(feet.X - radius);
		int x1 = (int)MathF.Floor(feet.X + radius);
		int y0 = (int)MathF.Floor(feet.Y);
		int y1 = (int)MathF.Floor(feet.Y + height - 0.001f);
		int z0 = (int)MathF.Floor(feet.Z - radius);
		int z1 = (int)MathF.Floor(feet.Z + radius);
		for (int x = x0; x <= x1; x++)
		{
			for (int y = y0; y <= y1; y++)
			{
				for (int z = z0; z <= z1; z++)
				{
					int idx;
					if (level.Index.TryGetValue(new Point3(x, y, z), out idx) && StructureScanner.IsSolid(level.Values[idx]))
					{
						return true;
					}
				}
			}
		}
		return false;
	}

	// Block value directly under the feet (cell frame), or 0.
	int FloorValue(SubLevel level, PVec3 feet, float radius)
	{
		int y = (int)MathF.Floor(feet.Y - 0.06f);
		int x0 = (int)MathF.Floor(feet.X - radius);
		int x1 = (int)MathF.Floor(feet.X + radius);
		int z0 = (int)MathF.Floor(feet.Z - radius);
		int z1 = (int)MathF.Floor(feet.Z + radius);
		for (int x = x0; x <= x1; x++)
		{
			for (int z = z0; z <= z1; z++)
			{
				int idx;
				if (level.Index.TryGetValue(new Point3(x, y, z), out idx) && StructureScanner.IsSolid(level.Values[idx]))
				{
					return level.Values[idx];
				}
			}
		}
		return 0;
	}

	PVec3 CellToWorld(SubLevel level, PVec3 cell)
	{
		return level.Body.LocalToWorld(cell - level.Body.CenterOfMass);
	}

	PVec3 WorldToCell(SubLevel level, PVec3 world)
	{
		return level.Body.WorldToLocal(world) + level.Body.CenterOfMass;
	}

	bool IsPilotBody(ComponentBody b)
	{
		for (int i = 0; i < m_levels.Count; i++)
		{
			ShipData ship = m_levels[i].Ship;
			if (ship != null && ship.Pilot != null && ship.Pilot.ComponentBody == b)
			{
				return true;
			}
		}
		return false;
	}

	// Called right after the game moved 'b' (ComponentBody.Update postfix): carries it with the body it stands on.
	public void CarryBody(ComponentBody b)
	{
		if (m_levels.Count == 0 || b == null)
		{
			if (m_riders.Count > 0)
			{
				m_riders.Clear();
			}
			return;
		}
		try
		{
			if (b.ParentBody != null || IsPilotBody(b))
			{
				return;
			}
			Vector3 P = b.Position;
			Vector3 box = b.StanceBoxSize;
			float radius = box.X * 0.5f;
			float height = box.Y;
			float dt = (m_subsystemTime != null) ? Math.Min(m_subsystemTime.GameTimeDelta, 0.1f) : 0.016f;

			RideState rs;
			if (m_riders.TryGetValue(b, out rs))
			{
				if (!m_levels.Contains(rs.Level))
				{
					m_riders.Remove(b);
					return;
				}
				UpdateRider(b, rs, P, radius, height, dt);
				return;
			}
			TryBoard(b, P, radius, height);
		}
		catch (Exception ex)
		{
			Log.Error("SubLevel: carry failed: " + ex);
			m_riders.Remove(b);
		}
	}

	void TryBoard(ComponentBody b, Vector3 P, float radius, float height)
	{
		if (b.Velocity.Y > 2f)
		{
			return;
		}
		for (int li = 0; li < m_levels.Count; li++)
		{
			SubLevel level = m_levels[li];
			RigidBody3D body = level.Body;
			PVec3 half = (level.BoundsMax - level.BoundsMin) * 0.5f;
			float reach = half.Length + 3f;
			float dx = P.X - body.Position.X;
			float dy = P.Y - body.Position.Y;
			float dz = P.Z - body.Position.Z;
			if (dx * dx + dy * dy + dz * dz > reach * reach)
			{
				continue;
			}
			PMat3 R = body.Rotation.ToMat3();
			if (R.M11 < SubLevelConfig.RideMinUpright)
			{
				continue;
			}
			PVec3 cell = WorldToCell(level, new PVec3(P.X, P.Y, P.Z));
			if (cell.X < level.BoundsMin.X - radius - 1f || cell.X > level.BoundsMax.X + radius + 1f
				|| cell.Z < level.BoundsMin.Z - radius - 1f || cell.Z > level.BoundsMax.Z + radius + 1f
				|| cell.Y < level.BoundsMin.Y - height - 1f || cell.Y > level.BoundsMax.Y + 2f)
			{
				continue;
			}
			// feet slightly inside the deck (fell onto it quickly): lift up to half a block onto the surface
			bool boarded = false;
			PVec3 at = cell;
			for (int step = 0; step <= 5; step++)
			{
				PVec3 t = new PVec3(cell.X, cell.Y + 0.1f * step, cell.Z);
				if (!BoxHits(level, t, radius, height))
				{
					if (FloorValue(level, t, radius) != 0)
					{
						at = t;
						boarded = true;
					}
					break;
				}
			}
			if (boarded)
			{
				RideState rs = new RideState();
				rs.Level = level;
				rs.Cell = at;
				rs.RotAtSet = R;
				PVec3 w0 = CellToWorld(level, at);
				rs.WorldAtSet = w0;
				rs.Yaw = YawOf(R);
				b.Position = new Vector3(w0.X, w0.Y, w0.Z);
				m_riders[b] = rs;
				return;
			}
			if (BoxHits(level, cell, radius, height))
			{
				PushOut(b, level, cell, R, radius, height);
				return;
			}
		}
	}

	// Walls of a body are solid for entities outside it: move the entity out through the nearest free side.
	void PushOut(ComponentBody b, SubLevel level, PVec3 cell, PMat3 R, float radius, float height)
	{
		float bestDist = 0.75f;
		PVec3 best = default(PVec3);
		bool found = false;
		for (int s = 1; s <= 15; s++)
		{
			float d = 0.05f * s;
			if (d >= bestDist)
			{
				break;
			}
			PVec3[] tries =
			{
				new PVec3(d, 0f, 0f), new PVec3(-d, 0f, 0f), new PVec3(0f, 0f, d), new PVec3(0f, 0f, -d)
			};
			for (int k = 0; k < tries.Length; k++)
			{
				PVec3 t = cell + tries[k];
				if (!BoxHits(level, t, radius, height))
				{
					bestDist = d;
					best = tries[k];
					found = true;
					break;
				}
			}
			if (found)
			{
				break;
			}
		}
		if (!found)
		{
			return;
		}
		PVec3 w = R.Mul(best);
		Vector3 p = b.Position;
		b.Position = new Vector3(p.X + w.X, p.Y + w.Y, p.Z + w.Z);
		Vector3 v = b.Velocity;
		float into = v.X * w.X + v.Z * w.Z;
		float len2 = w.X * w.X + w.Z * w.Z;
		if (len2 > 1e-8f && into < 0f)
		{
			float k = into / len2;
			b.Velocity = new Vector3(v.X - k * w.X, v.Y, v.Z - k * w.Z);
		}
	}

	void UpdateRider(ComponentBody b, RideState rs, Vector3 P, float radius, float height, float dt)
	{
		SubLevel level = rs.Level;
		RigidBody3D body = level.Body;

		// entity was teleported / respawned far away
		PVec3 own = new PVec3(P.X - rs.WorldAtSet.X, P.Y - rs.WorldAtSet.Y, P.Z - rs.WorldAtSet.Z);
		if (own.Length > 4f)
		{
			m_riders.Remove(b);
			return;
		}

		// the entity's own motion this frame (walking, gravity, jumping), expressed in the body's cell frame
		PVec3 dl = rs.RotAtSet.Transpose().Mul(own);
		PVec3 c = rs.Cell;

		// axis separated collision against the body's blocks
		if (dl.X != 0f)
		{
			PVec3 t = new PVec3(c.X + dl.X, c.Y, c.Z);
			if (!BoxHits(level, t, radius, height)) c = t;
		}
		if (dl.Z != 0f)
		{
			PVec3 t = new PVec3(c.X, c.Y, c.Z + dl.Z);
			if (!BoxHits(level, t, radius, height)) c = t;
		}
		bool landed = false;
		if (dl.Y != 0f)
		{
			PVec3 t = new PVec3(c.X, c.Y + dl.Y, c.Z);
			if (!BoxHits(level, t, radius, height))
			{
				c = t;
			}
			else
			{
				if (dl.Y < 0f)
				{
					landed = true;
					// rest exactly on top of the block under the feet
					c = new PVec3(c.X, MathF.Floor(c.Y + dl.Y) + 1f, c.Z);
					if (BoxHits(level, c, radius, height))
					{
						c = new PVec3(c.X, rs.Cell.Y, c.Z);
					}
				}
				Vector3 v = b.Velocity;
				b.Velocity = new Vector3(v.X, 0f, v.Z);
			}
		}

		int floor = FloorValue(level, c, radius);
		bool supported = landed || floor != 0;
		if (supported)
		{
			rs.Airborne = 0f;
		}
		else
		{
			rs.Airborne += dt;
		}

		PMat3 R = body.Rotation.ToMat3();
		PVec3 world = CellToWorld(level, c);

		if (rs.Airborne > SubLevelConfig.RideGrace || R.M11 < 0.2f)
		{
			// left the body: keep its momentum (Sable: entities keep the velocity of what they stood on)
			PVec3 arm = world - body.Position;
			PVec3 carry = body.Velocity + PVec3.Cross(body.AngularVelocity, arm);
			Vector3 v = b.Velocity;
			b.Velocity = new Vector3(v.X + carry.X, v.Y + carry.Y, v.Z + carry.Z);
			m_riders.Remove(b);
			return;
		}

		// follow the body: new world position from the corrected cell-frame position, turn with the body's yaw
		float yaw = YawOf(R);
		float dyaw = yaw - rs.Yaw;
		while (dyaw > MathF.PI) dyaw -= 2f * MathF.PI;
		while (dyaw < -MathF.PI) dyaw += 2f * MathF.PI;
		if (MathF.Abs(dyaw) > 1e-5f)
		{
			Quaternion q = b.Rotation;
			float angle = MathF.Atan2(2f * q.Y * q.W - 2f * q.X * q.Z, 1f - 2f * q.Y * q.Y - 2f * q.Z * q.Z);
			b.Rotation = Quaternion.CreateFromAxisAngle(Vector3.UnitY, angle + dyaw);
		}
		b.Position = new Vector3(world.X, world.Y, world.Z);
		if (supported && floor != 0)
		{
			b.StandingOnValue = floor;   // lets the player walk with ground friction and jump from the deck
		}
		rs.Cell = c;
		rs.RotAtSet = R;
		rs.WorldAtSet = world;
		rs.Yaw = yaw;
	}

	// ================================================================ build on bodies

	bool TryPlaceOnBody(ComponentPlayer p, ComponentMiner miner, Ray3 ray, int active)
	{
		Block block = BlocksManager.Blocks[Terrain.ExtractContents(active)];
		if (!block.IsPlaceable_(active))
		{
			return false;
		}
		SubLevel level;
		int index;
		float distance;
		Vector3 point;
		if (!TryBodyHit(ray, out level, out index, out distance, out point))
		{
			return false;
		}
		bool crouching = p.ComponentBody.IsCrouching;
		int hitValue = level.Values[index];
		Block hitBlock = BlocksManager.Blocks[Terrain.ExtractContents(hitValue)];
		bool isInteractive = ToolConfig.IsLever(hitValue) || ToolConfig.IsHelm(hitValue)
			|| hitBlock is DoorBlock || hitBlock is TrapdoorBlock || hitBlock is FenceGateBlock
			|| hitBlock is ChestBlock || hitBlock is SwitchBlock || hitBlock is ButtonBlock;
		if (!crouching && isInteractive)
		{
			return false; // tap interactive blocks normally; crouch to build next to them
		}
		if (level.Count >= SubLevelConfig.MaxBlocksPerBody)
		{
			Say(p, "Benda sudah penuh (maks " + SubLevelConfig.MaxBlocksPerBody + " blok).");
			return true;
		}

		// which face of the hit block was tapped (cell frame)
		PVec3 hp = WorldToCell(level, new PVec3(point.X, point.Y, point.Z));
		PVec3 center = new PVec3(level.Cx[index] + 0.5f, level.Cy[index] + 0.5f, level.Cz[index] + 0.5f);
		PVec3 d = hp - center;
		float ax = MathF.Abs(d.X), ay = MathF.Abs(d.Y), az = MathF.Abs(d.Z);
		Point3 n;
		if (ax >= ay && ax >= az) n = new Point3(d.X > 0f ? 1 : -1, 0, 0);
		else if (ay >= ax && ay >= az) n = new Point3(0, d.Y > 0f ? 1 : -1, 0);
		else n = new Point3(0, 0, d.Z > 0f ? 1 : -1);
		Point3 target = new Point3(level.Cx[index] + n.X, level.Cy[index] + n.Y, level.Cz[index] + n.Z);
		if (level.Index.ContainsKey(target))
		{
			return true;
		}

		// do not wall in the player who is building
		Vector3 pp = p.ComponentBody.Position;
		PVec3 pc = WorldToCell(level, new PVec3(pp.X, pp.Y, pp.Z));
		if (pc.X > target.X - 0.3f && pc.X < target.X + 1.3f && pc.Z > target.Z - 0.3f && pc.Z < target.Z + 1.3f
			&& pc.Y > target.Y - 1.7f && pc.Y < target.Y + 1f)
		{
			return true;
		}

		// let the block decide its own data (orientation of stairs etc.); fall back to the plain item value
		int placeValue = active;
		try
		{
			PVec3 wc = CellToWorld(level, center);
			PVec3 wn = level.Body.Rotation.ToMat3().Mul(new PVec3(n.X, n.Y, n.Z));
			int face;
			float awx = MathF.Abs(wn.X), awy = MathF.Abs(wn.Y), awz = MathF.Abs(wn.Z);
			if (awx >= awy && awx >= awz) face = wn.X > 0f ? 1 : 3;
			else if (awy >= awx && awy >= awz) face = wn.Y > 0f ? 4 : 5;
			else face = wn.Z > 0f ? 0 : 2;
			TerrainRaycastResult fake = new TerrainRaycastResult();
			fake.Ray = ray;
			fake.Distance = distance;
			fake.Value = hitValue;
			fake.CellFace = new CellFace((int)MathF.Floor(wc.X), (int)MathF.Floor(wc.Y), (int)MathF.Floor(wc.Z), face);
			BlockPlacementData data = block.GetPlacementValue(m_subsystemTerrain, miner, active, fake);
			if (data.Value != 0)
			{
				placeValue = data.Value;
			}
		}
		catch
		{
			placeValue = active;
		}

		float mass = Math.Max(0.1f, BlocksManager.Blocks[Terrain.ExtractContents(placeValue)].GetDensity(placeValue));
		level.AddBlock(placeValue, target, mass);
		RebuildBody(level);
		level.Body.Wake();
		if (level.Ship != null)
		{
			ComputeShipStats(level, level.Ship);
		}
		if (m_subsystemGameInfo == null || m_subsystemGameInfo.WorldSettings.GameMode != GameMode.Creative)
		{
			miner.RemoveActiveTool(1);
		}
		miner.Poke(false);
		return true;
	}

	// ================================================================ splitting

	// Called after a block was removed from the arrays (and before RebuildBody). Pieces that are no longer connected to the
	// main part (the one with the helm, otherwise the biggest) become independent bodies.
	void SplitDisconnected(SubLevel level)
	{
		int n = level.Count;
		if (n < 2)
		{
			return;
		}
		Dictionary<Point3, int> index = new Dictionary<Point3, int>();
		for (int i = 0; i < n; i++)
		{
			index[new Point3(level.Cx[i], level.Cy[i], level.Cz[i])] = i;
		}
		int[] comp = new int[n];
		for (int i = 0; i < n; i++)
		{
			comp[i] = -1;
		}
		List<List<int>> comps = new List<List<int>>();
		Point3[] dirs =
		{
			new Point3(1, 0, 0), new Point3(-1, 0, 0), new Point3(0, 1, 0),
			new Point3(0, -1, 0), new Point3(0, 0, 1), new Point3(0, 0, -1)
		};
		for (int i = 0; i < n; i++)
		{
			if (comp[i] >= 0)
			{
				continue;
			}
			List<int> members = new List<int>();
			Queue<int> queue = new Queue<int>();
			queue.Enqueue(i);
			comp[i] = comps.Count;
			while (queue.Count > 0)
			{
				int k = queue.Dequeue();
				members.Add(k);
				for (int d = 0; d < 6; d++)
				{
					int j;
					if (index.TryGetValue(new Point3(level.Cx[k] + dirs[d].X, level.Cy[k] + dirs[d].Y, level.Cz[k] + dirs[d].Z), out j) && comp[j] < 0)
					{
						comp[j] = comps.Count;
						queue.Enqueue(j);
					}
				}
			}
			comps.Add(members);
		}
		if (comps.Count <= 1)
		{
			return;
		}

		int keep = 0;
		bool helm = false;
		for (int c = 0; c < comps.Count && !helm; c++)
		{
			for (int m = 0; m < comps[c].Count; m++)
			{
				if (ToolConfig.IsHelm(level.Values[comps[c][m]]))
				{
					keep = c;
					helm = true;
					break;
				}
			}
		}
		if (!helm)
		{
			for (int c = 1; c < comps.Count; c++)
			{
				if (comps[c].Count > comps[keep].Count)
				{
					keep = c;
				}
			}
		}

		RigidBody3D old = level.Body;
		PMat3 R = old.Rotation.ToMat3();
		List<SubLevel> fragments = new List<SubLevel>();
		for (int c = 0; c < comps.Count; c++)
		{
			if (c == keep)
			{
				continue;
			}
			List<int> part = comps[c];
			if (m_levels.Count + fragments.Count + 1 >= SubLevelConfig.MaxTotalBodies)
			{
				// too many bodies: this piece breaks into items
				for (int m = 0; m < part.Count; m++)
				{
					int s = part[m];
					PVec3 w = old.LocalToWorld(new PVec3(level.Cx[s] + 0.5f - old.CenterOfMass.X, level.Cy[s] + 0.5f - old.CenterOfMass.Y, level.Cz[s] + 0.5f - old.CenterOfMass.Z));
					DropBlock(level.Values[s], new Vector3(w.X, w.Y, w.Z), 0);
				}
				continue;
			}
			SubLevel frag = new SubLevel();
			frag.Count = part.Count;
			frag.Values = new int[part.Count];
			frag.Cx = new int[part.Count];
			frag.Cy = new int[part.Count];
			frag.Cz = new int[part.Count];
			frag.Mass = new float[part.Count];
			for (int m = 0; m < part.Count; m++)
			{
				int s = part[m];
				frag.Values[m] = level.Values[s];
				frag.Cx[m] = level.Cx[s];
				frag.Cy[m] = level.Cy[s];
				frag.Cz[m] = level.Cz[s];
				frag.Mass[m] = level.Mass[s];
			}
			RigidBody3D nb = new RigidBody3D(frag.Cx, frag.Cy, frag.Cz, frag.Mass, frag.Count);
			PVec3 shift = R.Mul(nb.CenterOfMass - old.CenterOfMass);
			nb.Rotation = old.Rotation;
			nb.Position = old.Position + shift;
			nb.AngularVelocity = old.AngularVelocity;
			nb.Velocity = old.Velocity + PVec3.Cross(old.AngularVelocity, shift);
			frag.Body = nb;
			frag.RebuildLocal();
			frag.RebuildIndex();
			frag.Humidity = level.Humidity;
			frag.Temperature = level.Temperature;
			fragments.Add(frag);
		}

		// the original keeps only the main part
		List<int> main = comps[keep];
		int[] values = new int[main.Count];
		int[] cx = new int[main.Count];
		int[] cy = new int[main.Count];
		int[] cz = new int[main.Count];
		float[] mass = new float[main.Count];
		for (int m = 0; m < main.Count; m++)
		{
			int s = main[m];
			values[m] = level.Values[s];
			cx[m] = level.Cx[s];
			cy[m] = level.Cy[s];
			cz[m] = level.Cz[s];
			mass[m] = level.Mass[s];
		}
		level.Values = values;
		level.Cx = cx;
		level.Cy = cy;
		level.Cz = cz;
		level.Mass = mass;
		level.Count = main.Count;

		for (int f = 0; f < fragments.Count; f++)
		{
			fragments[f].Body.Wake();
			m_levels.Add(fragments[f]);
		}
	}
}
