// Sub-level physics mod - shared data and helpers: configuration, tool/role blocks, tree scanner, bodies,
// glue groups (saved per world) and ray casting against rotated bodies.
using System;
using System.Collections.Generic;
using System.Text;
using Engine;

namespace Game;

public static class SubLevelConfig
{
	public const int MaxBlocksPerBody = 700;       // blocks in one body (glue group or tree)
	public const int MaxBodies = 8;                // simultaneous physics bodies (glue groups, trees)
	public const int MaxTotalBodies = 16;          // hard cap including fragments from broken structures
	public const float RideGrace = 0.2f;           // seconds an entity stays carried after losing the floor (jump, step off)
	public const float RideMinUpright = 0.5f;      // body must be this upright (cos of tilt) before entities can board
	public const int MaxLeafDistance = 3;          // leaves farther than this from a log are not part of a tree
	public const float MaxBodyAge = 40f;           // seconds; felled trees are forced to settle after this
	public const float MaxVisibleDistance = 160f;
	public const bool AutoTrees = true;            // felled trees topple by themselves (no glue / lever needed)
	public const float TreeKick = 0.25f;           // initial angular speed of a falling tree (rad/s)
	public const float TreeReleaseTilt = 0.8f;     // radians; the hinge is released after this much tilt
	public const bool RestoreBlocks = true;        // false = a tree that lands is dropped as items instead of placed
	public const float ReachDistance = 6f;         // reach for digging / interacting with bodies
	public const int MaxGlueBox = 24;              // longest edge of a glue box
	public const float LeverPollInterval = 0.25f;  // seconds between lever checks
	public const float LeverScanInterval = 3f;     // seconds between searches for levers next to a group
	public const float GroupActiveDistance = 48f;  // groups farther than this from every player are ignored
	public const float PushSpeed = 6f;             // magnet push: speed given to the body (m/s)
	public const float GrabMaxDistance = 14f;      // magnet grab is released beyond this distance
	public const float WakeInterval = 2f;          // sleeping bodies re-check the terrain below them this often
}

// Which vanilla blocks play which role. Change the classes here to use other items.
public static class ToolConfig
{
	static Block BlockOf(int value) { return BlocksManager.Blocks[Terrain.ExtractContents(value)]; }

	public static bool IsGlue(int value)
	{
		Block b = BlockOf(value);
		return b is PhysicsGlueBlock || b is CottonWadBlock;
	}

	public static bool IsMover(int value)
	{
		Block b = BlockOf(value);
		return b is PhysicsMoverBlock || b is MagnetBlock;
	}

	public static bool IsLever(int value)
	{
		Block b = BlockOf(value);
		return b is PhysicsLeverBlock || b is SwitchBlock;
	}

	public static bool IsHelm(int value)
	{
		Block b = BlockOf(value);
		return b is PhysicsHelmBlock || b is CraftingTableBlock;
	}

	public static bool IsEnvelope(int value)
	{
		Block b = BlockOf(value);
		return b is CanvasBlock;
	}

	public static bool IsEngine(int value)
	{
		Block b = BlockOf(value);
		return b is PhysicsEngineBlock || b is FurnaceBlock || b is LitFurnaceBlock;
	}
}

// Airship tuning.
public static class ShipConfig
{
	public const float RequiredEnvelopeFraction = 0.30f; // share of balloon blocks that gives exactly hover lift
	public const float HoverFactor = 0.98f;              // lift / weight with no input (sinks very slowly)
	public const float AscendBonus = 0.45f;              // extra lift while Jump is held
	public const float VerticalDrag = 0.9f;              // damping of vertical speed (1/s)
	public const float RequiredEngineFraction = 0.06f;   // share of engine blocks that gives ThrustAccelAtRequired
	public const float ThrustAccelAtRequired = 4f;       // m/s^2
	public const float MaxThrustAccel = 8f;
	public const float YawRate = 0.9f;                   // rad/s at full stick
	public const float YawResponse = 2.5f;
	public const float RightingAccel = 5f;               // rad/s^2 that keeps the ship level
	public const float TiltDamping = 2.5f;
	public const float LinearDamping = 0.3f;             // air drag (1/s): top speed = accel / this
	public const float AngularDamping = 0.6f;
	public const float DismountGrace = 0.8f;             // seconds after boarding before dismount input counts
}

// Decides which blocks form a tree (or other structure) and whether it is anchored.
public static class StructureScanner
{
	static readonly Point3[] Neighbors6 =
	{
		new Point3(1, 0, 0), new Point3(-1, 0, 0), new Point3(0, 1, 0),
		new Point3(0, -1, 0), new Point3(0, 0, 1), new Point3(0, 0, -1)
	};

	static Block BlockOf(int value)
	{
		return BlocksManager.Blocks[Terrain.ExtractContents(value)];
	}

	public static bool IsLog(int value) { return BlockOf(value) is WoodBlock; }

	public static bool IsLeaves(int value) { return BlockOf(value) is LeavesBlock; }

	// Blocks that players build with (and trees). Natural terrain (dirt, grass, stone, sand, ores...) is NOT structural,
	// it counts as ground that supports structures.
	public static bool IsStructural(int value)
	{
		if (Terrain.ExtractContents(value) == 0)
		{
			return false;
		}
		Block b = BlockOf(value);
		return b is WoodBlock || b is LeavesBlock || b is PlanksBlock || b is BrickBlock || b is BricksBlock
			|| b is StoneBrickBlock || b is CobblestoneBlock || b is GlassBlock || b is FramedGlassBlock
			|| b is PaintedCubeBlock || b is SlabBlock || b is StairsBlock || b is FenceBlock || b is WindowBlock
			|| b is IronBlock || b is CopperBlock || b is DiamondBlock
			|| b is CanvasBlock || b is FurnaceBlock || b is LitFurnaceBlock || b is CraftingTableBlock
			|| b is DoorBlock || b is TrapdoorBlock || b is FenceGateBlock || b is ChestBlock
			|| b is WireBlock || b is ElectricElementBlock || b is MountedElectricElementBlock
			|| b is PhysicsGlueBlock || b is PhysicsLeverBlock || b is PhysicsHelmBlock
			|| b is PhysicsEngineBlock || b is PhysicsMoverBlock;
	}

	// Full, opaque cube: hides the faces of its neighbors (used to skip drawing enclosed blocks).
	public static bool IsOpaqueCube(int value)
	{
		int c = Terrain.ExtractContents(value);
		if (c == 0)
		{
			return false;
		}
		Block b = BlocksManager.Blocks[c];
		return b is CubeBlock && !b.IsTransparent_(value);
	}

	public static bool IsSolid(int value)
	{
		int c = Terrain.ExtractContents(value);
		return c != 0 && BlocksManager.Blocks[c].IsCollidable_(value);
	}

	// Blocks that super glue can stick: building blocks plus a few attachments (lever, torch, ladder).
	public static bool IsGluable(int value)
	{
		int c = Terrain.ExtractContents(value);
		if (c == 0)
		{
			return false;
		}
		Block b = BlocksManager.Blocks[c];
		if (b is FluidBlock)
		{
			return false;
		}
		return IsStructural(value) || b is SwitchBlock || b is TorchBlock || b is LadderBlock;
	}

	// Collects the structure containing 'seed' (not a leaf block). Returns false if it is too big.
	// cells: non-leaf blocks first (nonLeafCount of them), then leaves. anchored = supported by the ground.
	public static bool Scan(Terrain terrain, Point3 seed, HashSet<Point3> claimed,
		out List<Point3> cells, out int nonLeafCount, out bool treeLike, out bool anchored)
	{
		cells = new List<Point3>();
		nonLeafCount = 0;
		treeLike = false;
		anchored = false;
		bool supportedBelow = false;
		bool supportedSide = false;
		int logs = 0;
		bool tooBig = false;

		Queue<Point3> queue = new Queue<Point3>();
		claimed.Add(seed);
		queue.Enqueue(seed);
		while (queue.Count > 0)
		{
			Point3 p = queue.Dequeue();
			cells.Add(p);
			if (cells.Count > SubLevelConfig.MaxBlocksPerBody)
			{
				tooBig = true;
				break;
			}
			int v = terrain.GetCellValue(p.X, p.Y, p.Z);
			if (IsLog(v))
			{
				logs++;
			}
			for (int i = 0; i < 6; i++)
			{
				Point3 n = new Point3(p.X + Neighbors6[i].X, p.Y + Neighbors6[i].Y, p.Z + Neighbors6[i].Z);
				int nv = terrain.GetCellValue(n.X, n.Y, n.Z);
				if (IsSolid(nv) && !IsStructural(nv))
				{
					if (Neighbors6[i].Y == -1)
					{
						supportedBelow = true;
					}
					else
					{
						supportedSide = true;
					}
				}
			}
			for (int dx = -1; dx <= 1; dx++)
			{
				for (int dy = -1; dy <= 1; dy++)
				{
					for (int dz = -1; dz <= 1; dz++)
					{
						if (dx == 0 && dy == 0 && dz == 0)
						{
							continue;
						}
						Point3 n = new Point3(p.X + dx, p.Y + dy, p.Z + dz);
						if (n.Y < 0 || n.Y > 255 || claimed.Contains(n))
						{
							continue;
						}
						int nv = terrain.GetCellValue(n.X, n.Y, n.Z);
						if (IsStructural(nv) && !IsLeaves(nv))
						{
							claimed.Add(n);
							queue.Enqueue(n);
						}
					}
				}
			}
		}
		if (tooBig)
		{
			return false;
		}
		nonLeafCount = cells.Count;
		treeLike = (logs == nonLeafCount);
		anchored = supportedBelow || (!treeLike && supportedSide);
		if (anchored)
		{
			return true;
		}

		// Leaves belong to the structure when they are within a few cells of one of its logs.
		if (logs > 0)
		{
			Dictionary<Point3, int> distance = new Dictionary<Point3, int>();
			Queue<Point3> leafQueue = new Queue<Point3>();
			for (int i = 0; i < nonLeafCount; i++)
			{
				if (IsLog(terrain.GetCellValue(cells[i].X, cells[i].Y, cells[i].Z)))
				{
					distance[cells[i]] = 0;
					leafQueue.Enqueue(cells[i]);
				}
			}
			while (leafQueue.Count > 0)
			{
				Point3 p = leafQueue.Dequeue();
				int d = distance[p];
				if (d >= SubLevelConfig.MaxLeafDistance)
				{
					continue;
				}
				for (int i = 0; i < 6; i++)
				{
					Point3 n = new Point3(p.X + Neighbors6[i].X, p.Y + Neighbors6[i].Y, p.Z + Neighbors6[i].Z);
					if (n.Y < 0 || n.Y > 255 || distance.ContainsKey(n) || claimed.Contains(n))
					{
						continue;
					}
					if (IsLeaves(terrain.GetCellValue(n.X, n.Y, n.Z)))
					{
						distance[n] = d + 1;
						claimed.Add(n);
						cells.Add(n);
						if (cells.Count > SubLevelConfig.MaxBlocksPerBody)
						{
							return false;
						}
						leafQueue.Enqueue(n);
					}
				}
			}
		}
		return true;
	}
}

public sealed class ShipData
{
	public ComponentPlayer Pilot;
	public PVec3 ForwardLocal;           // ship forward / right in body-local space
	public PVec3 RightLocal;
	public PVec3 EnvelopeCentroidLocal;
	public PVec3 SeatLocal;
	public float EnvelopeFraction;
	public float EngineFraction;
}

// A group of blocks that was lifted out of the terrain and now moves as one rigid body.
public sealed class SubLevel
{
	public RigidBody3D Body;
	public int Count;
	public int[] Values;        // block values
	public int[] Cx;            // original cell coordinates of each block (the body's own frame)
	public int[] Cy;
	public int[] Cz;
	public float[] Mass;
	public PVec3[] Local;       // block centers relative to the center of mass (local space)
	public Dictionary<Point3, int> Index = new Dictionary<Point3, int>();
	public PVec3 BoundsMin;     // cell bounds in the body's own frame (max is exclusive)
	public PVec3 BoundsMax;
	public bool[] Hidden;       // block is fully enclosed by opaque cubes: physics only, never drawn
	public bool TreeMode;
	public int Humidity;
	public int Temperature;
	public ShipData Ship;       // non-null = a piloted airship
	public GlueGroup Group;     // non-null = activated by a lever from a glue group
	public float SleepClock;
	public bool EnginesElectricallyPowered;

	// Simulates internal sub-level electricity: power sources -> conductors -> receivers
	public void UpdateElectrics()
	{
		bool power = false;
		for (int i = 0; i < Count; i++)
		{
			int val = Values[i];
			Block b = BlocksManager.Blocks[Terrain.ExtractContents(val)];
			if (b is PhysicsLeverBlock || b is SwitchBlock)
			{
				if ((Terrain.ExtractData(val) & 1) != 0) // Lever ON
				{
					power = true;
					break;
				}
			}
			else if (b is BatteryBlock)
			{
				power = true;
				break;
			}
		}

		EnginesElectricallyPowered = power;

		// Power lights, doors, engines
		for (int i = 0; i < Count; i++)
		{
			int val = Values[i];
			int content = Terrain.ExtractContents(val);
			Block b = BlocksManager.Blocks[content];
			
			// Electric light: 143 (unlit) <-> 144 (lit)
			if (power && content == 143)
			{
				Values[i] = Terrain.MakeBlockValue(144, 0, Terrain.ExtractData(val));
			}
			else if (!power && content == 144)
			{
				Values[i] = Terrain.MakeBlockValue(143, 0, Terrain.ExtractData(val));
			}
			// Automatic doors on electric signal
			else if (b is DoorBlock)
			{
				int data = Terrain.ExtractData(val);
				bool open = DoorBlock.GetOpen(data);
				if (power && !open)
				{
					Values[i] = Terrain.ReplaceData(val, DoorBlock.SetOpen(data, true));
				}
				else if (!power && open)
				{
					Values[i] = Terrain.ReplaceData(val, DoorBlock.SetOpen(data, false));
				}
			}
			else if (b is TrapdoorBlock)
			{
				int data = Terrain.ExtractData(val);
				bool open = TrapdoorBlock.GetOpen(data);
				if (power && !open)
				{
					Values[i] = Terrain.ReplaceData(val, TrapdoorBlock.SetOpen(data, true));
				}
				else if (!power && open)
				{
					Values[i] = Terrain.ReplaceData(val, TrapdoorBlock.SetOpen(data, false));
				}
			}
		}
	}

	public void RebuildLocal()
	{
		Local = new PVec3[Count];
		for (int i = 0; i < Count; i++)
		{
			Local[i] = new PVec3(Cx[i] + 0.5f - Body.CenterOfMass.X, Cy[i] + 0.5f - Body.CenterOfMass.Y, Cz[i] + 0.5f - Body.CenterOfMass.Z);
		}
	}

	public void RebuildIndex()
	{
		Index.Clear();
		int minX = int.MaxValue, minY = int.MaxValue, minZ = int.MaxValue;
		int maxX = int.MinValue, maxY = int.MinValue, maxZ = int.MinValue;
		for (int i = 0; i < Count; i++)
		{
			Index[new Point3(Cx[i], Cy[i], Cz[i])] = i;
			minX = Math.Min(minX, Cx[i]);
			minY = Math.Min(minY, Cy[i]);
			minZ = Math.Min(minZ, Cz[i]);
			maxX = Math.Max(maxX, Cx[i]);
			maxY = Math.Max(maxY, Cy[i]);
			maxZ = Math.Max(maxZ, Cz[i]);
		}
		BoundsMin = new PVec3(minX, minY, minZ);
		BoundsMax = new PVec3(maxX + 1, maxY + 1, maxZ + 1);

		Hidden = new bool[Count];
		for (int i = 0; i < Count; i++)
		{
			bool enclosed = true;
			for (int d = 0; d < 6 && enclosed; d++)
			{
				int n;
				Point3 q = new Point3(Cx[i] + Face6[d].X, Cy[i] + Face6[d].Y, Cz[i] + Face6[d].Z);
				if (!Index.TryGetValue(q, out n) || !StructureScanner.IsOpaqueCube(Values[n]))
				{
					enclosed = false;
				}
			}
			Hidden[i] = enclosed;
		}
	}

	static readonly Point3[] Face6 =
	{
		new Point3(1, 0, 0), new Point3(-1, 0, 0), new Point3(0, 1, 0),
		new Point3(0, -1, 0), new Point3(0, 0, 1), new Point3(0, 0, -1)
	};

	// Adds one block (the physics body must be rebuilt afterwards).
	public void AddBlock(int value, Point3 cell, float mass)
	{
		int[] values = new int[Count + 1];
		int[] cx = new int[Count + 1];
		int[] cy = new int[Count + 1];
		int[] cz = new int[Count + 1];
		float[] m = new float[Count + 1];
		Array.Copy(Values, values, Count);
		Array.Copy(Cx, cx, Count);
		Array.Copy(Cy, cy, Count);
		Array.Copy(Cz, cz, Count);
		Array.Copy(Mass, m, Count);
		values[Count] = value;
		cx[Count] = cell.X;
		cy[Count] = cell.Y;
		cz[Count] = cell.Z;
		m[Count] = mass;
		Values = values;
		Cx = cx;
		Cy = cy;
		Cz = cz;
		Mass = m;
		Count++;
	}

	// Removes one block from the arrays (the physics body must be rebuilt afterwards).
	public void RemoveAt(int index)
	{
		int[] values = new int[Count - 1];
		int[] cx = new int[Count - 1];
		int[] cy = new int[Count - 1];
		int[] cz = new int[Count - 1];
		float[] mass = new float[Count - 1];
		int j = 0;
		for (int i = 0; i < Count; i++)
		{
			if (i == index)
			{
				continue;
			}
			values[j] = Values[i];
			cx[j] = Cx[i];
			cy[j] = Cy[i];
			cz[j] = Cz[i];
			mass[j] = Mass[i];
			j++;
		}
		Values = values;
		Cx = cx;
		Cy = cy;
		Cz = cz;
		Mass = mass;
		Count--;
	}
}

// Blocks joined with super glue. They only turn into a physics body when a lever next to them is switched on.
public sealed class GlueGroup
{
	public HashSet<Point3> Cells = new HashSet<Point3>();
	public List<Point3> Levers = new List<Point3>();
	public SubLevel Active;            // non-null while the group is a physics body (cells are then stale)
	public double NextLeverScan;
}

public sealed class GlueStore
{
	public readonly List<GlueGroup> Groups = new List<GlueGroup>();
	readonly Dictionary<Point3, GlueGroup> m_byCell = new Dictionary<Point3, GlueGroup>();

	public GlueGroup Find(Point3 cell)
	{
		GlueGroup g;
		return m_byCell.TryGetValue(cell, out g) ? g : null;
	}

	void Index(GlueGroup g)
	{
		foreach (Point3 c in g.Cells)
		{
			m_byCell[c] = g;
		}
	}

	public void Unindex(GlueGroup g)
	{
		foreach (Point3 c in g.Cells)
		{
			GlueGroup other;
			if (m_byCell.TryGetValue(c, out other) && other == g)
			{
				m_byCell.Remove(c);
			}
		}
	}

	// Adds cells as one group; existing groups that contain any of the cells are merged into it.
	public GlueGroup AddCells(List<Point3> cells)
	{
		List<GlueGroup> touched = new List<GlueGroup>();
		for (int i = 0; i < cells.Count; i++)
		{
			GlueGroup g = Find(cells[i]);
			if (g != null && !touched.Contains(g))
			{
				touched.Add(g);
			}
		}
		GlueGroup target;
		if (touched.Count > 0)
		{
			target = touched[0];
			for (int i = 1; i < touched.Count; i++)
			{
				foreach (Point3 c in touched[i].Cells)
				{
					target.Cells.Add(c);
				}
				Groups.Remove(touched[i]);
			}
		}
		else
		{
			target = new GlueGroup();
			Groups.Add(target);
		}
		for (int i = 0; i < cells.Count; i++)
		{
			target.Cells.Add(cells[i]);
		}
		target.Levers.Clear();
		target.NextLeverScan = 0;
		Index(target);
		return target;
	}

	public void RemoveCell(Point3 cell)
	{
		GlueGroup g = Find(cell);
		if (g == null)
		{
			return;
		}
		g.Cells.Remove(cell);
		m_byCell.Remove(cell);
		g.Levers.Remove(cell);
		if (g.Cells.Count == 0 && g.Active == null)
		{
			Groups.Remove(g);
		}
	}

	public void SetCells(GlueGroup g, List<Point3> cells)
	{
		Unindex(g);
		g.Cells = new HashSet<Point3>(cells);
		g.Levers.Clear();
		g.NextLeverScan = 0;
		if (g.Cells.Count == 0)
		{
			Groups.Remove(g);
			return;
		}
		Index(g);
	}

	public void Remove(GlueGroup g)
	{
		Unindex(g);
		Groups.Remove(g);
	}

	public void Clear()
	{
		Groups.Clear();
		m_byCell.Clear();
	}

	// One group per line: x,y,z;x,y,z;...
	public string Serialize()
	{
		StringBuilder sb = new StringBuilder();
		sb.Append("SubLevelGlue 1\n");
		for (int i = 0; i < Groups.Count; i++)
		{
			bool first = true;
			foreach (Point3 c in Groups[i].Cells)
			{
				if (!first)
				{
					sb.Append(';');
				}
				first = false;
				sb.Append(c.X).Append(',').Append(c.Y).Append(',').Append(c.Z);
			}
			sb.Append('\n');
		}
		return sb.ToString();
	}

	public void Deserialize(string text)
	{
		Clear();
		string[] lines = text.Split('\n');
		for (int i = 1; i < lines.Length; i++)
		{
			string line = lines[i].Trim();
			if (line.Length == 0)
			{
				continue;
			}
			GlueGroup g = new GlueGroup();
			string[] parts = line.Split(';');
			for (int j = 0; j < parts.Length; j++)
			{
				string[] xyz = parts[j].Split(',');
				int x, y, z;
				if (xyz.Length == 3 && int.TryParse(xyz[0], out x) && int.TryParse(xyz[1], out y) && int.TryParse(xyz[2], out z))
				{
					g.Cells.Add(new Point3(x, y, z));
				}
			}
			if (g.Cells.Count > 0)
			{
				Groups.Add(g);
				Index(g);
			}
		}
	}
}

// Ray casting against bodies: the ray is moved into the body's own (unrotated) frame and walked through the block grid.
public static class BodyRaycaster
{
	public static bool Raycast(List<SubLevel> levels, Ray3 ray, float maxDistance,
		out SubLevel hitLevel, out int hitIndex, out float hitDistance, out Vector3 hitPoint)
	{
		hitLevel = null;
		hitIndex = -1;
		hitDistance = maxDistance;
		hitPoint = Vector3.Zero;
		Vector3 dir = Vector3.Normalize(ray.Direction);
		for (int li = 0; li < levels.Count; li++)
		{
			SubLevel level = levels[li];
			float dist;
			int index;
			if (RaycastLevel(level, ray.Position, dir, hitDistance, out index, out dist) && dist <= hitDistance)
			{
				hitLevel = level;
				hitIndex = index;
				hitDistance = dist;
				hitPoint = ray.Position + dir * dist;
			}
		}
		return hitLevel != null;
	}

	static bool RaycastLevel(SubLevel level, Vector3 origin, Vector3 dir, float maxDistance, out int hitIndex, out float hitDistance)
	{
		hitIndex = -1;
		hitDistance = 0f;
		RigidBody3D body = level.Body;
		PMat3 Rt = body.Rotation.ToMat3().Transpose();
		PVec3 o = Rt.Mul(new PVec3(origin.X - body.Position.X, origin.Y - body.Position.Y, origin.Z - body.Position.Z)) + body.CenterOfMass;
		PVec3 d = Rt.Mul(new PVec3(dir.X, dir.Y, dir.Z));

		// slab test against the body's bounds
		float tmin = 0f;
		float tmax = maxDistance;
		float[] oa = { o.X, o.Y, o.Z };
		float[] da = { d.X, d.Y, d.Z };
		float[] lo = { level.BoundsMin.X, level.BoundsMin.Y, level.BoundsMin.Z };
		float[] hi = { level.BoundsMax.X, level.BoundsMax.Y, level.BoundsMax.Z };
		for (int a = 0; a < 3; a++)
		{
			if (MathF.Abs(da[a]) < 1e-8f)
			{
				if (oa[a] < lo[a] || oa[a] > hi[a])
				{
					return false;
				}
			}
			else
			{
				float t1 = (lo[a] - oa[a]) / da[a];
				float t2 = (hi[a] - oa[a]) / da[a];
				if (t1 > t2)
				{
					float tmp = t1;
					t1 = t2;
					t2 = tmp;
				}
				tmin = Math.Max(tmin, t1);
				tmax = Math.Min(tmax, t2);
				if (tmin > tmax)
				{
					return false;
				}
			}
		}

		// grid walk
		float t = tmin + 1e-4f;
		float tEnter = tmin;
		int cx = (int)MathF.Floor(o.X + d.X * t);
		int cy = (int)MathF.Floor(o.Y + d.Y * t);
		int cz = (int)MathF.Floor(o.Z + d.Z * t);
		int sx = d.X > 0f ? 1 : (d.X < 0f ? -1 : 0);
		int sy = d.Y > 0f ? 1 : (d.Y < 0f ? -1 : 0);
		int sz = d.Z > 0f ? 1 : (d.Z < 0f ? -1 : 0);
		float tMaxX = sx == 0 ? float.MaxValue : ((sx > 0 ? cx + 1 : cx) - o.X) / d.X;
		float tMaxY = sy == 0 ? float.MaxValue : ((sy > 0 ? cy + 1 : cy) - o.Y) / d.Y;
		float tMaxZ = sz == 0 ? float.MaxValue : ((sz > 0 ? cz + 1 : cz) - o.Z) / d.Z;
		float tDx = sx == 0 ? float.MaxValue : MathF.Abs(1f / d.X);
		float tDy = sy == 0 ? float.MaxValue : MathF.Abs(1f / d.Y);
		float tDz = sz == 0 ? float.MaxValue : MathF.Abs(1f / d.Z);
		for (int i = 0; i < 256; i++)
		{
			int index;
			if (level.Index.TryGetValue(new Point3(cx, cy, cz), out index))
			{
				hitIndex = index;
				hitDistance = tEnter;
				return true;
			}
			if (tMaxX < tMaxY && tMaxX < tMaxZ)
			{
				tEnter = tMaxX;
				cx += sx;
				tMaxX += tDx;
			}
			else if (tMaxY < tMaxZ)
			{
				tEnter = tMaxY;
				cy += sy;
				tMaxY += tDy;
			}
			else
			{
				tEnter = tMaxZ;
				cz += sz;
				tMaxZ += tDz;
			}
			if (tEnter > tmax)
			{
				break;
			}
		}
		return false;
	}
}
