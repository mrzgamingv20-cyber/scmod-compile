// Bhop mod: makin lama pemain lari (dan makin sering lompat), makin cepat larinya.
// Kecepatan ditambahkan sebagai Factor "Bhop" (Multiply) ke ComponentFactors.m_speedFactors lewat hook OnFactorsUpdate,
// yang dipanggil setelah game membuat ulang daftar faktor kecepatan tiap frame. Dipakai oleh ComponentLocomotion
// (WalkSpeed * SpeedFactor). Pengali maksimum diatur lewat tombol di layar Pengaturan.
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Xml.Linq;
using Engine;

namespace Game
{
	public class BhopLoader : ModLoader
	{
		public const string ConfigKey = "com.mrzgaming.bhop.MaxMultiplier";

		const float RampSeconds = 8f;     // lari terus selama ini untuk mencapai pengali maksimum
		const float StopSeconds = 0.7f;   // berhenti di tanah: momentum habis dalam waktu ini
		const float JumpBonus = 0.04f;    // tambahan momentum tiap lompatan (bhop)
		const float BlockedDecay = 2.5f;  // momentum hilang per detik saat tertahan tembok

		static readonly float[] Options = new float[] { 1f, 2f, 3f, 4f, 6f };   // 1 = mati
		static float s_max = 3f;
		static bool s_loaded;

		sealed class State
		{
			public float Momentum;      // 0..1
			public float MovingTime;
			public bool WasStanding;
		}

		static readonly ConditionalWeakTable<ComponentFactors, State> s_states = new ConditionalWeakTable<ComponentFactors, State>();

		static float MaxMultiplier
		{
			get
			{
				if (!s_loaded)
				{
					string text;
					float value;
					if (ModsManager.Configs.TryGetValue(ConfigKey, out text) && float.TryParse(text, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out value))
					{
						s_max = Math.Clamp(value, 1f, 6f);
					}
					s_loaded = true;
				}
				return s_max;
			}
		}

		static string ButtonText()
		{
			float max = MaxMultiplier;
			return "Bhop (makin cepat): " + (max <= 1.001f ? "Mati" : "Maks " + max.ToString("0.#", System.Globalization.CultureInfo.InvariantCulture) + "x");
		}

		public override void __ModInitialize()
		{
			ModsManager.RegisterHook("OnFactorsUpdate", this);
			ModsManager.RegisterHook("OnSettingsScreenCreated", this);
		}

		public override void OnFactorsUpdate(ComponentFactors componentFactors, float dt)
		{
			if (componentFactors == null || dt <= 0f)
			{
				return;
			}
			ComponentPlayer player = componentFactors.Entity.FindComponent<ComponentPlayer>();
			if (player == null)
			{
				return; // hanya pemain
			}
			State s = s_states.GetOrCreateValue(componentFactors);
			float max = MaxMultiplier;
			if (max <= 1.001f)
			{
				s.Momentum = 0f;
				return;
			}

			ComponentBody body = player.ComponentBody;
			ComponentLocomotion loco = player.ComponentLocomotion;
			bool alive = player.ComponentHealth.Health > 0f;
			bool standing = body.StandingOnValue.HasValue || body.StandingOnBody != null;
			bool swimming = body.ImmersionFactor > 0.2f;
			bool flying = loco.IsCreativeFlyEnabled;
			Vector2? order = loco.WalkOrder;
			bool moving = order.HasValue && order.Value.Length() > 0.3f && order.Value.Y > -0.2f;

			if (!alive || flying || swimming)
			{
				s.Momentum = 0f;
				s.MovingTime = 0f;
			}
			else if (moving)
			{
				s.MovingTime += dt;
				s.Momentum += dt / RampSeconds;
				if (s.WasStanding && !standing && body.Velocity.Y > 1f)
				{
					s.Momentum += JumpBonus;   // lompat = bonus momentum
				}
				if (standing && s.MovingTime > 0.6f)
				{
					float horizontal = new Vector2(body.Velocity.X, body.Velocity.Z).Length();
					if (horizontal < 0.35f * loco.WalkSpeed)
					{
						s.Momentum -= BlockedDecay * dt;   // menabrak tembok / tertahan
					}
				}
			}
			else
			{
				s.MovingTime = 0f;
				if (standing)
				{
					s.Momentum -= dt / StopSeconds;   // di udara momentum dipertahankan
				}
			}
			s.Momentum = Math.Clamp(s.Momentum, 0f, 1f);
			s.WasStanding = standing;

			float multiplier = 1f + s.Momentum * (max - 1f);
			if (multiplier > 1.001f)
			{
				componentFactors.m_speedFactors.Add(new ComponentLevel.Factor
				{
					Name = "Bhop",
					Description = "Bhop",
					Value = multiplier,
					FactorAdditionType = FactorAdditionType.Multiply
				});
			}
		}

		public override void OnSettingsScreenCreated(SettingsScreen settingsScreen, out Dictionary<ButtonWidget, Action> buttonsToAdd)
		{
			ButtonWidget button = new BevelledButtonWidget
			{
				Name = "BhopButton",
				Text = ButtonText(),
				Style = ContentManager.Get<XElement>("Styles/ButtonStyle_310x60"),
				HorizontalAlignment = WidgetAlignment.Center,
				VerticalAlignment = WidgetAlignment.Center,
				Margin = new Vector2(0f, 5f)
			};
			buttonsToAdd = new Dictionary<ButtonWidget, Action>();
			buttonsToAdd.Add(button, delegate
			{
				// ganti ke pilihan berikutnya: Mati -> 2x -> 3x -> 4x -> 6x -> Mati
				int index = 0;
				for (int i = 0; i < Options.Length; i++)
				{
					if (Math.Abs(Options[i] - MaxMultiplier) < 0.01f)
					{
						index = i;
					}
				}
				s_max = Options[(index + 1) % Options.Length];
				s_loaded = true;
				ModsManager.SetConfig(ConfigKey, s_max.ToString(System.Globalization.CultureInfo.InvariantCulture));
				SettingsManager.SaveSettings();
				button.Text = ButtonText();
			});
		}
	}
}
