// SubLevelPhysics v11 - Joint and Constraint System (Hinge, Slider, Fixed, Rope)
// Namespace Game, completely independent vector math (PVec3, PQuat, PMat3).
using System;
using System.Collections.Generic;

namespace Game;

public enum JointType
{
	Hinge,
	Slider,
	Fixed,
	Rope
}

public abstract class Joint3D
{
	public JointType Type;
	public RigidBody3D BodyA;
	public RigidBody3D BodyB; // null means anchored to static world
	public bool IsActive = true;

	public abstract void ApplyConstraints(float dt);
}

// Hinge Joint: allows rotation around a single axis passing through an anchor point.
public class HingeJoint3D : Joint3D
{
	public PVec3 AnchorWorld;    // World space anchor position
	public PVec3 AxisWorld;      // World space rotation axis (normalized)
	public float MinAngle = -MathF.PI;
	public float MaxAngle = MathF.PI;
	public float MotorSpeed = 0f;
	public float MotorMaxForce = 0f;

	public HingeJoint3D(RigidBody3D bodyA, RigidBody3D bodyB, PVec3 anchorWorld, PVec3 axisWorld)
	{
		Type = JointType.Hinge;
		BodyA = bodyA;
		BodyB = bodyB;
		AnchorWorld = anchorWorld;
		AxisWorld = Normalized(axisWorld);
	}

	static PVec3 Normalized(PVec3 v)
	{
		float l = v.Length;
		return l < 1e-6f ? new PVec3(0, 1, 0) : v * (1f / l);
	}

	public override void ApplyConstraints(float dt)
	{
		if (!IsActive) return;

		// 1. Position constraint: Anchor point on BodyA and BodyB must coincide in world space
		PVec3 posA = BodyA != null ? BodyA.LocalToWorld(BodyA.WorldToLocal(AnchorWorld)) : AnchorWorld; // Simplified
		// If BodyB is present, maintain relative position at anchor
		if (BodyB != null)
		{
			PVec3 rA = AnchorWorld - BodyA.Position;
			PVec3 rB = AnchorWorld - BodyB.Position;
			PVec3 velA = BodyA.Velocity + PVec3.Cross(BodyA.AngularVelocity, rA);
			PVec3 velB = BodyB.Velocity + PVec3.Cross(BodyB.AngularVelocity, rB);
			PVec3 error = (BodyB.Position + rB) - (BodyA.Position + rA);
			
			// Position correction impulse (Baumgarte stabilization)
			float beta = 0.3f;
			PVec3 correction = error * (beta / dt);
			
			// Apply velocity correction to satisfy joint position
			PVec3 impulse = correction * (BodyA.Mass * BodyB.Mass / (BodyA.Mass + BodyB.Mass));
			BodyA.AddImpulseAtPoint(impulse * 0.5f, AnchorWorld);
			BodyB.AddImpulseAtPoint(-impulse * 0.5f, AnchorWorld);
		}
		else if (BodyA != null)
		{
			// BodyA hinged to static world at AnchorWorld
			PVec3 rA = AnchorWorld - BodyA.Position;
			PVec3 currentAnchor = BodyA.LocalToWorld(BodyA.WorldToLocal(AnchorWorld));
			PVec3 error = AnchorWorld - currentAnchor;
			PVec3 correction = error * (0.4f / dt);
			BodyA.AddImpulseAtPoint(correction * BodyA.Mass * 0.5f, AnchorWorld);

			// Enforce axis rotation constraint (remove velocity components orthogonal to hinge axis)
			PVec3 angVel = BodyA.AngularVelocity;
			float axisVel = PVec3.Dot(angVel, AxisWorld);
			PVec3 restrictedAngVel = AxisWorld * axisVel;
			// Apply motor speed if active
			if (MotorMaxForce > 0f)
			{
				float speedError = MotorSpeed - axisVel;
				float motorImpulse = Math.Clamp(speedError * BodyA.InertiaScale, -MotorMaxForce * dt, MotorMaxForce * dt);
				BodyA.AngularVelocity = BodyA.AngularVelocity + AxisWorld * (motorImpulse / BodyA.InertiaScale);
			}
		}
	}
}

// Slider Joint: restricts relative movement between bodies to a single linear axis.
public class SliderJoint3D : Joint3D
{
	public PVec3 AnchorWorld;
	public PVec3 AxisWorld;       // Slide axis
	public float MinLimit = -5f;
	public float MaxLimit = 5f;
	public float CurrentPosition = 0f;

	public SliderJoint3D(RigidBody3D bodyA, RigidBody3D bodyB, PVec3 anchorWorld, PVec3 axisWorld)
	{
		Type = JointType.Slider;
		BodyA = bodyA;
		BodyB = bodyB;
		AnchorWorld = anchorWorld;
		AxisWorld = Normalized(axisWorld);
	}

	static PVec3 Normalized(PVec3 v)
	{
		float l = v.Length;
		return l < 1e-6f ? new PVec3(0, 1, 0) : v * (1f / l);
	}

	public override void ApplyConstraints(float dt)
	{
		if (!IsActive) return;

		if (BodyA != null && BodyB != null)
		{
			// Restrict relative motion perpendicular to AxisWorld
			PVec3 delta = BodyB.Position - BodyA.Position;
			float parallelDist = PVec3.Dot(delta, AxisWorld);
			CurrentPosition = parallelDist;

			// Clamp limits
			if (parallelDist < MinLimit || parallelDist > MaxLimit)
			{
				float clamped = Math.Clamp(parallelDist, MinLimit, MaxLimit);
				PVec3 targetPos = BodyA.Position + AxisWorld * clamped;
				BodyB.Position = targetPos;
			}

			// Cancel velocities orthogonal to slide axis
			PVec3 relVel = BodyB.Velocity - BodyA.Velocity;
			float axialVel = PVec3.Dot(relVel, AxisWorld);
			PVec3 orthoVel = relVel - AxisWorld * axialVel;
			BodyA.Velocity = BodyA.Velocity + orthoVel * 0.5f;
			BodyB.Velocity = BodyB.Velocity - orthoVel * 0.5f;
		}
		else if (BodyA != null)
		{
			// BodyA sliding along axis relative to world
			PVec3 relPos = BodyA.Position - AnchorWorld;
			float proj = PVec3.Dot(relPos, AxisWorld);
			CurrentPosition = proj;
			float clamped = Math.Clamp(proj, MinLimit, MaxLimit);
			BodyA.Position = AnchorWorld + AxisWorld * clamped;

			PVec3 vel = BodyA.Velocity;
			float axialVel = PVec3.Dot(vel, AxisWorld);
			BodyA.Velocity = AxisWorld * axialVel; // keep only velocity along slider axis
		}
	}
}

// Fixed Joint: rigidly locks two bodies together.
public class FixedJoint3D : Joint3D
{
	public PMat3 InitialRotationOffset;
	public PVec3 InitialPositionOffset;

	public FixedJoint3D(RigidBody3D bodyA, RigidBody3D bodyB)
	{
		Type = JointType.Fixed;
		BodyA = bodyA;
		BodyB = bodyB;
		if (bodyA != null && bodyB != null)
		{
			InitialPositionOffset = bodyB.Position - bodyA.Position;
		}
	}

	public override void ApplyConstraints(float dt)
	{
		if (!IsActive || BodyA == null || BodyB == null) return;

		// Lock relative positions and velocities
		PVec3 targetPos = BodyA.Position + InitialPositionOffset;
		BodyB.Position = targetPos;
		BodyB.Velocity = BodyA.Velocity;
		BodyB.AngularVelocity = BodyA.AngularVelocity;
		BodyB.Rotation = BodyA.Rotation;
	}
}

// Rope Joint: distance constraint (max distance, flexible).
public class RopeJoint3D : Joint3D
{
	public PVec3 AnchorA;
	public PVec3 AnchorB;
	public float MaxLength;

	public RopeJoint3D(RigidBody3D bodyA, RigidBody3D bodyB, PVec3 anchorA, PVec3 anchorB, float maxLength)
	{
		Type = JointType.Rope;
		BodyA = bodyA;
		BodyB = bodyB;
		AnchorA = anchorA;
		AnchorB = anchorB;
		MaxLength = maxLength;
	}

	public override void ApplyConstraints(float dt)
	{
		if (!IsActive || BodyA == null || BodyB == null) return;

		PVec3 worldA = BodyA.LocalToWorld(AnchorA);
		PVec3 worldB = BodyB != null ? BodyB.LocalToWorld(AnchorB) : AnchorB;
		PVec3 diff = worldB - worldA;
		float dist = diff.Length;

		if (dist > MaxLength)
		{
			PVec3 dir = dist > 1e-6f ? diff * (1f / dist) : new PVec3(0, 1, 0);
			float error = dist - MaxLength;
			PVec3 correction = dir * (error * 0.5f);
			BodyA.AddImpulseAtPoint(correction * BodyA.Mass * 10f * dt, worldA);
			if (BodyB != null)
			{
				BodyB.AddImpulseAtPoint(-correction * BodyB.Mass * 10f * dt, worldB);
			}
		}
	}
}
