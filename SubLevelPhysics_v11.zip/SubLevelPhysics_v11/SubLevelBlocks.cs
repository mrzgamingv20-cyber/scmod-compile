// SubLevelPhysics v10 - Custom Independent Block Suite (Sable & Create Aeronautics Style)
// Complete with dedicated procedural geometry, custom texture atlas mapping, and survival crafting recipes.
using System;
using System.Collections.Generic;
using System.Linq;
using Engine;
using Engine.Graphics;

namespace Game;

public static class SubLevelAtlas
{
	// UV Slots in SubLevelAtlas.png (256x256)
	public static readonly Vector4 SteelCasing   = new Vector4(0.00f, 0.00f, 0.25f, 0.25f);
	public static readonly Vector4 HazardStripe  = new Vector4(0.25f, 0.00f, 0.50f, 0.25f);
	public static readonly Vector4 BrassCopper   = new Vector4(0.50f, 0.00f, 0.75f, 0.25f);
	public static readonly Vector4 GlowingCore   = new Vector4(0.75f, 0.00f, 1.00f, 0.25f);
	public static readonly Vector4 MahoganyWood  = new Vector4(0.00f, 0.25f, 0.25f, 0.50f);
	public static readonly Vector4 TurbineGrill  = new Vector4(0.25f, 0.25f, 0.50f, 0.50f);
	public static readonly Vector4 BearingRing   = new Vector4(0.50f, 0.25f, 0.75f, 0.50f);
	public static readonly Vector4 PistonShaft   = new Vector4(0.75f, 0.25f, 1.00f, 0.50f);
	public static readonly Vector4 DockingPad    = new Vector4(0.00f, 0.50f, 0.25f, 0.75f);
	public static readonly Vector4 LeatherSeat   = new Vector4(0.25f, 0.50f, 0.50f, 0.75f);

	static Texture2D m_texture;
	static bool m_triedLoad;

	public static Texture2D GetTexture()
	{
		if (!m_triedLoad)
		{
			m_triedLoad = true;
			try
			{
				m_texture = ContentManager.Get<Texture2D>("Textures/SubLevelAtlas");
			}
			catch
			{
				m_texture = null;
			}
		}
		return m_texture;
	}
}

public static class ProceduralMeshHelper
{
	public static void AddQuad(BlockMesh mesh, Vector3 p0, Vector3 p1, Vector3 p2, Vector3 p3, Vector4 tc, Color color, byte face, Matrix? transform = null)
	{
		if (transform.HasValue)
		{
			p0 = Vector3.Transform(p0, transform.Value);
			p1 = Vector3.Transform(p1, transform.Value);
			p2 = Vector3.Transform(p2, transform.Value);
			p3 = Vector3.Transform(p3, transform.Value);
		}
		int start = mesh.Vertices.Count;
		mesh.Vertices.Add(new BlockMeshVertex { Position = p0, TextureCoordinates = new Vector2(tc.X, tc.W), Color = color, Face = face });
		mesh.Vertices.Add(new BlockMeshVertex { Position = p1, TextureCoordinates = new Vector2(tc.Z, tc.W), Color = color, Face = face });
		mesh.Vertices.Add(new BlockMeshVertex { Position = p2, TextureCoordinates = new Vector2(tc.Z, tc.Y), Color = color, Face = face });
		mesh.Vertices.Add(new BlockMeshVertex { Position = p3, TextureCoordinates = new Vector2(tc.X, tc.Y), Color = color, Face = face });

		mesh.Indices.Add(start);
		mesh.Indices.Add(start + 1);
		mesh.Indices.Add(start + 2);
		mesh.Indices.Add(start + 2);
		mesh.Indices.Add(start + 3);
		mesh.Indices.Add(start);
	}

	public static void AddBox(BlockMesh mesh, Vector3 min, Vector3 max, Color color, Vector4 tc, Matrix? transform = null)
	{
		// Face 0: +Z
		AddQuad(mesh, new Vector3(min.X, min.Y, max.Z), new Vector3(max.X, min.Y, max.Z), new Vector3(max.X, max.Y, max.Z), new Vector3(min.X, max.Y, max.Z), tc, color, 0, transform);
		// Face 1: +X
		AddQuad(mesh, new Vector3(max.X, min.Y, max.Z), new Vector3(max.X, min.Y, min.Z), new Vector3(max.X, max.Y, min.Z), new Vector3(max.X, max.Y, max.Z), tc, color, 1, transform);
		// Face 2: -Z
		AddQuad(mesh, new Vector3(max.X, min.Y, min.Z), new Vector3(min.X, min.Y, min.Z), new Vector3(min.X, max.Y, min.Z), new Vector3(max.X, max.Y, min.Z), tc, color, 2, transform);
		// Face 3: -X
		AddQuad(mesh, new Vector3(min.X, min.Y, min.Z), new Vector3(min.X, min.Y, max.Z), new Vector3(min.X, max.Y, max.Z), new Vector3(min.X, max.Y, min.Z), tc, color, 3, transform);
		// Face 4: +Y
		AddQuad(mesh, new Vector3(min.X, max.Y, max.Z), new Vector3(max.X, max.Y, max.Z), new Vector3(max.X, max.Y, min.Z), new Vector3(min.X, max.Y, min.Z), tc, color, 4, transform);
		// Face 5: -Y
		AddQuad(mesh, new Vector3(min.X, min.Y, min.Z), new Vector3(max.X, min.Y, min.Z), new Vector3(max.X, min.Y, max.Z), new Vector3(min.X, min.Y, max.Z), tc, color, 5, transform);
	}
}

// ============================================================================
// 1. Physics Super Glue: Precision Adhesive Tube
// ============================================================================
public class PhysicsGlueBlock : Block
{
	public BlockMesh m_standaloneMesh = new BlockMesh();
	public BoundingBox[] m_collisionBoxes = new BoundingBox[1];

	public PhysicsGlueBlock()
	{
		DefaultDisplayName = "Lem Super Fisika";
		DefaultDescription = "Alat perekat struktur sub-level (Create/Sable style). Ketuk balok sudut pertama, lalu balok sudut lawannya untuk mengelompokkan area menjadi objek fisik dinamis.";
		DefaultCategory = "Mechanics";
		MaxStacking = 16;
		IsCollidable = true;
		IsPlaceable = true;
	}

	public override void Initialize()
	{
		m_standaloneMesh = new BlockMesh();
		ProceduralMeshHelper.AddBox(m_standaloneMesh, new Vector3(0.35f, 0.0f, 0.35f), new Vector3(0.65f, 0.50f, 0.65f), Color.White, SubLevelAtlas.SteelCasing);
		ProceduralMeshHelper.AddBox(m_standaloneMesh, new Vector3(0.34f, 0.15f, 0.34f), new Vector3(0.66f, 0.35f, 0.66f), Color.White, SubLevelAtlas.HazardStripe);
		ProceduralMeshHelper.AddBox(m_standaloneMesh, new Vector3(0.40f, 0.50f, 0.40f), new Vector3(0.60f, 0.62f, 0.60f), Color.White, SubLevelAtlas.BrassCopper);
		ProceduralMeshHelper.AddBox(m_standaloneMesh, new Vector3(0.45f, 0.62f, 0.45f), new Vector3(0.55f, 0.85f, 0.55f), Color.White, SubLevelAtlas.SteelCasing);

		m_collisionBoxes[0] = new BoundingBox(new Vector3(0.3f, 0.0f, 0.3f), new Vector3(0.7f, 0.85f, 0.7f));
		base.Initialize();
	}

	public override void GenerateTerrainVertices(BlockGeometryGenerator generator, TerrainGeometry geometry, int value, int x, int y, int z)
	{
		Texture2D tex = SubLevelAtlas.GetTexture();
		TerrainGeometrySubset subset = (tex != null) ? geometry.GetGeometry(tex).SubsetOpaque : geometry.SubsetOpaque;
		generator.GenerateMeshVertices(this, x, y, z, m_standaloneMesh, Color.White, null, subset);
	}

	public override void DrawBlock(PrimitivesRenderer3D primitivesRenderer, int value, Color color, float size, ref Matrix matrix, DrawBlockEnvironmentData environmentData)
	{
		Texture2D tex = SubLevelAtlas.GetTexture();
		if (tex != null)
			BlocksManager.DrawMeshBlock(primitivesRenderer, m_standaloneMesh, tex, color, size, ref matrix, environmentData);
		else
			BlocksManager.DrawMeshBlock(primitivesRenderer, m_standaloneMesh, color, size, ref matrix, environmentData);
	}

	public override BoundingBox[] GetCustomCollisionBoxes(SubsystemTerrain terrain, int value) => m_collisionBoxes;

	public override CraftingRecipe GetAdHocCraftingRecipe(SubsystemTerrain terrain, string[] ingredients, float heatLevel, float playerLevel)
	{
		// Cotton Wad (111) + Gunpowder (107) -> 4 Lem Super
		bool hasCotton = ingredients.Any(i => !string.IsNullOrEmpty(i) && (i.StartsWith("Cotton") || i.Contains("111")));
		bool hasGunpowder = ingredients.Any(i => !string.IsNullOrEmpty(i) && (i.StartsWith("Gunpowder") || i.Contains("107")));
		if (hasCotton && hasGunpowder)
		{
			CraftingRecipe recipe = new CraftingRecipe();
			recipe.ResultValue = Terrain.MakeBlockValue(BlockIndex);
			recipe.ResultCount = 4;
			recipe.Description = "Membuat 4 Lem Super Fisika";
			recipe.Ingredients = (string[])ingredients.Clone();
			return recipe;
		}
		return null;
	}
}

// ============================================================================
// 2. Physics Lever: Heavy-Duty Industrial Activation Switch
// ============================================================================
public class PhysicsLeverBlock : Block
{
	public BlockMesh[] m_blockMeshesByIndex = new BlockMesh[12];
	public BlockMesh m_standaloneMesh = new BlockMesh();
	public BoundingBox[][] m_collisionBoxesByIndex = new BoundingBox[12][];

	public PhysicsLeverBlock()
	{
		DefaultDisplayName = "Tuas Fisika";
		DefaultDescription = "Tuas industri pengaktif sub-level fisika. Sakelar ON mengubah struktur balok menjadi objek dinamis & mengalirkan listrik. Ketuk saat jongkok untuk memarkirkan kembali.";
		DefaultCategory = "Mechanics";
		MaxStacking = 16;
		IsCollidable = true;
		IsPlaceable = true;
	}

	public override void Initialize()
	{
		for (int face = 0; face < 6; face++)
		{
			for (int state = 0; state < 2; state++)
			{
				int index = (face << 1) | state;
				Matrix faceMat = face >= 4
					? face != 4
						? Matrix.CreateRotationX((float)Math.PI) * Matrix.CreateTranslation(0.5f, 1f, 0.5f)
						: Matrix.CreateTranslation(0.5f, 0f, 0.5f)
					: Matrix.CreateRotationX((float)Math.PI / 2f)
					* Matrix.CreateTranslation(0f, 0f, -0.5f)
					* Matrix.CreateRotationY(face * (float)Math.PI / 2f)
					* Matrix.CreateTranslation(0.5f, 0.5f, 0.5f);

				BlockMesh mesh = new BlockMesh();
				ProceduralMeshHelper.AddBox(mesh, new Vector3(0.20f, 0.0f, 0.20f), new Vector3(0.80f, 0.08f, 0.80f), Color.White, SubLevelAtlas.SteelCasing, faceMat);
				ProceduralMeshHelper.AddBox(mesh, new Vector3(0.40f, 0.08f, 0.38f), new Vector3(0.60f, 0.22f, 0.62f), Color.White, SubLevelAtlas.SteelCasing, faceMat);

				float angle = (state == 1) ? MathUtils.DegToRad(32f) : MathUtils.DegToRad(-32f);
				Matrix leverMat = Matrix.CreateTranslation(-0.5f, -0.15f, -0.5f)
					* Matrix.CreateRotationX(angle)
					* Matrix.CreateTranslation(0.5f, 0.15f, 0.5f)
					* faceMat;

				ProceduralMeshHelper.AddBox(mesh, new Vector3(0.46f, 0.15f, 0.46f), new Vector3(0.54f, 0.58f, 0.54f), Color.White, SubLevelAtlas.BrassCopper, leverMat);
				Vector4 knobTex = (state == 1) ? SubLevelAtlas.HazardStripe : SubLevelAtlas.SteelCasing;
				ProceduralMeshHelper.AddBox(mesh, new Vector3(0.40f, 0.58f, 0.40f), new Vector3(0.60f, 0.74f, 0.60f), Color.White, knobTex, leverMat);

				m_blockMeshesByIndex[index] = mesh;
				m_collisionBoxesByIndex[index] = new BoundingBox[] { mesh.CalculateBoundingBox() };
			}
		}

		m_standaloneMesh = m_blockMeshesByIndex[0];
		base.Initialize();
	}

	public override void GenerateTerrainVertices(BlockGeometryGenerator generator, TerrainGeometry geometry, int value, int x, int y, int z)
	{
		int face = (Terrain.ExtractData(value) >> 1) & 7;
		int state = Terrain.ExtractData(value) & 1;
		int index = Math.Clamp((face << 1) | state, 0, 11);
		Texture2D tex = SubLevelAtlas.GetTexture();
		TerrainGeometrySubset subset = (tex != null) ? geometry.GetGeometry(tex).SubsetOpaque : geometry.SubsetOpaque;
		generator.GenerateMeshVertices(this, x, y, z, m_blockMeshesByIndex[index], Color.White, null, subset);
	}

	public override void DrawBlock(PrimitivesRenderer3D primitivesRenderer, int value, Color color, float size, ref Matrix matrix, DrawBlockEnvironmentData environmentData)
	{
		Texture2D tex = SubLevelAtlas.GetTexture();
		if (tex != null)
			BlocksManager.DrawMeshBlock(primitivesRenderer, m_standaloneMesh, tex, color, size, ref matrix, environmentData);
		else
			BlocksManager.DrawMeshBlock(primitivesRenderer, m_standaloneMesh, color, size, ref matrix, environmentData);
	}

	public override BoundingBox[] GetCustomCollisionBoxes(SubsystemTerrain terrain, int value)
	{
		int face = (Terrain.ExtractData(value) >> 1) & 7;
		int state = Terrain.ExtractData(value) & 1;
		int index = Math.Clamp((face << 1) | state, 0, 11);
		return m_collisionBoxesByIndex[index];
	}

	public override BlockPlacementData GetPlacementValue(SubsystemTerrain subsystemTerrain, ComponentMiner componentMiner, int value, TerrainRaycastResult raycastResult)
	{
		BlockPlacementData result = default;
		result.Value = Terrain.ReplaceData(value, raycastResult.CellFace.Face << 1);
		result.CellFace = raycastResult.CellFace;
		return result;
	}

	public override CraftingRecipe GetAdHocCraftingRecipe(SubsystemTerrain terrain, string[] ingredients, float heatLevel, float playerLevel)
	{
		// Iron Ingot + Switch + Copper Ingot -> Tuas Fisika
		bool hasIron = ingredients.Any(i => !string.IsNullOrEmpty(i) && (i.StartsWith("IronIngot") || i.Contains("41")));
		bool hasSwitch = ingredients.Any(i => !string.IsNullOrEmpty(i) && (i.StartsWith("Switch") || i.Contains("141")));
		if (hasIron && hasSwitch)
		{
			CraftingRecipe recipe = new CraftingRecipe();
			recipe.ResultValue = Terrain.MakeBlockValue(BlockIndex);
			recipe.ResultCount = 1;
			recipe.Description = "Membuat Tuas Fisika Industri";
			recipe.Ingredients = (string[])ingredients.Clone();
			return recipe;
		}
		return null;
	}
}

// ============================================================================
// 3. Physics Helm: Airship & Vehicle Steering Wheel Console
// ============================================================================
public class PhysicsHelmBlock : Block
{
	public BlockMesh[] m_meshesByRotation = new BlockMesh[4];
	public BlockMesh m_standaloneMesh = new BlockMesh();
	public BoundingBox[][] m_collisionBoxes = new BoundingBox[4][];

	public PhysicsHelmBlock()
	{
		DefaultDisplayName = "Kemudi Kapal Udara";
		DefaultDescription = "Konsol kemudi untuk menerbangkan dan mengarahkan kapal udara atau kendaraan air. Ketuk untuk mengemudi, joystick untuk manuver, Lompat naik, Jongkok turun.";
		DefaultCategory = "Mechanics";
		MaxStacking = 8;
		IsCollidable = true;
		IsPlaceable = true;
	}

	public override void Initialize()
	{
		for (int rot = 0; rot < 4; rot++)
		{
			Matrix rotMat = Matrix.CreateRotationY(rot * (float)Math.PI / 2f) * Matrix.CreateTranslation(0.5f, 0f, 0.5f);
			BlockMesh mesh = new BlockMesh();

			ProceduralMeshHelper.AddBox(mesh, new Vector3(-0.30f, 0.0f, -0.25f), new Vector3(0.30f, 0.65f, 0.25f), Color.White, SubLevelAtlas.MahoganyWood, rotMat);
			ProceduralMeshHelper.AddBox(mesh, new Vector3(-0.20f, 0.65f, -0.15f), new Vector3(0.20f, 0.85f, 0.15f), Color.White, SubLevelAtlas.BrassCopper, rotMat);
			ProceduralMeshHelper.AddBox(mesh, new Vector3(-0.05f, 0.55f, 0.15f), new Vector3(0.05f, 0.65f, 0.35f), Color.White, SubLevelAtlas.BrassCopper, rotMat);

			Matrix wheelCenter = Matrix.CreateTranslation(0f, 0.60f, 0.35f) * rotMat;
			for (int s = 0; s < 4; s++)
			{
				Matrix spokeMat = Matrix.CreateRotationZ(s * (float)Math.PI / 4f) * wheelCenter;
				ProceduralMeshHelper.AddBox(mesh, new Vector3(-0.03f, -0.40f, -0.02f), new Vector3(0.03f, 0.40f, 0.02f), Color.White, SubLevelAtlas.MahoganyWood, spokeMat);
			}
			ProceduralMeshHelper.AddBox(mesh, new Vector3(-0.35f, -0.35f, -0.02f), new Vector3(0.35f, 0.35f, 0.02f), Color.White, SubLevelAtlas.BrassCopper, wheelCenter);
			ProceduralMeshHelper.AddBox(mesh, new Vector3(-0.08f, -0.08f, -0.03f), new Vector3(0.08f, 0.08f, 0.04f), Color.White, SubLevelAtlas.BrassCopper, wheelCenter);

			m_meshesByRotation[rot] = mesh;
			m_collisionBoxes[rot] = new BoundingBox[] { mesh.CalculateBoundingBox() };
		}

		m_standaloneMesh = m_meshesByRotation[0];
		base.Initialize();
	}

	public override void GenerateTerrainVertices(BlockGeometryGenerator generator, TerrainGeometry geometry, int value, int x, int y, int z)
	{
		int rot = Terrain.ExtractData(value) & 3;
		Texture2D tex = SubLevelAtlas.GetTexture();
		TerrainGeometrySubset subset = (tex != null) ? geometry.GetGeometry(tex).SubsetOpaque : geometry.SubsetOpaque;
		generator.GenerateMeshVertices(this, x, y, z, m_meshesByRotation[rot], Color.White, null, subset);
	}

	public override void DrawBlock(PrimitivesRenderer3D primitivesRenderer, int value, Color color, float size, ref Matrix matrix, DrawBlockEnvironmentData environmentData)
	{
		Texture2D tex = SubLevelAtlas.GetTexture();
		if (tex != null)
			BlocksManager.DrawMeshBlock(primitivesRenderer, m_standaloneMesh, tex, color, size, ref matrix, environmentData);
		else
			BlocksManager.DrawMeshBlock(primitivesRenderer, m_standaloneMesh, color, size, ref matrix, environmentData);
	}

	public override BoundingBox[] GetCustomCollisionBoxes(SubsystemTerrain terrain, int value)
	{
		int rot = Terrain.ExtractData(value) & 3;
		return m_collisionBoxes[rot];
	}

	public override BlockPlacementData GetPlacementValue(SubsystemTerrain subsystemTerrain, ComponentMiner componentMiner, int value, TerrainRaycastResult raycastResult)
	{
		Vector3 forward = componentMiner.ComponentPlayer != null ? componentMiner.ComponentPlayer.ComponentCreatureModel.EyeRotation.GetForwardVector() : Vector3.UnitZ;
		int rot = (MathF.Abs(forward.X) > MathF.Abs(forward.Z)) ? ((forward.X > 0f) ? 1 : 3) : ((forward.Z > 0f) ? 0 : 2);
		BlockPlacementData result = default;
		result.Value = Terrain.ReplaceData(value, rot);
		result.CellFace = raycastResult.CellFace;
		return result;
	}

	public override CraftingRecipe GetAdHocCraftingRecipe(SubsystemTerrain terrain, string[] ingredients, float heatLevel, float playerLevel)
	{
		// Planks + Wood + Copper Ingot -> Kemudi Kapal
		bool hasWood = ingredients.Any(i => !string.IsNullOrEmpty(i) && (i.StartsWith("Planks") || i.StartsWith("Wood") || i.Contains("4")));
		bool hasCopper = ingredients.Any(i => !string.IsNullOrEmpty(i) && (i.StartsWith("Copper") || i.Contains("43")));
		if (hasWood && hasCopper)
		{
			CraftingRecipe recipe = new CraftingRecipe();
			recipe.ResultValue = Terrain.MakeBlockValue(BlockIndex);
			recipe.ResultCount = 1;
			recipe.Description = "Membuat Kemudi Kapal Udara";
			recipe.Ingredients = (string[])ingredients.Clone();
			return recipe;
		}
		return null;
	}
}

// ============================================================================
// 4. Physics Engine: Mechanical Thruster with Turbine Exhaust
// ============================================================================
public class PhysicsEngineBlock : Block
{
	public BlockMesh m_blockMesh = new BlockMesh();
	public BoundingBox[] m_collisionBoxes = new BoundingBox[1];

	public PhysicsEngineBlock()
	{
		DefaultDisplayName = "Mesin Pendorong Fisika";
		DefaultDescription = "Mesin turbin pendorong untuk kapal udara dan wahana fisika. Memberikan daya dorong linier. Daya dorong meningkat drastis (mode TURBO 2.2x) saat dialiri listrik.";
		DefaultCategory = "Mechanics";
		MaxStacking = 16;
		IsCollidable = true;
		IsPlaceable = true;
	}

	public override void Initialize()
	{
		m_blockMesh = new BlockMesh();
		ProceduralMeshHelper.AddBox(m_blockMesh, new Vector3(0.04f, 0.04f, 0.04f), new Vector3(0.96f, 0.96f, 0.96f), Color.White, SubLevelAtlas.SteelCasing);
		ProceduralMeshHelper.AddBox(m_blockMesh, new Vector3(0.18f, 0.18f, 0.95f), new Vector3(0.82f, 0.82f, 1.01f), Color.White, SubLevelAtlas.TurbineGrill);
		ProceduralMeshHelper.AddBox(m_blockMesh, new Vector3(0.15f, 0.15f, -0.02f), new Vector3(0.85f, 0.85f, 0.06f), Color.White, SubLevelAtlas.BrassCopper);
		ProceduralMeshHelper.AddBox(m_blockMesh, new Vector3(0.25f, 0.25f, 0.25f), new Vector3(0.75f, 0.75f, 0.75f), Color.White, SubLevelAtlas.GlowingCore);

		m_collisionBoxes[0] = new BoundingBox(Vector3.Zero, Vector3.One);
		base.Initialize();
	}

	public override void GenerateTerrainVertices(BlockGeometryGenerator generator, TerrainGeometry geometry, int value, int x, int y, int z)
	{
		Texture2D tex = SubLevelAtlas.GetTexture();
		TerrainGeometrySubset subset = (tex != null) ? geometry.GetGeometry(tex).SubsetOpaque : geometry.SubsetOpaque;
		generator.GenerateMeshVertices(this, x, y, z, m_blockMesh, Color.White, null, subset);
	}

	public override void DrawBlock(PrimitivesRenderer3D primitivesRenderer, int value, Color color, float size, ref Matrix matrix, DrawBlockEnvironmentData environmentData)
	{
		Texture2D tex = SubLevelAtlas.GetTexture();
		if (tex != null)
			BlocksManager.DrawMeshBlock(primitivesRenderer, m_blockMesh, tex, color, size, ref matrix, environmentData);
		else
			BlocksManager.DrawMeshBlock(primitivesRenderer, m_blockMesh, color, size, ref matrix, environmentData);
	}

	public override BoundingBox[] GetCustomCollisionBoxes(SubsystemTerrain terrain, int value) => m_collisionBoxes;

	public override CraftingRecipe GetAdHocCraftingRecipe(SubsystemTerrain terrain, string[] ingredients, float heatLevel, float playerLevel)
	{
		// Furnace (64) + Iron Ingot (41) + Gunpowder (107) -> Mesin Pendorong
		bool hasFurnace = ingredients.Any(i => !string.IsNullOrEmpty(i) && (i.StartsWith("Furnace") || i.Contains("64")));
		bool hasIron = ingredients.Any(i => !string.IsNullOrEmpty(i) && (i.StartsWith("IronIngot") || i.Contains("41")));
		if (hasFurnace && hasIron)
		{
			CraftingRecipe recipe = new CraftingRecipe();
			recipe.ResultValue = Terrain.MakeBlockValue(BlockIndex);
			recipe.ResultCount = 1;
			recipe.Description = "Membuat Mesin Pendorong Fisika";
			recipe.Ingredients = (string[])ingredients.Clone();
			return recipe;
		}
		return null;
	}
}

// ============================================================================
// 5. Physics Manipulator: Handheld Gravity & Kinetic Tool
// ============================================================================
public class PhysicsMoverBlock : Block
{
	public BlockMesh m_standaloneMesh = new BlockMesh();
	public BoundingBox[] m_collisionBoxes = new BoundingBox[1];

	public PhysicsMoverBlock()
	{
		DefaultDisplayName = "Manipulator Fisika";
		DefaultDescription = "Alat manipulator gravitasi. Ketuk untuk mengangkat dan membawa struktur sub-level. Serang/pukul untuk melontarkan daya kinetik pendorong.";
		DefaultCategory = "Tools";
		MaxStacking = 1;
		IsCollidable = true;
		IsPlaceable = true;
	}

	public override void Initialize()
	{
		m_standaloneMesh = new BlockMesh();
		ProceduralMeshHelper.AddBox(m_standaloneMesh, new Vector3(0.42f, 0.0f, 0.42f), new Vector3(0.58f, 0.55f, 0.58f), Color.White, SubLevelAtlas.SteelCasing);
		ProceduralMeshHelper.AddBox(m_standaloneMesh, new Vector3(0.32f, 0.55f, 0.35f), new Vector3(0.68f, 0.72f, 0.65f), Color.White, SubLevelAtlas.GlowingCore);
		ProceduralMeshHelper.AddBox(m_standaloneMesh, new Vector3(0.30f, 0.72f, 0.42f), new Vector3(0.40f, 0.95f, 0.58f), Color.White, SubLevelAtlas.BrassCopper);
		ProceduralMeshHelper.AddBox(m_standaloneMesh, new Vector3(0.60f, 0.72f, 0.42f), new Vector3(0.70f, 0.95f, 0.58f), Color.White, SubLevelAtlas.BrassCopper);

		m_collisionBoxes[0] = new BoundingBox(new Vector3(0.25f, 0.0f, 0.25f), new Vector3(0.75f, 0.95f, 0.75f));
		base.Initialize();
	}

	public override void GenerateTerrainVertices(BlockGeometryGenerator generator, TerrainGeometry geometry, int value, int x, int y, int z)
	{
		Texture2D tex = SubLevelAtlas.GetTexture();
		TerrainGeometrySubset subset = (tex != null) ? geometry.GetGeometry(tex).SubsetOpaque : geometry.SubsetOpaque;
		generator.GenerateMeshVertices(this, x, y, z, m_standaloneMesh, Color.White, null, subset);
	}

	public override void DrawBlock(PrimitivesRenderer3D primitivesRenderer, int value, Color color, float size, ref Matrix matrix, DrawBlockEnvironmentData environmentData)
	{
		Texture2D tex = SubLevelAtlas.GetTexture();
		if (tex != null)
			BlocksManager.DrawMeshBlock(primitivesRenderer, m_standaloneMesh, tex, color, size, ref matrix, environmentData);
		else
			BlocksManager.DrawMeshBlock(primitivesRenderer, m_standaloneMesh, color, size, ref matrix, environmentData);
	}

	public override BoundingBox[] GetCustomCollisionBoxes(SubsystemTerrain terrain, int value) => m_collisionBoxes;

	public override CraftingRecipe GetAdHocCraftingRecipe(SubsystemTerrain terrain, string[] ingredients, float heatLevel, float playerLevel)
	{
		// Magnet (167) + Iron Ingot (41) + Copper (43) -> Manipulator Fisika
		bool hasMagnet = ingredients.Any(i => !string.IsNullOrEmpty(i) && (i.StartsWith("Magnet") || i.Contains("167")));
		bool hasIron = ingredients.Any(i => !string.IsNullOrEmpty(i) && (i.StartsWith("IronIngot") || i.Contains("41")));
		if (hasMagnet && hasIron)
		{
			CraftingRecipe recipe = new CraftingRecipe();
			recipe.ResultValue = Terrain.MakeBlockValue(BlockIndex);
			recipe.ResultCount = 1;
			recipe.Description = "Membuat Manipulator Fisika";
			recipe.Ingredients = (string[])ingredients.Clone();
			return recipe;
		}
		return null;
	}
}

// ============================================================================
// 6. Physics Bearing: Mechanical Rotator / Turret Axis (Create Style)
// ============================================================================
public class PhysicsBearingBlock : Block
{
	public BlockMesh m_blockMesh = new BlockMesh();
	public BoundingBox[] m_collisionBoxes = new BoundingBox[1];

	public PhysicsBearingBlock()
	{
		DefaultDisplayName = "Bearing Putar Fisika";
		DefaultDescription = "Poros putar mekanik (Create style). Berputar saat dialiri sinyal listrik atau diketuk, memutar struktur yang menempel di atasnya.";
		DefaultCategory = "Mechanics";
		MaxStacking = 16;
		IsCollidable = true;
		IsPlaceable = true;
	}

	public override void Initialize()
	{
		m_blockMesh = new BlockMesh();
		ProceduralMeshHelper.AddBox(m_blockMesh, new Vector3(0.05f, 0.0f, 0.05f), new Vector3(0.95f, 0.60f, 0.95f), Color.White, SubLevelAtlas.SteelCasing);
		ProceduralMeshHelper.AddBox(m_blockMesh, new Vector3(0.15f, 0.60f, 0.15f), new Vector3(0.85f, 0.95f, 0.85f), Color.White, SubLevelAtlas.BearingRing);
		ProceduralMeshHelper.AddBox(m_blockMesh, new Vector3(0.35f, 0.95f, 0.35f), new Vector3(0.65f, 1.00f, 0.65f), Color.White, SubLevelAtlas.BrassCopper);

		m_collisionBoxes[0] = new BoundingBox(Vector3.Zero, Vector3.One);
		base.Initialize();
	}

	public override void GenerateTerrainVertices(BlockGeometryGenerator generator, TerrainGeometry geometry, int value, int x, int y, int z)
	{
		Texture2D tex = SubLevelAtlas.GetTexture();
		TerrainGeometrySubset subset = (tex != null) ? geometry.GetGeometry(tex).SubsetOpaque : geometry.SubsetOpaque;
		generator.GenerateMeshVertices(this, x, y, z, m_blockMesh, Color.White, null, subset);
	}

	public override void DrawBlock(PrimitivesRenderer3D primitivesRenderer, int value, Color color, float size, ref Matrix matrix, DrawBlockEnvironmentData environmentData)
	{
		Texture2D tex = SubLevelAtlas.GetTexture();
		if (tex != null)
			BlocksManager.DrawMeshBlock(primitivesRenderer, m_blockMesh, tex, color, size, ref matrix, environmentData);
		else
			BlocksManager.DrawMeshBlock(primitivesRenderer, m_blockMesh, color, size, ref matrix, environmentData);
	}

	public override BoundingBox[] GetCustomCollisionBoxes(SubsystemTerrain terrain, int value) => m_collisionBoxes;

	public override CraftingRecipe GetAdHocCraftingRecipe(SubsystemTerrain terrain, string[] ingredients, float heatLevel, float playerLevel)
	{
		// Planks + Iron Ingot -> Bearing Putar
		bool hasIron = ingredients.Any(i => !string.IsNullOrEmpty(i) && (i.StartsWith("IronIngot") || i.Contains("41")));
		bool hasPlanks = ingredients.Any(i => !string.IsNullOrEmpty(i) && (i.StartsWith("Planks") || i.Contains("4")));
		if (hasIron && hasPlanks)
		{
			CraftingRecipe recipe = new CraftingRecipe();
			recipe.ResultValue = Terrain.MakeBlockValue(BlockIndex);
			recipe.ResultCount = 1;
			recipe.Description = "Membuat Bearing Putar Fisika";
			recipe.Ingredients = (string[])ingredients.Clone();
			return recipe;
		}
		return null;
	}
}

// ============================================================================
// 7. Physics Piston: Linear Actuator / Mechanical Push-Pull Ram
// ============================================================================
public class PhysicsPistonBlock : Block
{
	public BlockMesh m_blockMesh = new BlockMesh();
	public BoundingBox[] m_collisionBoxes = new BoundingBox[1];

	public PhysicsPistonBlock()
	{
		DefaultDisplayName = "Piston Fisika";
		DefaultDescription = "Piston dorong-tarik mekanis. Mendorong balok atau objek fisika lain saat menerima sinyal listrik, dan menarik kembali saat listrik padam.";
		DefaultCategory = "Mechanics";
		MaxStacking = 16;
		IsCollidable = true;
		IsPlaceable = true;
	}

	public override void Initialize()
	{
		m_blockMesh = new BlockMesh();
		ProceduralMeshHelper.AddBox(m_blockMesh, new Vector3(0.05f, 0.0f, 0.05f), new Vector3(0.95f, 0.70f, 0.95f), Color.White, SubLevelAtlas.SteelCasing);
		ProceduralMeshHelper.AddBox(m_blockMesh, new Vector3(0.20f, 0.70f, 0.20f), new Vector3(0.80f, 0.90f, 0.80f), Color.White, SubLevelAtlas.PistonShaft);
		ProceduralMeshHelper.AddBox(m_blockMesh, new Vector3(0.10f, 0.90f, 0.10f), new Vector3(0.90f, 1.00f, 0.90f), Color.White, SubLevelAtlas.MahoganyWood);

		m_collisionBoxes[0] = new BoundingBox(Vector3.Zero, Vector3.One);
		base.Initialize();
	}

	public override void GenerateTerrainVertices(BlockGeometryGenerator generator, TerrainGeometry geometry, int value, int x, int y, int z)
	{
		Texture2D tex = SubLevelAtlas.GetTexture();
		TerrainGeometrySubset subset = (tex != null) ? geometry.GetGeometry(tex).SubsetOpaque : geometry.SubsetOpaque;
		generator.GenerateMeshVertices(this, x, y, z, m_blockMesh, Color.White, null, subset);
	}

	public override void DrawBlock(PrimitivesRenderer3D primitivesRenderer, int value, Color color, float size, ref Matrix matrix, DrawBlockEnvironmentData environmentData)
	{
		Texture2D tex = SubLevelAtlas.GetTexture();
		if (tex != null)
			BlocksManager.DrawMeshBlock(primitivesRenderer, m_blockMesh, tex, color, size, ref matrix, environmentData);
		else
			BlocksManager.DrawMeshBlock(primitivesRenderer, m_blockMesh, color, size, ref matrix, environmentData);
	}

	public override BoundingBox[] GetCustomCollisionBoxes(SubsystemTerrain terrain, int value) => m_collisionBoxes;

	public override CraftingRecipe GetAdHocCraftingRecipe(SubsystemTerrain terrain, string[] ingredients, float heatLevel, float playerLevel)
	{
		// Iron Ingot + Switch + Planks -> Piston Fisika
		bool hasIron = ingredients.Any(i => !string.IsNullOrEmpty(i) && (i.StartsWith("IronIngot") || i.Contains("41")));
		bool hasWood = ingredients.Any(i => !string.IsNullOrEmpty(i) && (i.StartsWith("Planks") || i.Contains("4")));
		if (hasIron && hasWood)
		{
			CraftingRecipe recipe = new CraftingRecipe();
			recipe.ResultValue = Terrain.MakeBlockValue(BlockIndex);
			recipe.ResultCount = 1;
			recipe.Description = "Membuat Piston Fisika";
			recipe.Ingredients = (string[])ingredients.Clone();
			return recipe;
		}
		return null;
	}
}

// ============================================================================
// 8. Physics Anchor: Magnetic Docking Clamp & Port Lock
// ============================================================================
public class PhysicsAnchorBlock : Block
{
	public BlockMesh m_blockMesh = new BlockMesh();
	public BoundingBox[] m_collisionBoxes = new BoundingBox[1];

	public PhysicsAnchorBlock()
	{
		DefaultDisplayName = "Jangkar Docking Fisika";
		DefaultDescription = "Klem magnetik pengunci kapal ke dermaga atau menyambungkan dua wahana fisika. Ketuk untuk mengunci posisi di udara/laut.";
		DefaultCategory = "Mechanics";
		MaxStacking = 16;
		IsCollidable = true;
		IsPlaceable = true;
	}

	public override void Initialize()
	{
		m_blockMesh = new BlockMesh();
		ProceduralMeshHelper.AddBox(m_blockMesh, new Vector3(0.10f, 0.0f, 0.10f), new Vector3(0.90f, 0.40f, 0.90f), Color.White, SubLevelAtlas.SteelCasing);
		ProceduralMeshHelper.AddBox(m_blockMesh, new Vector3(0.20f, 0.40f, 0.20f), new Vector3(0.80f, 0.75f, 0.80f), Color.White, SubLevelAtlas.DockingPad);
		ProceduralMeshHelper.AddBox(m_blockMesh, new Vector3(0.35f, 0.75f, 0.35f), new Vector3(0.65f, 0.95f, 0.65f), Color.White, SubLevelAtlas.GlowingCore);

		m_collisionBoxes[0] = new BoundingBox(new Vector3(0.1f, 0f, 0.1f), new Vector3(0.9f, 0.95f, 0.9f));
		base.Initialize();
	}

	public override void GenerateTerrainVertices(BlockGeometryGenerator generator, TerrainGeometry geometry, int value, int x, int y, int z)
	{
		Texture2D tex = SubLevelAtlas.GetTexture();
		TerrainGeometrySubset subset = (tex != null) ? geometry.GetGeometry(tex).SubsetOpaque : geometry.SubsetOpaque;
		generator.GenerateMeshVertices(this, x, y, z, m_blockMesh, Color.White, null, subset);
	}

	public override void DrawBlock(PrimitivesRenderer3D primitivesRenderer, int value, Color color, float size, ref Matrix matrix, DrawBlockEnvironmentData environmentData)
	{
		Texture2D tex = SubLevelAtlas.GetTexture();
		if (tex != null)
			BlocksManager.DrawMeshBlock(primitivesRenderer, m_blockMesh, tex, color, size, ref matrix, environmentData);
		else
			BlocksManager.DrawMeshBlock(primitivesRenderer, m_blockMesh, color, size, ref matrix, environmentData);
	}

	public override BoundingBox[] GetCustomCollisionBoxes(SubsystemTerrain terrain, int value) => m_collisionBoxes;

	public override CraftingRecipe GetAdHocCraftingRecipe(SubsystemTerrain terrain, string[] ingredients, float heatLevel, float playerLevel)
	{
		// Magnet (167) + Iron Ingot (41) -> Jangkar Docking
		bool hasMagnet = ingredients.Any(i => !string.IsNullOrEmpty(i) && (i.StartsWith("Magnet") || i.Contains("167")));
		bool hasIron = ingredients.Any(i => !string.IsNullOrEmpty(i) && (i.StartsWith("IronIngot") || i.Contains("41")));
		if (hasMagnet && hasIron)
		{
			CraftingRecipe recipe = new CraftingRecipe();
			recipe.ResultValue = Terrain.MakeBlockValue(BlockIndex);
			recipe.ResultCount = 1;
			recipe.Description = "Membuat Jangkar Docking Fisika";
			recipe.Ingredients = (string[])ingredients.Clone();
			return recipe;
		}
		return null;
	}
}

// ============================================================================
// 9. Physics Seat: Passenger Seat / Pilot Chair (Multiplayer Riding)
// ============================================================================
public class PhysicsSeatBlock : Block
{
	public BlockMesh[] m_meshesByRotation = new BlockMesh[4];
	public BlockMesh m_standaloneMesh = new BlockMesh();
	public BoundingBox[][] m_collisionBoxes = new BoundingBox[4][];

	public PhysicsSeatBlock()
	{
		DefaultDisplayName = "Kursi Penumpang Fisika";
		DefaultDescription = "Kursi penumpang dan pilot. Ketuk untuk duduk aman saat kapal bergerak cepat. Lompat atau jongkok untuk berdiri.";
		DefaultCategory = "Mechanics";
		MaxStacking = 16;
		IsCollidable = true;
		IsPlaceable = true;
	}

	public override void Initialize()
	{
		for (int rot = 0; rot < 4; rot++)
		{
			Matrix rotMat = Matrix.CreateRotationY(rot * (float)Math.PI / 2f) * Matrix.CreateTranslation(0.5f, 0f, 0.5f);
			BlockMesh mesh = new BlockMesh();

			// 4 Steel legs
			ProceduralMeshHelper.AddBox(mesh, new Vector3(-0.35f, 0.0f, -0.35f), new Vector3(-0.25f, 0.40f, -0.25f), Color.White, SubLevelAtlas.SteelCasing, rotMat);
			ProceduralMeshHelper.AddBox(mesh, new Vector3(0.25f, 0.0f, -0.35f), new Vector3(0.35f, 0.40f, -0.25f), Color.White, SubLevelAtlas.SteelCasing, rotMat);
			ProceduralMeshHelper.AddBox(mesh, new Vector3(-0.35f, 0.0f, 0.25f), new Vector3(-0.25f, 0.40f, 0.35f), Color.White, SubLevelAtlas.SteelCasing, rotMat);
			ProceduralMeshHelper.AddBox(mesh, new Vector3(0.25f, 0.0f, 0.25f), new Vector3(0.35f, 0.40f, 0.35f), Color.White, SubLevelAtlas.SteelCasing, rotMat);

			// Padded cushion seat
			ProceduralMeshHelper.AddBox(mesh, new Vector3(-0.40f, 0.35f, -0.40f), new Vector3(0.40f, 0.50f, 0.40f), Color.White, SubLevelAtlas.LeatherSeat, rotMat);
			// Backrest
			ProceduralMeshHelper.AddBox(mesh, new Vector3(-0.40f, 0.50f, -0.40f), new Vector3(0.40f, 0.95f, -0.25f), Color.White, SubLevelAtlas.LeatherSeat, rotMat);

			m_meshesByRotation[rot] = mesh;
			m_collisionBoxes[rot] = new BoundingBox[] { mesh.CalculateBoundingBox() };
		}

		m_standaloneMesh = m_meshesByRotation[0];
		base.Initialize();
	}

	public override void GenerateTerrainVertices(BlockGeometryGenerator generator, TerrainGeometry geometry, int value, int x, int y, int z)
	{
		int rot = Terrain.ExtractData(value) & 3;
		Texture2D tex = SubLevelAtlas.GetTexture();
		TerrainGeometrySubset subset = (tex != null) ? geometry.GetGeometry(tex).SubsetOpaque : geometry.SubsetOpaque;
		generator.GenerateMeshVertices(this, x, y, z, m_meshesByRotation[rot], Color.White, null, subset);
	}

	public override void DrawBlock(PrimitivesRenderer3D primitivesRenderer, int value, Color color, float size, ref Matrix matrix, DrawBlockEnvironmentData environmentData)
	{
		Texture2D tex = SubLevelAtlas.GetTexture();
		if (tex != null)
			BlocksManager.DrawMeshBlock(primitivesRenderer, m_standaloneMesh, tex, color, size, ref matrix, environmentData);
		else
			BlocksManager.DrawMeshBlock(primitivesRenderer, m_standaloneMesh, color, size, ref matrix, environmentData);
	}

	public override BoundingBox[] GetCustomCollisionBoxes(SubsystemTerrain terrain, int value)
	{
		int rot = Terrain.ExtractData(value) & 3;
		return m_collisionBoxes[rot];
	}

	public override BlockPlacementData GetPlacementValue(SubsystemTerrain subsystemTerrain, ComponentMiner componentMiner, int value, TerrainRaycastResult raycastResult)
	{
		Vector3 forward = componentMiner.ComponentPlayer != null ? componentMiner.ComponentPlayer.ComponentCreatureModel.EyeRotation.GetForwardVector() : Vector3.UnitZ;
		int rot = (MathF.Abs(forward.X) > MathF.Abs(forward.Z)) ? ((forward.X > 0f) ? 1 : 3) : ((forward.Z > 0f) ? 0 : 2);
		BlockPlacementData result = default;
		result.Value = Terrain.ReplaceData(value, rot);
		result.CellFace = raycastResult.CellFace;
		return result;
	}

	public override CraftingRecipe GetAdHocCraftingRecipe(SubsystemTerrain terrain, string[] ingredients, float heatLevel, float playerLevel)
	{
		// Leather / Canvas + Iron Ingot -> Kursi Penumpang
		bool hasCloth = ingredients.Any(i => !string.IsNullOrEmpty(i) && (i.StartsWith("Leather") || i.StartsWith("Canvas") || i.Contains("203") || i.Contains("204")));
		bool hasIron = ingredients.Any(i => !string.IsNullOrEmpty(i) && (i.StartsWith("IronIngot") || i.Contains("41")));
		if (hasCloth && hasIron)
		{
			CraftingRecipe recipe = new CraftingRecipe();
			recipe.ResultValue = Terrain.MakeBlockValue(BlockIndex);
			recipe.ResultCount = 1;
			recipe.Description = "Membuat Kursi Penumpang Fisika";
			recipe.Ingredients = (string[])ingredients.Clone();
			return recipe;
		}
		return null;
	}
}

// ============================================================================
// 12. Physics Hinge Block (Engsel)
// ============================================================================
public class PhysicsHingeBlock : Block
{
	public BlockMesh m_standaloneMesh = new BlockMesh();
	public BoundingBox[] m_collisionBoxes = new BoundingBox[1];

	public PhysicsHingeBlock()
	{
		DefaultDisplayName = "Engsel Fisika";
		DefaultDescription = "Blok engsel mekanik untuk menghubungkan struktur rigid body yang bisa berputar (Hinge Joint).";
		DefaultCategory = "Mechanics";
		MaxStacking = 16;
		IsCollidable = true;
		IsPlaceable = true;
	}

	public override void Initialize()
	{
		m_standaloneMesh = new BlockMesh();
		ProceduralMeshHelper.AddBox(m_standaloneMesh, new Vector3(0.2f, 0.2f, 0.0f), new Vector3(0.8f, 0.8f, 0.3f), Color.White, SubLevelAtlas.SteelCasing);
		ProceduralMeshHelper.AddBox(m_standaloneMesh, new Vector3(0.35f, 0.35f, 0.3f), new Vector3(0.65f, 0.65f, 0.7f), Color.White, SubLevelAtlas.BearingRing);
		ProceduralMeshHelper.AddBox(m_standaloneMesh, new Vector3(0.2f, 0.2f, 0.7f), new Vector3(0.8f, 0.8f, 1.0f), Color.White, SubLevelAtlas.SteelCasing);

		m_collisionBoxes[0] = new BoundingBox(Vector3.Zero, Vector3.One);
		base.Initialize();
	}

	public override void GenerateTerrainVertices(BlockGeometryGenerator generator, TerrainGeometry geometry, int value, int x, int y, int z)
	{
		Texture2D tex = SubLevelAtlas.GetTexture();
		TerrainGeometrySubset subset = (tex != null) ? geometry.GetGeometry(tex).SubsetOpaque : geometry.SubsetOpaque;
		generator.GenerateMeshVertices(this, x, y, z, m_standaloneMesh, Color.White, null, subset);
	}

	public override void DrawBlock(PrimitivesRenderer3D primitivesRenderer, int value, Color color, float size, ref Matrix matrix, DrawBlockEnvironmentData environmentData)
	{
		Texture2D tex = SubLevelAtlas.GetTexture();
		if (tex != null)
			BlocksManager.DrawMeshBlock(primitivesRenderer, m_standaloneMesh, tex, color, size, ref matrix, environmentData);
		else
			BlocksManager.DrawMeshBlock(primitivesRenderer, m_standaloneMesh, color, size, ref matrix, environmentData);
	}

	public override BoundingBox[] GetCustomCollisionBoxes(SubsystemTerrain terrain, int value) => m_collisionBoxes;
}

// ============================================================================
// 13. Physics Slider Block (Blok Geser)
// ============================================================================
public class PhysicsSliderBlock : Block
{
	public BlockMesh m_standaloneMesh = new BlockMesh();
	public BoundingBox[] m_collisionBoxes = new BoundingBox[1];

	public PhysicsSliderBlock()
	{
		DefaultDisplayName = "Slider Fisika";
		DefaultDescription = "Blok pemandu geser linier untuk struktur rigid body (Slider Joint / Piston path).";
		DefaultCategory = "Mechanics";
		MaxStacking = 16;
		IsCollidable = true;
		IsPlaceable = true;
	}

	public override void Initialize()
	{
		m_standaloneMesh = new BlockMesh();
		ProceduralMeshHelper.AddBox(m_standaloneMesh, new Vector3(0.1f, 0.1f, 0.0f), new Vector3(0.9f, 0.9f, 0.4f), Color.White, SubLevelAtlas.SteelCasing);
		ProceduralMeshHelper.AddBox(m_standaloneMesh, new Vector3(0.3f, 0.3f, 0.4f), new Vector3(0.7f, 0.7f, 1.0f), Color.White, SubLevelAtlas.PistonShaft);

		m_collisionBoxes[0] = new BoundingBox(Vector3.Zero, Vector3.One);
		base.Initialize();
	}

	public override void GenerateTerrainVertices(BlockGeometryGenerator generator, TerrainGeometry geometry, int value, int x, int y, int z)
	{
		Texture2D tex = SubLevelAtlas.GetTexture();
		TerrainGeometrySubset subset = (tex != null) ? geometry.GetGeometry(tex).SubsetOpaque : geometry.SubsetOpaque;
		generator.GenerateMeshVertices(this, x, y, z, m_standaloneMesh, Color.White, null, subset);
	}

	public override void DrawBlock(PrimitivesRenderer3D primitivesRenderer, int value, Color color, float size, ref Matrix matrix, DrawBlockEnvironmentData environmentData)
	{
		Texture2D tex = SubLevelAtlas.GetTexture();
		if (tex != null)
			BlocksManager.DrawMeshBlock(primitivesRenderer, m_standaloneMesh, tex, color, size, ref matrix, environmentData);
		else
			BlocksManager.DrawMeshBlock(primitivesRenderer, m_standaloneMesh, color, size, ref matrix, environmentData);
	}

	public override BoundingBox[] GetCustomCollisionBoxes(SubsystemTerrain terrain, int value) => m_collisionBoxes;
}

// ============================================================================
// 14. Physics Piston Block (Piston Pendorong)
// ============================================================================
public class PhysicsPistonBlock : Block
{
	public BlockMesh m_standaloneMesh = new BlockMesh();
	public BoundingBox[] m_collisionBoxes = new BoundingBox[1];

	public PhysicsPistonBlock()
	{
		DefaultDisplayName = "Piston Fisika";
		DefaultDescription = "Piston mekanik yang mendorong struktur blok saat diaktifkan dengan sinyal redstone atau interaksi.";
		DefaultCategory = "Mechanics";
		MaxStacking = 16;
		IsCollidable = true;
		IsPlaceable = true;
	}

	public override void Initialize()
	{
		m_standaloneMesh = new BlockMesh();
		ProceduralMeshHelper.AddBox(m_standaloneMesh, new Vector3(0.0f, 0.0f, 0.0f), new Vector3(1.0f, 1.0f, 0.6f), Color.White, SubLevelAtlas.SteelCasing);
		ProceduralMeshHelper.AddBox(m_standaloneMesh, new Vector3(0.2f, 0.2f, 0.6f), new Vector3(0.8f, 0.8f, 1.0f), Color.White, SubLevelAtlas.PistonShaft);

		m_collisionBoxes[0] = new BoundingBox(Vector3.Zero, Vector3.One);
		base.Initialize();
	}

	public override void GenerateTerrainVertices(BlockGeometryGenerator generator, TerrainGeometry geometry, int value, int x, int y, int z)
	{
		Texture2D tex = SubLevelAtlas.GetTexture();
		TerrainGeometrySubset subset = (tex != null) ? geometry.GetGeometry(tex).SubsetOpaque : geometry.SubsetOpaque;
		generator.GenerateMeshVertices(this, x, y, z, m_standaloneMesh, Color.White, null, subset);
	}

	public override void DrawBlock(PrimitivesRenderer3D primitivesRenderer, int value, Color color, float size, ref Matrix matrix, DrawBlockEnvironmentData environmentData)
	{
		Texture2D tex = SubLevelAtlas.GetTexture();
		if (tex != null)
			BlocksManager.DrawMeshBlock(primitivesRenderer, m_standaloneMesh, tex, color, size, ref matrix, environmentData);
		else
			BlocksManager.DrawMeshBlock(primitivesRenderer, m_standaloneMesh, color, size, ref matrix, environmentData);
	}

	public override BoundingBox[] GetCustomCollisionBoxes(SubsystemTerrain terrain, int value) => m_collisionBoxes;

	public override CraftingRecipe GetAdHocCraftingRecipe(SubsystemTerrain terrain, string[] ingredients, float heatLevel, float playerLevel)
	{
		// Mover (PhysicsMover) + Iron Ingot + Piston (vanilla or copper)
		bool hasMover = ingredients.Any(i => !string.IsNullOrEmpty(i) && (i.Contains("Mover") || i.Contains("PhysicsMover")));
		bool hasIron = ingredients.Any(i => !string.IsNullOrEmpty(i) && (i.StartsWith("IronIngot") || i.Contains("41")));
		if (hasMover && hasIron)
		{
			CraftingRecipe recipe = new CraftingRecipe();
			recipe.ResultValue = Terrain.MakeBlockValue(BlockIndex);
			recipe.ResultCount = 1;
			recipe.Description = "Membuat Piston Fisika";
			recipe.Ingredients = (string[])ingredients.Clone();
			return recipe;
		}
		return null;
	}
}
