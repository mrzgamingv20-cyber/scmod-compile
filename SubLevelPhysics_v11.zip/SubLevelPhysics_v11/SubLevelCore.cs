// SubLevelPhysics v10 - Core configuration, scanning, sub-level data & in-flight persistence
using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Linq;
using Engine;

namespace Game;

public static class SubLevelConfig
{
	public const int MaxBlocksPerBody = 800;       // blocks in one body (glue group or tree)
	public const int MaxBodies = 12;               // simultaneous physics bodies
	public const int MaxTotalBodies = 24;          // hard cap including fragments from broken structures
	public const float RideGrace = 0.25f;          // seconds an entity stays carried after losing floor
	public const float RideMinUpright = 0.40f;     // body must be this upright before boarding
	public const int MaxLeafDistance = 3;          // leaves farther than this from a log are not part of tree
	public const float MaxBodyAge = 60f;           // seconds; felled trees settle after this
	public const float MaxVisibleDistance = 200f;
	public const bool AutoTrees = true;            // felled trees topple by themselves
	public const float TreeKick = 0.25f;           // initial angular speed of falling tree (rad/s)
	public const float TreeReleaseTilt = 0.8f;     // radians; hinge release tilt
	public const bool RestoreBlocks = true;
	public const float ReachDistance = 6.5f;       // reach distance for dig/interact
	public const int MaxGlueBox = 32;              // longest edge of glue box
	public const float LeverPollInterval = 0.20f;  // seconds between lever checks
	public const float LeverScanInterval = 2.5f;   // seconds between searches for levers
	public const float GroupActiveDistance = 64f;  // active distance from players
	public const float PushSpeed = 7f;             // manipulator push speed (m/s)
	public const float GrabMaxDistance = 16f;      // manipulator grab release distance
	public const float WakeInterval = 2f;          // sleep wake check interval
	public const float WaterBuoyancyPerBlock = 14f;// upward buoyant force per submerged block
	public const float WaterDragLinear = 1.2f;     // linear drag damping in water
	public const float WaterDragAngular = 1.5f;    // angular drag damping in water
}

public static class ToolConfig
{
	static Block BlockOf(int value) { return BlocksManager.Blocks[Terrain.ExtractContents(value)]; }

	public static bool IsGlue(int value)
	{
		Block b = BlockOf(value);
		return b is PhysicsGlueBlock || b is CottonWadBlock;
	}

	public static bool IsMover(int value)
	{
		Block b = BlockOf(value);
		return b is PhysicsMoverBlock || b is MagnetBlock;
	}

	public static bool IsLever(int value)
	{
		Block b = BlockOf(value);
		return b is PhysicsLeverBlock || b is SwitchBlock;
	}

	public static bool IsHelm(int value)
	{
		Block b = BlockOf(value);
		return b is PhysicsHelmBlock || b is CraftingTableBlock;
	}

	public static bool IsEnvelope(int value)
	{
		Block b = BlockOf(value);
		return b is CanvasBlock;
	}

	public static bool IsEngine(int value)
	{
		Block b = BlockOf(value);
		return b is PhysicsEngineBlock || b is FurnaceBlock || b is LitFurnaceBlock;
	}

	public static bool IsBearing(int value)
	{
		Block b = BlockOf(value);
		return b is PhysicsBearingBlock;
	}

	public static bool IsHinge(int value)
	{
		Block b = BlockOf(value);
		return b is PhysicsHingeBlock;
	}

	public static bool IsSlider(int value)
	{
		Block b = BlockOf(value);
		return b is PhysicsSliderBlock;
	}

	public static bool IsPiston(int value)
	{
		Block b = BlockOf(value);
		return b is PhysicsPistonBlock;
	}

	public static bool IsAnchor(int value)
	{
		Block b = BlockOf(value);
		return b is PhysicsAnchorBlock;
	}

	public static bool IsSeat(int value)
	{
		Block b = BlockOf(value);
		return b is PhysicsSeatBlock;
	}
}

public static class ShipConfig
{
	public const float RequiredEnvelopeFraction = 0.28f; // share of balloon blocks that gives hover lift
	public const float HoverFactor = 0.98f;              // lift / weight with no input
	public const float AscendBonus = 0.50f;              // extra lift while Jump is held
	public const float VerticalDrag = 0.9f;              // damping of vertical speed (1/s)
	public const float RequiredEngineFraction = 0.05f;   // share of engine blocks that gives ThrustAccelAtRequired
	public const float ThrustAccelAtRequired = 4.5f;     // m/s^2
	public const float MaxThrustAccel = 9f;
	public const float YawRate = 1.0f;                   // rad/s at full stick
	public const float YawResponse = 2.8f;
	public const float RightingAccel = 5.5f;             // rad/s^2 keeping ship level
	public const float TiltDamping = 2.5f;
	public const float LinearDamping = 0.25f;
	public const float AngularDamping = 0.5f;
	public const float DismountGrace = 0.8f;
}

public static class StructureScanner
{
	static readonly Point3[] Neighbors6 =
	{
		new Point3(1, 0, 0), new Point3(-1, 0, 0), new Point3(0, 1, 0),
		new Point3(0, -1, 0), new Point3(0, 0, 1), new Point3(0, 0, -1)
	};

	static Block BlockOf(int value)
	{
		return BlocksManager.Blocks[Terrain.ExtractContents(value)];
	}

	public static bool IsLog(int value) { return BlockOf(value) is WoodBlock; }

	public static bool IsLeaves(int value) { return BlockOf(value) is LeavesBlock; }

	public static bool IsStructural(int value)
	{
		if (Terrain.ExtractContents(value) == 0)
		{
			return false;
		}
		Block b = BlockOf(value);
		return b is WoodBlock || b is LeavesBlock || b is PlanksBlock || b is BrickBlock || b is BricksBlock
			|| b is StoneBrickBlock || b is CobblestoneBlock || b is GlassBlock || b is FramedGlassBlock
			|| b is PaintedCubeBlock || b is SlabBlock || b is StairsBlock || b is FenceBlock || b is WindowBlock
			|| b is IronBlock || b is CopperBlock || b is DiamondBlock
			|| b is CanvasBlock || b is FurnaceBlock || b is LitFurnaceBlock || b is CraftingTableBlock
			|| b is DoorBlock || b is TrapdoorBlock || b is FenceGateBlock || b is ChestBlock
			|| b is WireBlock || b is ElectricElementBlock || b is MountedElectricElementBlock
			|| b is PhysicsGlueBlock || b is PhysicsLeverBlock || b is PhysicsHelmBlock
			|| b is PhysicsEngineBlock || b is PhysicsMoverBlock || b is PhysicsBearingBlock
			|| b is PhysicsPistonBlock || b is PhysicsAnchorBlock || b is PhysicsSeatBlock;
	}

	public static bool IsOpaqueCube(int value)
	{
		int c = Terrain.ExtractContents(value);
		if (c == 0) return false;
		Block b = BlocksManager.Blocks[c];
		return b is CubeBlock && !b.IsTransparent_(value);
	}

	public static bool IsSolid(int value)
	{
		int c = Terrain.ExtractContents(value);
		return c != 0 && BlocksManager.Blocks[c].IsCollidable_(value);
	}

	public static bool ScanConnected(Terrain terrain, Point3 start,
		out List<Point3> cells, out int nonLeafCount, out bool treeLike, out bool anchored)
	{
		cells = new List<Point3>();
		nonLeafCount = 0;
		treeLike = false;
		anchored = false;
		int startVal = terrain.GetCellValue(start.X, start.Y, start.Z);
		if (!IsStructural(startVal) || IsLeaves(startVal))
		{
			return false;
		}
		HashSet<Point3> claimed = new HashSet<Point3>();
		Queue<Point3> queue = new Queue<Point3>();
		claimed.Add(start);
		queue.Enqueue(start);
		bool supportedBelow = false;
		bool supportedSide = false;
		int logs = 0;
		bool tooBig = false;

		while (queue.Count > 0)
		{
			Point3 p = queue.Dequeue();
			cells.Add(p);
			if (cells.Count > SubLevelConfig.MaxBlocksPerBody)
			{
				tooBig = true;
				break;
			}
			int v = terrain.GetCellValue(p.X, p.Y, p.Z);
			if (IsLog(v)) logs++;

			for (int i = 0; i < 6; i++)
			{
				Point3 n = new Point3(p.X + Neighbors6[i].X, p.Y + Neighbors6[i].Y, p.Z + Neighbors6[i].Z);
				int nv = terrain.GetCellValue(n.X, n.Y, n.Z);
				if (IsSolid(nv) && !IsStructural(nv))
				{
					if (Neighbors6[i].Y == -1) supportedBelow = true;
					else supportedSide = true;
				}
			}
			for (int dx = -1; dx <= 1; dx++)
			{
				for (int dy = -1; dy <= 1; dy++)
				{
					for (int dz = -1; dz <= 1; dz++)
					{
						if (dx == 0 && dy == 0 && dz == 0) continue;
						Point3 n = new Point3(p.X + dx, p.Y + dy, p.Z + dz);
						if (n.Y < 0 || n.Y > 255 || claimed.Contains(n)) continue;
						int nv = terrain.GetCellValue(n.X, n.Y, n.Z);
						if (IsStructural(nv) && !IsLeaves(nv))
						{
							claimed.Add(n);
							queue.Enqueue(n);
						}
					}
				}
			}
		}
		if (tooBig) return false;
		nonLeafCount = cells.Count;
		treeLike = (logs == nonLeafCount);
		anchored = supportedBelow || (!treeLike && supportedSide);
		if (anchored) return true;

		if (logs > 0)
		{
			Dictionary<Point3, int> distance = new Dictionary<Point3, int>();
			Queue<Point3> leafQueue = new Queue<Point3>();
			for (int i = 0; i < nonLeafCount; i++)
			{
				if (IsLog(terrain.GetCellValue(cells[i].X, cells[i].Y, cells[i].Z)))
				{
					distance[cells[i]] = 0;
					leafQueue.Enqueue(cells[i]);
				}
			}
			while (leafQueue.Count > 0)
			{
				Point3 p = leafQueue.Dequeue();
				int d = distance[p];
				if (d >= SubLevelConfig.MaxLeafDistance) continue;
				for (int i = 0; i < 6; i++)
				{
					Point3 n = new Point3(p.X + Neighbors6[i].X, p.Y + Neighbors6[i].Y, p.Z + Neighbors6[i].Z);
					if (n.Y < 0 || n.Y > 255 || distance.ContainsKey(n) || claimed.Contains(n)) continue;
					if (IsLeaves(terrain.GetCellValue(n.X, n.Y, n.Z)))
					{
						distance[n] = d + 1;
						claimed.Add(n);
						cells.Add(n);
						if (cells.Count > SubLevelConfig.MaxBlocksPerBody) return false;
						leafQueue.Enqueue(n);
					}
				}
			}
		}
		return true;
	}
}

public sealed class ShipData
{
	public ComponentPlayer Pilot;
	public PVec3 ForwardLocal;           // ship forward / right in body-local space
	public PVec3 RightLocal;
	public PVec3 EnvelopeCentroidLocal;
	public PVec3 SeatLocal;
	public float EnvelopeFraction;
	public float EngineFraction;
}

// A group of blocks moving as an independent 3D rigid body (Sable / Valkyrien Skies / Create style).
public sealed class SubLevel
{
	public RigidBody3D Body;
	public int Count;
	public int[] Values;        // block values
	public int[] Cx;            // original cell coordinates of each block (the body's own frame)
	public int[] Cy;
	public int[] Cz;
	public float[] Mass;
	public PVec3[] Local;       // block centers relative to center of mass (local space)
	public Dictionary<Point3, int> Index = new Dictionary<Point3, int>();
	public PVec3 BoundsMin;     // cell bounds in body frame
	public PVec3 BoundsMax;
	public bool[] Hidden;       // enclosed by opaque cubes: not drawn
	public bool TreeMode;
	public int Humidity;
	public int Temperature;
	public ShipData Ship;       // non-null = piloted airship
	public GlueGroup Group;     // non-null = activated from glue group
	public float SleepClock;

	// v10 Features:
	public bool EnginesElectricallyPowered;
	public bool IsAnchored;     // docked / clamped in place
	public float BearingAngle;  // rotation of attached bearing
	public bool PistonExtended;
	public float PistonDistance;
	public readonly List<ComponentPlayer> Passengers = new List<ComponentPlayer>();

	// Evaluates internal electrical circuitry: power sources -> conductors -> receivers
	public void UpdateElectrics()
	{
		bool power = false;
		for (int i = 0; i < Count; i++)
		{
			int val = Values[i];
			Block b = BlocksManager.Blocks[Terrain.ExtractContents(val)];
			if (b is PhysicsLeverBlock || b is SwitchBlock)
			{
				if ((Terrain.ExtractData(val) & 1) != 0) // Lever ON
				{
					power = true;
					break;
				}
			}
			else if (b is BatteryBlock)
			{
				power = true;
				break;
			}
		}

		EnginesElectricallyPowered = power;

		// Power lights, doors, bearings, pistons
		for (int i = 0; i < Count; i++)
		{
			int val = Values[i];
			int content = Terrain.ExtractContents(val);
			Block b = BlocksManager.Blocks[content];

			// Electric light: 143 (unlit) <-> 144 (lit)
			if (power && content == 143)
				Values[i] = Terrain.MakeBlockValue(144, 0, Terrain.ExtractData(val));
			else if (!power && content == 144)
				Values[i] = Terrain.MakeBlockValue(143, 0, Terrain.ExtractData(val));
			// Automatic doors
			else if (b is DoorBlock)
			{
				int data = Terrain.ExtractData(val);
				bool open = DoorBlock.GetOpen(data);
				if (power && !open) Values[i] = Terrain.ReplaceData(val, DoorBlock.SetOpen(data, true));
				else if (!power && open) Values[i] = Terrain.ReplaceData(val, DoorBlock.SetOpen(data, false));
			}
			else if (b is TrapdoorBlock)
			{
				int data = Terrain.ExtractData(val);
				bool open = TrapdoorBlock.GetOpen(data);
				if (power && !open) Values[i] = Terrain.ReplaceData(val, TrapdoorBlock.SetOpen(data, true));
				else if (!power && open) Values[i] = Terrain.ReplaceData(val, TrapdoorBlock.SetOpen(data, false));
			}
			// Physics Piston extension
			else if (b is PhysicsPistonBlock)
			{
				PistonExtended = power;
				PistonDistance = power ? 2.0f : 0f;
			}
			// Physics Bearing rotation
			else if (b is PhysicsBearingBlock && power)
			{
				BearingAngle += 0.05f;
				if (BearingAngle > MathF.PI * 2f) BearingAngle -= MathF.PI * 2f;
			}
		}
	}

	// Water Buoyancy Calculation: Archimedean upward force for floating boats/ships
	public void CalculateBuoyancy(Terrain terrain, out PVec3 buoyancyForce, out PVec3 centerOfBuoyancy)
	{
		PVec3 pos = Body.Position;
		PMat3 R = Body.Rotation.ToMat3();
		PVec3 submergedCentroid = default(PVec3);
		int submergedCount = 0;

		for (int i = 0; i < Count; i++)
		{
			PVec3 w = pos + R.Mul(Local[i]);
			int cx = (int)MathF.Floor(w.X);
			int cy = (int)MathF.Floor(w.Y);
			int cz = (int)MathF.Floor(w.Z);

			if (cy >= 0 && cy < 256)
			{
				int cellVal = terrain.GetCellValue(cx, cy, cz);
				int contents = Terrain.ExtractContents(cellVal);
				// Water content is 18
				if (contents == 18)
				{
					submergedCentroid = submergedCentroid + w;
					submergedCount++;
				}
			}
		}

		if (submergedCount > 0)
		{
			centerOfBuoyancy = submergedCentroid * (1f / submergedCount);
			float lift = submergedCount * SubLevelConfig.WaterBuoyancyPerBlock;
			buoyancyForce = new PVec3(0f, lift, 0f);
		}
		else
		{
			centerOfBuoyancy = pos;
			buoyancyForce = default(PVec3);
		}
	}

	public void RebuildLocal()
	{
		Local = new PVec3[Count];
		for (int i = 0; i < Count; i++)
		{
			Local[i] = new PVec3(Cx[i] + 0.5f - Body.CenterOfMass.X, Cy[i] + 0.5f - Body.CenterOfMass.Y, Cz[i] + 0.5f - Body.CenterOfMass.Z);
		}
	}

	public void RebuildIndex()
	{
		Index.Clear();
		int minX = int.MaxValue, minY = int.MaxValue, minZ = int.MaxValue;
		int maxX = int.MinValue, maxY = int.MinValue, maxZ = int.MinValue;
		for (int i = 0; i < Count; i++)
		{
			Index[new Point3(Cx[i], Cy[i], Cz[i])] = i;
			minX = Math.Min(minX, Cx[i]);
			minY = Math.Min(minY, Cy[i]);
			minZ = Math.Min(minZ, Cz[i]);
			maxX = Math.Max(maxX, Cx[i]);
			maxY = Math.Max(maxY, Cy[i]);
			maxZ = Math.Max(maxZ, Cz[i]);
		}
		BoundsMin = new PVec3(minX, minY, minZ);
		BoundsMax = new PVec3(maxX + 1, maxY + 1, maxZ + 1);

		Hidden = new bool[Count];
		for (int i = 0; i < Count; i++)
		{
			bool enclosed = true;
			for (int d = 0; d < 6 && enclosed; d++)
			{
				int n;
				Point3 q = new Point3(Cx[i] + Face6[d].X, Cy[i] + Face6[d].Y, Cz[i] + Face6[d].Z);
				if (!Index.TryGetValue(q, out n) || !StructureScanner.IsOpaqueCube(Values[n]))
				{
					enclosed = false;
				}
			}
			Hidden[i] = enclosed;
		}
	}

	static readonly Point3[] Face6 =
	{
		new Point3(1, 0, 0), new Point3(-1, 0, 0), new Point3(0, 1, 0),
		new Point3(0, -1, 0), new Point3(0, 0, 1), new Point3(0, 0, -1)
	};

	public void AddBlock(int value, Point3 cell, float mass)
	{
		int[] values = new int[Count + 1];
		int[] cx = new int[Count + 1];
		int[] cy = new int[Count + 1];
		int[] cz = new int[Count + 1];
		float[] m = new float[Count + 1];
		Array.Copy(Values, values, Count);
		Array.Copy(Cx, cx, Count);
		Array.Copy(Cy, cy, Count);
		Array.Copy(Cz, cz, Count);
		Array.Copy(Mass, m, Count);
		values[Count] = value;
		cx[Count] = cell.X;
		cy[Count] = cell.Y;
		cz[Count] = cell.Z;
		m[Count] = mass;
		Values = values;
		Cx = cx;
		Cy = cy;
		Cz = cz;
		Mass = m;
		Count++;
	}

	public void RemoveAt(int index)
	{
		int[] values = new int[Count - 1];
		int[] cx = new int[Count - 1];
		int[] cy = new int[Count - 1];
		int[] cz = new int[Count - 1];
		float[] mass = new float[Count - 1];
		int j = 0;
		for (int i = 0; i < Count; i++)
		{
			if (i == index) continue;
			values[j] = Values[i];
			cx[j] = Cx[i];
			cy[j] = Cy[i];
			cz[j] = Cz[i];
			mass[j] = Mass[i];
			j++;
		}
		Values = values;
		Cx = cx;
		Cy = cy;
		Cz = cz;
		Mass = mass;
		Count--;
	}

	// In-Flight World Saving Serialization
	public void SaveToXml(XElement parent)
	{
		XElement node = new XElement("SubLevel");
		node.SetAttributeValue("Count", Count);
		node.SetAttributeValue("PosX", Body.Position.X);
		node.SetAttributeValue("PosY", Body.Position.Y);
		node.SetAttributeValue("PosZ", Body.Position.Z);
		node.SetAttributeValue("RotX", Body.Rotation.X);
		node.SetAttributeValue("RotY", Body.Rotation.Y);
		node.SetAttributeValue("RotZ", Body.Rotation.Z);
		node.SetAttributeValue("RotW", Body.Rotation.W);
		node.SetAttributeValue("VelX", Body.Velocity.X);
		node.SetAttributeValue("VelY", Body.Velocity.Y);
		node.SetAttributeValue("VelZ", Body.Velocity.Z);
		node.SetAttributeValue("AngX", Body.AngularVelocity.X);
		node.SetAttributeValue("AngY", Body.AngularVelocity.Y);
		node.SetAttributeValue("AngZ", Body.AngularVelocity.Z);
		node.SetAttributeValue("IsAnchored", IsAnchored);
		node.SetAttributeValue("TreeMode", TreeMode);

		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < Count; i++)
		{
			if (i > 0) sb.Append(';');
			sb.Append(Cx[i]).Append(',').Append(Cy[i]).Append(',').Append(Cz[i]).Append(',').Append(Values[i]);
		}
		node.SetElementValue("Blocks", sb.ToString());
		parent.Add(node);
	}

	public static SubLevel LoadFromXml(XElement node)
	{
		int count = int.Parse(node.Attribute("Count")?.Value ?? "0");
		if (count <= 0) return null;
		string blocksStr = node.Element("Blocks")?.Value;
		if (string.IsNullOrEmpty(blocksStr)) return null;

		int[] cx = new int[count];
		int[] cy = new int[count];
		int[] cz = new int[count];
		int[] vals = new int[count];
		float[] mass = new float[count];

		string[] items = blocksStr.Split(';');
		int actual = Math.Min(count, items.Length);
		for (int i = 0; i < actual; i++)
		{
			string[] parts = items[i].Split(',');
			if (parts.Length >= 4)
			{
				cx[i] = int.Parse(parts[0]);
				cy[i] = int.Parse(parts[1]);
				cz[i] = int.Parse(parts[2]);
				vals[i] = int.Parse(parts[3]);
				mass[i] = Math.Max(0.1f, BlocksManager.Blocks[Terrain.ExtractContents(vals[i])].GetDensity(vals[i]));
			}
		}

		SubLevel level = new SubLevel();
		level.Count = actual;
		level.Cx = cx;
		level.Cy = cy;
		level.Cz = cz;
		level.Values = vals;
		level.Mass = mass;
		level.Body = new RigidBody3D(cx, cy, cz, mass, actual);

		float px = float.Parse(node.Attribute("PosX")?.Value ?? "0");
		float py = float.Parse(node.Attribute("PosY")?.Value ?? "0");
		float pz = float.Parse(node.Attribute("PosZ")?.Value ?? "0");
		level.Body.Position = new PVec3(px, py, pz);

		float rx = float.Parse(node.Attribute("RotX")?.Value ?? "0");
		float ry = float.Parse(node.Attribute("RotY")?.Value ?? "0");
		float rz = float.Parse(node.Attribute("RotZ")?.Value ?? "0");
		float rw = float.Parse(node.Attribute("RotW")?.Value ?? "1");
		level.Body.Rotation = new PQuat(rx, ry, rz, rw);

		float vx = float.Parse(node.Attribute("VelX")?.Value ?? "0");
		float vy = float.Parse(node.Attribute("VelY")?.Value ?? "0");
		float vz = float.Parse(node.Attribute("VelZ")?.Value ?? "0");
		level.Body.Velocity = new PVec3(vx, vy, vz);

		float wx = float.Parse(node.Attribute("AngX")?.Value ?? "0");
		float wy = float.Parse(node.Attribute("AngY")?.Value ?? "0");
		float wz = float.Parse(node.Attribute("AngZ")?.Value ?? "0");
		level.Body.AngularVelocity = new PVec3(wx, wy, wz);

		level.IsAnchored = bool.Parse(node.Attribute("IsAnchored")?.Value ?? "false");
		level.TreeMode = bool.Parse(node.Attribute("TreeMode")?.Value ?? "false");

		level.RebuildIndex();
		level.RebuildLocal();
		return level;
	}
}

public sealed class GlueGroup
{
	public HashSet<Point3> Cells = new HashSet<Point3>();
	public List<Point3> Levers = new List<Point3>();
	public SubLevel Active;
	public double NextLeverScan;
}

public sealed class GlueStore
{
	public readonly List<GlueGroup> Groups = new List<GlueGroup>();
	readonly Dictionary<Point3, GlueGroup> m_byCell = new Dictionary<Point3, GlueGroup>();

	public GlueGroup Find(Point3 cell)
	{
		GlueGroup g;
		return m_byCell.TryGetValue(cell, out g) ? g : null;
	}

	void Index(GlueGroup g)
	{
		foreach (Point3 c in g.Cells) m_byCell[c] = g;
	}

	public void Unindex(GlueGroup g)
	{
		foreach (Point3 c in g.Cells)
		{
			GlueGroup other;
			if (m_byCell.TryGetValue(c, out other) && other == g) m_byCell.Remove(c);
		}
	}

	public GlueGroup AddCells(List<Point3> cells)
	{
		List<GlueGroup> touched = new List<GlueGroup>();
		for (int i = 0; i < cells.Count; i++)
		{
			GlueGroup g = Find(cells[i]);
			if (g != null && !touched.Contains(g)) touched.Add(g);
		}
		GlueGroup target;
		if (touched.Count > 0)
		{
			target = touched[0];
			for (int i = 1; i < touched.Count; i++)
			{
				foreach (Point3 c in touched[i].Cells) target.Cells.Add(c);
				Groups.Remove(touched[i]);
			}
		}
		else
		{
			target = new GlueGroup();
			Groups.Add(target);
		}
		for (int i = 0; i < cells.Count; i++) target.Cells.Add(cells[i]);
		target.Levers.Clear();
		target.NextLeverScan = 0;
		Index(target);
		return target;
	}

	public void RemoveCell(Point3 cell)
	{
		GlueGroup g = Find(cell);
		if (g == null) return;
		g.Cells.Remove(cell);
		m_byCell.Remove(cell);
		g.Levers.Remove(cell);
		if (g.Cells.Count == 0 && g.Active == null) Groups.Remove(g);
	}

	public void SetCells(GlueGroup g, List<Point3> cells)
	{
		Unindex(g);
		g.Cells = new HashSet<Point3>(cells);
		g.Levers.Clear();
		g.NextLeverScan = 0;
		if (g.Cells.Count == 0)
		{
			Groups.Remove(g);
			return;
		}
		Index(g);
	}

	public void Remove(GlueGroup g)
	{
		Unindex(g);
		Groups.Remove(g);
	}

	public void Clear()
	{
		Groups.Clear();
		m_byCell.Clear();
	}

	public string Serialize()
	{
		StringBuilder sb = new StringBuilder();
		sb.Append("SubLevelGlue 1\n");
		for (int i = 0; i < Groups.Count; i++)
		{
			bool first = true;
			foreach (Point3 c in Groups[i].Cells)
			{
				if (!first) sb.Append(';');
				first = false;
				sb.Append(c.X).Append(',').Append(c.Y).Append(',').Append(c.Z);
			}
			sb.Append('\n');
		}
		return sb.ToString();
	}

	public void Deserialize(string text)
	{
		Clear();
		string[] lines = text.Split('\n');
		for (int i = 1; i < lines.Length; i++)
		{
			string line = lines[i].Trim();
			if (line.Length == 0) continue;
			GlueGroup g = new GlueGroup();
			string[] parts = line.Split(';');
			for (int j = 0; j < parts.Length; j++)
			{
				string[] xyz = parts[j].Split(',');
				int x, y, z;
				if (xyz.Length == 3 && int.TryParse(xyz[0], out x) && int.TryParse(xyz[1], out y) && int.TryParse(xyz[2], out z))
				{
					g.Cells.Add(new Point3(x, y, z));
				}
			}
			if (g.Cells.Count > 0)
			{
				Groups.Add(g);
				Index(g);
			}
		}
	}
}

public static class BodyRaycaster
{
	public static bool Raycast(List<SubLevel> levels, Ray3 ray, float maxDistance,
		out SubLevel hitLevel, out int hitIndex, out float hitDistance, out Vector3 hitPoint)
	{
		hitLevel = null;
		hitIndex = -1;
		hitDistance = maxDistance;
		hitPoint = Vector3.Zero;
		Vector3 dir = Vector3.Normalize(ray.Direction);
		for (int li = 0; li < levels.Count; li++)
		{
			SubLevel level = levels[li];
			float dist;
			int index;
			if (RaycastLevel(level, ray.Position, dir, hitDistance, out index, out dist) && dist <= hitDistance)
			{
				hitLevel = level;
				hitIndex = index;
				hitDistance = dist;
				hitPoint = ray.Position + dir * dist;
			}
		}
		return hitLevel != null;
	}

	static bool RaycastLevel(SubLevel level, Vector3 origin, Vector3 dir, float maxDistance, out int hitIndex, out float hitDistance)
	{
		hitIndex = -1;
		hitDistance = 0f;
		RigidBody3D body = level.Body;
		PMat3 Rt = body.Rotation.ToMat3().Transpose();
		PVec3 o = Rt.Mul(new PVec3(origin.X - body.Position.X, origin.Y - body.Position.Y, origin.Z - body.Position.Z)) + body.CenterOfMass;
		PVec3 d = Rt.Mul(new PVec3(dir.X, dir.Y, dir.Z));

		float tmin = 0f;
		float tmax = maxDistance;
		float[] oa = { o.X, o.Y, o.Z };
		float[] da = { d.X, d.Y, d.Z };
		float[] lo = { level.BoundsMin.X, level.BoundsMin.Y, level.BoundsMin.Z };
		float[] hi = { level.BoundsMax.X, level.BoundsMax.Y, level.BoundsMax.Z };
		for (int a = 0; a < 3; a++)
		{
			if (MathF.Abs(da[a]) < 1e-8f)
			{
				if (oa[a] < lo[a] || oa[a] > hi[a]) return false;
			}
			else
			{
				float t1 = (lo[a] - oa[a]) / da[a];
				float t2 = (hi[a] - oa[a]) / da[a];
				if (t1 > t2) { float tmp = t1; t1 = t2; t2 = tmp; }
				tmin = Math.Max(tmin, t1);
				tmax = Math.Min(tmax, t2);
				if (tmin > tmax) return false;
			}
		}

		float t = tmin + 1e-4f;
		float tEnter = tmin;
		int cx = (int)MathF.Floor(o.X + d.X * t);
		int cy = (int)MathF.Floor(o.Y + d.Y * t);
		int cz = (int)MathF.Floor(o.Z + d.Z * t);
		int sx = d.X > 0f ? 1 : (d.X < 0f ? -1 : 0);
		int sy = d.Y > 0f ? 1 : (d.Y < 0f ? -1 : 0);
		int sz = d.Z > 0f ? 1 : (d.Z < 0f ? -1 : 0);
		float tMaxX = sx == 0 ? float.MaxValue : ((sx > 0 ? cx + 1 : cx) - o.X) / d.X;
		float tMaxY = sy == 0 ? float.MaxValue : ((sy > 0 ? cy + 1 : cy) - o.Y) / d.Y;
		float tMaxZ = sz == 0 ? float.MaxValue : ((sz > 0 ? cz + 1 : cz) - o.Z) / d.Z;
		float tDx = sx == 0 ? float.MaxValue : MathF.Abs(1f / d.X);
		float tDy = sy == 0 ? float.MaxValue : MathF.Abs(1f / d.Y);
		float tDz = sz == 0 ? float.MaxValue : MathF.Abs(1f / d.Z);
		for (int i = 0; i < 256; i++)
		{
			int index;
			if (level.Index.TryGetValue(new Point3(cx, cy, cz), out index))
			{
				hitIndex = index;
				hitDistance = tEnter;
				return true;
			}
			if (tMaxX < tMaxY && tMaxX < tMaxZ)
			{
				tEnter = tMaxX;
				cx += sx;
				tMaxX += tDx;
			}
			else if (tMaxY < tMaxZ)
			{
				tEnter = tMaxY;
				cy += sy;
				tMaxY += tDy;
			}
			else
			{
				tEnter = tMaxZ;
				cz += sz;
				tMaxZ += tDz;
			}
			if (tEnter > tmax) break;
		}
		return false;
	}
}
